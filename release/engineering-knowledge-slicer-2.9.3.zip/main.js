'use strict';
(function() {
const __nativeRequire = typeof require === 'function' ? require : null;
const __modules = {
"main.js": function(require, module, exports) {
const {
  ItemView,
  Modal,
  Notice,
  Plugin,
  PluginSettingTab,
  requestUrl,
  Setting,
  TFile,
  TFolder
} = require("obsidian");

const {
  DEFAULT_SETTINGS,
  buildTaskFromFile,
  detectSourceType,
  isProcessableSource,
  migrateSettings,
  normalizeVaultPath,
  rollbackPath,
  sourceHash,
  statusCounts,
  tasksPath
} = require("src/core/task.js");
const { extractTextFromBuffer, sanitizeAttachmentFileName } = require("src/core/extractors.js");
const { createFolderIndexMarkdown, folderIndexPath } = require("src/core/moc.js");
const { parseTagLibrary, suggestMapIndex, validateCard } = require("src/core/tags.js");
const { detectEcosystemPlugins } = require("src/core/ecosystem.js");
const { cardOutputPath, resolveFixedRoute } = require("src/core/routing.js");
const { migrateTaskLedgerV3 } = require("src/core/migration.js");
const { createTaskRecord } = require("src/core/pipeline.js");
// v2.9.2: requestMiniMaxStream 之前漏了导入，SSE 开启时 line ~906 引用直接抛 ReferenceError
const { requestMiniMaxJson, requestMiniMaxStream } = require("src/core/ai-pipeline.js");
const { runKnowledgeWorkflow } = require("src/core/workflow.js");
const { buildCardRecord, cardFileName, renderKnowledgeCard, renderStructuredSummary } = require("src/core/markdown-renderer.js");
const { groupReviewItems, applyBatchAction } = require("src/core/review-service.js");

// v1.1.9 / v1.1.10: 把诊断共享状态挂到 globalThis，让 src/core/ai-pipeline.js 等独立闭包模块也能调用 diag()
// 历史背景：v1.1.6 起在 src/core/ai-pipeline.js（line 3928-4609）里加了 3 个 diag() 调用
//          （minimax.timeout / minimax.transport / minimax.http），但 ai-pipeline.js 是独立 bundle 模块闭包，
//          main.js 里 function diag 对它词法不可见，运行到失败路径时直接报 "diag is not defined"。
// v1.1.9 只 init state，function diag 仍留在 main.js 本地闭包；ai-pipeline wrapper 静默不调用（不抛错），
//          但 ReferenceError 仍可能在 main.js 模块求值之前被触发的边角路径上触发。
// v1.1.10 真正修复：下面把 function diag / keyFingerprint / flushDiagLog / forceFlushDiag 全部 attach 到
//          globalThis.__eksDiag（同时声明一个 no-op fallback 防止 main.js 还没 attach 时 ai-pipeline
//          触发 ReferenceError）。wrapper 走 globalThis 委托，单一来源。
if (!globalThis.__eksDiag) globalThis.__eksDiag = { state: { logPath: null, buffer: [], flushTimer: null } };
// 兜底：如果 main.js 的 function diag 还没装载（极端缓存/重启顺序），ai-pipeline 触发也不抛 ReferenceError，
//   而是 console.log 一行即可。等下方 attach 完成后再调用就会触发真正的实现。
function diagFallback(scope, payload) { try { console.log('[EKS diag] ' + scope + ' ' + JSON.stringify(payload || { value: payload })); } catch (_) {} }
function fpFallback() { return 'fp:<unavailable>'; }
globalThis.__eksDiag.diag = globalThis.__eksDiag.diag || diagFallback;
globalThis.__eksDiag.keyFingerprint = globalThis.__eksDiag.keyFingerprint || fpFallback;
globalThis.__eksDiag.flushDiagLog = globalThis.__eksDiag.flushDiagLog || function () {};
globalThis.__eksDiag.forceFlushDiag = globalThis.__eksDiag.forceFlushDiag || function () {};

// v1.1.3 + v1.1.5: 字符串规范化工具，做 NFC + 控制字符剥离 + 全角→半角空格。
// 必须放在 main.js 模块的"主代码区"（plugin class 闭包能直接看到的位置）。
// 之前误放在 src/core/task.js 模块内，那是独立作用域，main.js 模块内的 plugin class 方法看不到。
// v1.1.5 把它抬到 main.js bundle 模块的 closure 内，使 plugin class 的所有方法都能解析到。
// migration.js 模块内的同款副本保留一份独立副本，避免跨模块引用崩。
// v1.4: 新增 normalizePathForCompare 作为路径比较的唯一入口。
//       顺序固定为 normalizeVaultPath → normalizeUnicodeForm，调用方不再各自拼。
function normalizePathForCompare(value) {
  return normalizeUnicodeForm(normalizeVaultPath(value));
}
function normalizeUnicodeForm(value) {
  let str = String(value || '');
  if (!str) return str;
  if (typeof str.normalize === 'function') {
    try { str = str.normalize('NFC'); } catch { /* 不可用则忽略 */ }
  }
  str = str.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F﻿]/g, '');
  str = str.replace(/[  ]/g, ' ');
  return str;
}

// v1.1.6: 统一诊断日志入口。所有诊断输出都带 `[EKS diag]` 前缀，
// 用户在 Obsidian DevTools Console 里 grep 一行就能定位。
// v1.1.7: 同时写到 .obsidian/plugins/engineering-knowledge-slicer/diag.log 文件，
//        让没法开 DevTools 的用户也能拿到日志（用 Obsidian 自身打开该 Markdown 文件即可查看）。
// v1.1.9: 共享状态 (__diagLogPath / __diagBuffer / __diagFlushTimer) 全部搬上 globalThis.__eksDiag.state，
//        这样 src/core/ai-pipeline.js 等独立 bundle 模块（line 3928-4609）也能写入同一个 diag.log。
function diag(scope, payload) {
  try {
    const data = payload && typeof payload === 'object' ? payload : { value: payload };
    const serialized = JSON.stringify(data, (_k, v) => {
      // v1.4: 改为"内容指纹"模式，不再依赖键名匹配。
      //       任何看起来像凭证的字面量都自动转指纹，与键名无关（防止调用方改个 key 名就漏出来）。
      //       同时也覆盖 JWT (eyJ...)、GitHub PAT (ghp_/gho_/ghs_/ghu_)、MinerU / PaddleOCR / MiniMax (sk-/key-) 各种前缀。
      if (typeof v === 'string') return redactCredential(v);
      return v;
    });
    const line = `[EKS diag] ${scope} ${serialized}`;
    console.log(line);
    // 写入文件：先入缓冲区，1 秒后批量 flush，避免每条诊断都同步 IO 卡 UI
    const state = globalThis.__eksDiag && globalThis.__eksDiag.state;
    if (state && state.logPath) {
      state.buffer.push(new Date().toISOString() + ' ' + line);
      if (!state.flushTimer) {
        state.flushTimer = setTimeout(flushDiagLog, 1000);
      }
    }
  } catch (e) { /* 诊断日志自身不能炸 */ }
}

// v1.4: 内容指纹脱敏。基于凭证特征（不是键名）判定一个字符串是否需要指纹化。
//       已识别的模式：
//         - JWT: 以 "eyJ" 开头的 base64url（典型长度 100+，形如 eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9....）
//         - GitHub PAT: ghp_/gho_/ghs_/ghu_/ghr_ 前缀的 36+ 字符字母数字
//         - OpenAI/Anthropic 风格: sk- 前缀，32+ 字符
//         - MinerU/PaddleOCR/MiniMax 风格: key- / paddle- / sk_ 前缀，32+ 字符
//         - 高熵长 base64/hex 串: 长度 ≥ 40 且几乎全是字母数字+/=- → 高概率是 secret
//       不会误伤：
//         - 短字符串（< 24 字符）
//         - 含空格 / 标点的自然语言片段
//         - 路径、URL、文件名前缀
function redactCredential(value) {
  const str = String(value || '');
  if (str.length < 24) return str;
  // JWT
  if (/^eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}/.test(str)) return keyFingerprint(str);
  // GitHub PAT / API Token (ghp_/gho_/ghs_/ghu_/ghr_/gho_/ghx_)
  if (/^gh[pousxr]_[A-Za-z0-9]{30,}/.test(str)) return keyFingerprint(str);
  // sk- / sk_ / key- / paddle- 前缀的 token
  if (/^(sk-|sk_|key-|paddle-)[A-Za-z0-9]{16,}/.test(str)) return keyFingerprint(str);
  // 高熵长 base64/hex 串（≥ 40 字符，几乎全是 [A-Za-z0-9+/=_-]）
  if (str.length >= 40 && /^[A-Za-z0-9+/=_-]+$/.test(str)) {
    const charClasses = new Set(str.split('').map((c) => {
      if (/[A-Z]/.test(c)) return 'U';
      if (/[a-z]/.test(c)) return 'L';
      if (/[0-9]/.test(c)) return 'D';
      if (c === '+' || c === '/' || c === '=') return 'B';
      return c; // _ -
    }));
    if (charClasses.size >= 3) return keyFingerprint(str);
  }
  return str;
}

// v2.8.1: 按行剥离文件开头已有的日志头部说明块（第一行为标题，随后是空行或以 > 开头的说明行）。
//   旧实现用 indexOf('\n\n\n\n') 找头部边界，但该序列在文件里从不出现（头部结尾只有 \n\n），
//   导致旧头部永远剥不掉，每次 flush 都在文件最前面再摞一份头部（用户日志里累积了 27 份）。
//   循环剥离可自愈历史重复头部文件：升级后第一次 flush 即清理干净。
function stripDiagHeaders(text) {
  let lines = String(text || '').split('\n');
  while (lines.length && lines[0] === '# 工程知识切片 诊断日志') {
    let i = 1;
    while (i < lines.length && (lines[i] === '' || lines[i].startsWith('>'))) i += 1;
    lines = lines.slice(i);
  }
  return lines.join('\n');
}

function flushDiagLog() {
  const state = globalThis.__eksDiag && globalThis.__eksDiag.state;
  if (!state) return;
  state.flushTimer = null;
  if (!state.logPath || !state.buffer.length) return;
  try {
    const fs = require('fs');
    const path = require('path');
    // 每次 flush 前预留头部，方便用户打开文件第一眼就看到说明
    const header = [
      '# 工程知识切片 诊断日志',
      '',
      '> 这份文件由插件自动写入，记录所有 `[EKS diag]` 诊断事件。',
      '> 复制本文件全部内容（除了这一段说明）发给开发者即可定位问题。',
      '> 文件位置：`' + state.logPath + '`',
      '> 日志会自动 trim 到最近约 2000 行，避免文件无限增长。',
      '',
      ''
    ].join('\n');
    const lines = state.buffer.join('\n') + '\n';
    state.buffer = [];
    // 读旧内容、追加、trim
    let existing = '';
    try { existing = fs.readFileSync(state.logPath, 'utf-8'); } catch (_) { /* 不存在则忽略 */ }
    // v2.8.1: 去掉旧 header（含历史累积的多份）再合并，保证文件里有且仅有一份头部
    const oldBody = stripDiagHeaders(existing);
    const merged = header + oldBody + lines;
    // trim 到最近 2000 行
    const allLines = merged.split('\n');
    const MAX_LINES = 2000;
    const trimmed = allLines.length > MAX_LINES ? allLines.slice(allLines.length - MAX_LINES).join('\n') : merged;
    fs.mkdirSync(path.dirname(state.logPath), { recursive: true });
    fs.writeFileSync(state.logPath, trimmed, 'utf-8');
  } catch (e) {
    // 写日志失败不能炸插件
    try { console.warn('[EKS diag] flush failed', String(e && e.message || e)); } catch (_) {}
  }
}

// 强制立即 flush（用于进程退出前的最后一批日志）
function forceFlushDiag() {
  const state = globalThis.__eksDiag && globalThis.__eksDiag.state;
  if (state && state.flushTimer) { clearTimeout(state.flushTimer); state.flushTimer = null; }
  flushDiagLog();
}

// v1.1.8: 实时进度条 + 心跳
// 1 秒一次刷新 elapsedMs / at，不写盘、不重渲染整个 dashboard，只更新进度条 DOM
function startProgressHeartbeat(plugin, task, startedAt) {
  return setInterval(() => {
    try {
      if (!task || !plugin) return;
      task.progress = task.progress || {};
      task.progress.elapsedMs = Date.now() - startedAt;
      task.progress.at = new Date().toISOString();
      plugin.refreshProgressOnly?.(task);
    } catch (_) { /* 心跳失败不能炸 */ }
  }, 1000);
}

// v1.1.8: 根据已用时 + 已完成批次数估算剩余时间
function computeEtaText(progress) {
  if (!progress || !progress.batchTotal || !progress.batchIndex || !progress.elapsedMs) return '';
  const avgPerBatch = progress.elapsedMs / progress.batchIndex;
  const remaining = progress.batchTotal - progress.batchIndex;
  if (remaining <= 0) return '';
  const etaMs = Math.round(avgPerBatch * remaining);
  return `预计剩余 ${formatDuration(etaMs)}`;
}

// 计算密钥指纹（sha256 前 8 字符），绝不暴露原值。
// 即使指纹出现在日志中也不会泄露密钥本身。
function keyFingerprint(value) {
  try {
    const crypto = require('crypto');
    return 'fp:' + crypto.createHash('sha256').update(String(value || '')).digest('hex').slice(0, 8);
  } catch (_) {
    return 'fp:<unavailable>';
  }
}

// v1.1.10: 把上面定义的真正实现 attach 到 globalThis.__eksDiag，替换占位的 fallback。
// ai-pipeline.js 的本地 diag wrapper 委托到 globalThis.__eksDiag.diag，现在能找到真函数。
if (typeof globalThis.__eksDiag === 'object') {
  globalThis.__eksDiag.diag = diag;
  globalThis.__eksDiag.keyFingerprint = keyFingerprint;
  globalThis.__eksDiag.flushDiagLog = flushDiagLog;
  globalThis.__eksDiag.forceFlushDiag = forceFlushDiag;
}

function loadSecretsFile() {
  try {
    const fs = require('fs');
    const path = require('path');
    const os = require('os');
    const secretsPath = path.join(os.homedir(), '.eks-secrets.json');
    if (fs.existsSync(secretsPath)) {
      const raw = fs.readFileSync(secretsPath, 'utf-8');
      const parsed = JSON.parse(raw);
      diag('secrets.loaded', {
        path: secretsPath,
        sizeBytes: raw.length,
        keys: Object.keys(parsed || {}).reduce((acc, k) => {
          acc[k] = parsed[k] ? keyFingerprint(parsed[k]) : '<empty>';
          return acc;
        }, {})
      });
      return parsed;
    }
    diag('secrets.missing', { path: secretsPath, hint: '请创建该文件并写入 minimaxApiKey/pdfMineruApiKey/pdfPaddleOcrApiKey 三个字段' });
  } catch (e) {
    diag('secrets.error', { message: String(e && e.message || e) });
    console.warn('工程知识切片: 密钥文件加载失败', e);
  }
  return {};
}

// v1.7 (M-01): 重写 RateLimiter。
//       旧实现是"两段互斥"——并发上限 + 最小间隔，但 100ms 忙等轮询会无谓唤醒；
//       失败 / 超时没有 backoff，会立刻重试打到上游。
//       新实现：
//         - 滑动窗口（保留过去 N 次请求时间戳），窗口内请求数 ≤ maxConcurrent 才放行
//         - 最小间隔仍是 intervalMs，但用事件驱动（resolve 链）取代 100ms 轮询
//         - 失败时指数退避：连续失败次数 × intervalMs 上限 backoffMs
//         - run() 接受 fn，自动 acquire/release + onError 触发 backoff
class RateLimiter {
  constructor({ intervalMs = 1000, maxConcurrent = 2, backoffMaxMs = 30_000, windowSize = 10 } = {}) {
    this.intervalMs = intervalMs;
    this.maxConcurrent = maxConcurrent;
    this.backoffMaxMs = backoffMaxMs;
    this.windowSize = windowSize;
    this.timestamps = []; // 滑动窗口内最近 N 次请求的 timestamp
    this.failures = 0;
    this.waiters = []; // FIFO 等待队列，每项是 { resolve, startedAt }
  }

  _cleanupExpired(now) {
    const cutoff = now - this.intervalMs * this.windowSize;
    while (this.timestamps.length && this.timestamps[0] < cutoff) this.timestamps.shift();
  }

  _activeInWindow(now) {
    const cutoff = now - this.intervalMs;
    let count = 0;
    for (const t of this.timestamps) if (t >= cutoff) count += 1;
    return count;
  }

  _scheduleNextWaiter() {
    // 滑动窗口按请求开始时间限流，不能在请求结束时直接放行下一个 waiter。
    // waiter 自己的定时器会在窗口腾出额度后放行并从队列移除。
  }

  acquire() {
    return new Promise((resolve) => {
      const now = Date.now();
      this._cleanupExpired(now);
      const active = this._activeInWindow(now);
      if (active < this.maxConcurrent) {
        // 有空位，立即放行
        this.timestamps.push(now);
        resolve();
        return;
      }
      // 排队：等下一个"窗口滑过"或最早的请求出窗口
      const earliest = this.timestamps[0] || now;
      const waitMs = Math.max(100, (earliest + this.intervalMs) - now);
      const waiter = { resolve, startedAt: now, done: false };
      const tryFire = () => {
        if (waiter.done) return; // 已被 _scheduleNextWaiter 处理
        const t = Date.now();
        this._cleanupExpired(t);
        if (this._activeInWindow(t) < this.maxConcurrent) {
          this.timestamps.push(t);
          waiter.done = true;
          const waiterIndex = this.waiters.indexOf(waiter);
          if (waiterIndex >= 0) this.waiters.splice(waiterIndex, 1);
          resolve();
          return;
        }
        // 仍未空：再排一次队（重设 timer），不修改 waiters 数组以免重复入队
        const earliest2 = this.timestamps[0] || t;
        const waitMs2 = Math.max(100, (earliest2 + this.intervalMs) - t);
        waiter.timer = setTimeout(tryFire, waitMs2);
      };
      waiter.timer = setTimeout(tryFire, waitMs);
      this.waiters.push(waiter);
    });
  }

  release() {
    // 滑动窗口按时间自动释放额度；不能因单个请求提前结束而绕过 intervalMs。
  }

  // 记录一次失败；后续 acquire 会自动指数退避
  recordFailure() {
    this.failures += 1;
  }
  recordSuccess() {
    this.failures = 0;
  }
  backoffMs() {
    if (this.failures === 0) return 0;
    // 1, 2, 4, 8 ... 指数退避到 backoffMaxMs
    return Math.min(this.backoffMaxMs, this.intervalMs * Math.pow(2, Math.min(this.failures - 1, 10)));
  }

  async run(fn) {
    const backoff = this.backoffMs();
    if (backoff > 0) {
      try { diag('ratelimit.backoff', { failures: this.failures, backoffMs: backoff }); } catch (_) {}
      await new Promise((r) => setTimeout(r, backoff));
    }
    await this.acquire();
    try {
      const result = await fn();
      this.recordSuccess();
      return result;
    } catch (e) {
      this.recordFailure();
      throw e;
    } finally {
      this.release();
    }
  }
}

const VIEW_TYPE_SLICER = 'engineering-knowledge-slicer-dashboard';
const PROCESSING_STATUSES = new Set(['parsing', 'classifying', 'summarizing', 'atomizing', 'validating', 'writing']);

module.exports = class EngineeringKnowledgeSlicerPlugin extends Plugin {
  async onload() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, migrateSettings(await this.loadData()));
    const _secrets = loadSecretsFile();
    if (this.settings.useEnvKeys !== false) {
      if (_secrets.minimaxApiKey) this.settings.minimaxApiKey = _secrets.minimaxApiKey;
      if (_secrets.pdfMineruApiKey) this.settings.pdfMineruApiKey = _secrets.pdfMineruApiKey;
      if (_secrets.pdfPaddleOcrApiKey) this.settings.pdfPaddleOcrApiKey = _secrets.pdfPaddleOcrApiKey;
    }
    // v1.1.6: 报告 effective 密钥指纹（绝不是原值），便于诊断"密钥填了但被插件忽略"类问题
    // v1.1.7: 同时初始化 diag.log 文件路径，让没法开 DevTools 的用户也能拿到日志
    // v1.3:   默认写到 vault 之外（~/.eks/logs/diag.log），
    //         避免被 iCloud / OneDrive / Git 等同步工具重复上传/同步。
    //         设置页可切回 vault 内（diagLogInVault: true）。
    try {
      const adapter = this.app.vault && this.app.vault.adapter;
      const path = require('path');
      const fs = require('fs');
      const os = require('os');
      let logPath = null;
      if (this.settings.diagLogInVault && adapter && typeof adapter.getBasePath === 'function') {
        logPath = path.join(adapter.getBasePath(), '.obsidian', 'plugins', 'engineering-knowledge-slicer', 'diag.log');
      } else {
        // vault 之外：~/.eks/logs/diag.log
        const logDir = path.join(os.homedir(), '.eks', 'logs');
        try { fs.mkdirSync(logDir, { recursive: true }); } catch (_) { /* 已存在或不可写就退化到 console */ }
        logPath = path.join(logDir, 'diag.log');
      }
      // v1.1.9: logPath 现在是 globalThis.__eksDiag.state 上的共享变量
      globalThis.__eksDiag.state.logPath = logPath;
      diag('onload.diagLogPath', { path: logPath, inVault: !!this.settings.diagLogInVault });
    } catch (e) { /* 取不到路径就退化到 console only */ try { diag('onload.diagLogPath.error', { message: String(e && e.message || e) }); } catch (_) {} }
    diag('onload.keys.effective', {
      useEnvKeys: this.settings.useEnvKeys,
      minimaxApiKey: this.settings.minimaxApiKey ? keyFingerprint(this.settings.minimaxApiKey) : '<empty>',
      pdfMineruApiKey: this.settings.pdfMineruApiKey ? keyFingerprint(this.settings.pdfMineruApiKey) : '<empty>',
      pdfPaddleOcrApiKey: this.settings.pdfPaddleOcrApiKey ? keyFingerprint(this.settings.pdfPaddleOcrApiKey) : '<empty>',
      minimaxEndpoint: this.settings.minimaxEndpoint,
      pdfMineruApiEndpoint: this.settings.pdfMineruApiEndpoint,
      pdfPaddleOcrApiEndpoint: this.settings.pdfPaddleOcrApiEndpoint
    });
    // v1.3: 注册上传确认桥接，供闭包模块（external-pdf.js）弹上传确认弹窗
    setEksUploadConfirm(this);
    // 密钥注入后再写盘，确保 data.json 不会因为顺序问题而清掉 secrets
    await this.saveData(this.settings);
    this.rateLimiter = new RateLimiter({
      intervalMs: this.settings.rateLimitMs || 1000,
      maxConcurrent: this.settings.rateLimitMaxConcurrent || 2,
      backoffMaxMs: Number(this.settings.rateLimitBackoffMaxMs || 30000),
      windowSize: Number(this.settings.rateLimitWindowSize || 10)
    });
    this.autoProcessing = false;
    this.pauseRequested = false;
    this.cancelRequestedTaskId = '';
    this.sessionStats = { scanned: 0, processed: 0, written: 0, review: 0, failed: 0, skipped: 0, current: '', lastMessage: '等待开始处理' };
    this.registerView(VIEW_TYPE_SLICER, (leaf) => new SlicerDashboardView(leaf, this));

    this.addRibbonIcon('layers', '工程知识切片', () => this.activateView());
    this.addCommand({ id: 'open-slicer-dashboard', name: '打开工程知识切片控制台', callback: () => this.activateView() });
    this.addCommand({ id: 'scan-source-files', name: '扫描源文件', callback: () => this.scanSourceFiles(true) });
    this.addCommand({ id: 'process-next-source-file', name: '处理下一个队列文件', callback: () => this.processNextQueuedTask() });
    this.addCommand({ id: 'auto-process-source-files', name: '自动处理可信卡片', callback: () => this.autoProcessQueue(true) });
    this.addCommand({ id: 'retry-failed-source-files', name: '重试失败任务并自动处理', callback: () => this.retryFailedAndAutoProcess(true) });
    this.addCommand({ id: 'rollback-last-batch', name: '回滚最近一批卡片', callback: () => this.rollbackLastBatch() });
    this.addCommand({ id: 'open-ai-settings', name: '打开工程知识切片 AI 设置', callback: () => this.activateView() });

    this.registerEvent(this.app.workspace.on('file-menu', (menu, file) => {
      if (!(file instanceof TFile)) return;
      menu.addItem((item) => item
        .setTitle('用工程知识切片处理')
        .setIcon('layers')
        .onClick(() => this.processSingleFile(file)));
      menu.addItem((item) => item
        .setTitle('查看切片处理历史')
        .setIcon('history')
        .onClick(() => this.showHistoryForFile(file)));
    }));

    // v2.9.0: 会话级失败缓存清理 + 中断任务续传询问。
    //   注册在 autoScan 之前：失败记录先清掉，续传询问先弹出；
    //   用户选择「继续」后 autoProcessQueue 与自动扫描由 autoProcessing 锁串行，不会打架。
    this.app.workspace.onLayoutReady(() => {
      this.sessionStartupCleanup().catch((error) => {
        try { diag('startup.cleanup.error', { message: String(error && error.message || error) }); } catch (_) {}
      });
    });

    // v2.8: 自动扫描改为设置项，默认关闭。
    //   只有 autoScanOnStartup === true 时才在工作区布局就绪后自动扫描源文件目录
    //   （扫描完按既有逻辑进入自动处理）；默认关闭状态下插件启动不读源文件、
    //   不触发云端解析与 MiniMax 调用，用户需手动点「扫描并自动处理」或用命令。
    if (this.settings.autoScanOnStartup === true) {
      this.app.workspace.onLayoutReady(() => {
        diag('autoScan.start', { reason: 'autoScanOnStartup=true' });
        this.scanSourceFiles(true).catch((error) => {
          try { diag('autoScan.error', { message: String(error && error.message || error) }); } catch (_) {}
        });
      });
    }

    this.addSettingTab(new SlicerSettingTab(this.app, this));
    // v1.1.7: 通知用户诊断日志文件位置（首次加载时显示一次，之后静默）
    // v1.1.9: 通知版本也跟进，避免旧用户重复弹窗同时提醒现在 diag 对所有路径都能写入
    try {
      const prev = await this.loadData();
      const notified = prev && prev.__diagLogNotifiedVersion === '1.1.9';
      const logPath = globalThis.__eksDiag && globalThis.__eksDiag.state && globalThis.__eksDiag.state.logPath;
      if (!notified && logPath) {
        new Notice(`工程知识切片 诊断日志已启用：${logPath}\n遇到问题时把该文件内容发给我即可定位。`);
        this.settings.__diagLogNotifiedVersion = '1.1.9';
        await this.saveData(this.settings);
      }
    } catch (_) { /* 通知失败不能影响插件加载 */ }
  }

  onunload() {
    // v1.1.7: 卸载前最后 flush 一次，确保所有诊断日志落盘
    try { forceFlushDiag(); } catch (_) {}
    // v1.6 (M-04): 卸载前 flush pending tasks，避免防抖窗口内的写丢失
    try { this.flushSaveTasksImmediate(); } catch (_) {}
    this.app.workspace.detachLeavesOfType(VIEW_TYPE_SLICER);
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }

  async testServiceConnection(service) {
    const config = serviceConnectionConfig(service, this.settings);
    diag('testConnection.start', { service, url: config.url, apiKey: config.apiKey ? keyFingerprint(config.apiKey) : '<empty>' });
    if (!config.apiKey) {
      diag('testConnection.noKey', { service, hint: '请确认 ~/.eks-secrets.json 中字段名拼写正确：minimaxApiKey / pdfMineruApiKey / pdfPaddleOcrApiKey' });
      new Notice(`${config.label} 密钥未配置。`);
      return false;
    }
    if (typeof fetch !== 'function') {
      diag('testConnection.noFetch', { service });
      new Notice('当前 Obsidian 环境不支持网络请求。');
      return false;
    }
    try {
      const response = await obsidianRequest(config.url, config.request);
      diag('testConnection.response', {
        service,
        status: response.status,
        ok: response.ok,
        url: config.url
      });
      if (response.status === 401 || response.status === 403) {
        let body = '';
        try { body = String(await response.text() || '').slice(0, 300); } catch (_) { /* 忽略 */ }
        diag('testConnection.auth', {
          service,
          status: response.status,
          serverResponse: body
        });
        throw new Error(`鉴权失败（HTTP ${response.status}）。${body ? '服务端响应：' + body.slice(0, 200) : ''}`);
      }
      if (service === 'minimax' && !response.ok) throw new Error(`HTTP ${response.status}`);
      new Notice(`${config.label} 连接可用。`);
      return true;
    } catch (error) {
      diag('testConnection.error', {
        service,
        errorClass: error && error.constructor ? error.constructor.name : typeof error,
        errorMessage: String(error && error.message || error),
        errorStack: String(error && error.stack || '').split('\n').slice(0, 6).join(' | ')
      });
      new Notice(`${config.label} 连接失败：${sanitizeSecret(error.message)}`);
      return false;
    }
  }

  async activateView() {
    const leaves = this.app.workspace.getLeavesOfType(VIEW_TYPE_SLICER);
    const leaf = leaves[0] || this.app.workspace.getRightLeaf(false);
    await leaf.setViewState({ type: VIEW_TYPE_SLICER, active: true });
    this.app.workspace.revealLeaf(leaf);
  }

  async refreshViews() {
    for (const leaf of this.app.workspace.getLeavesOfType(VIEW_TYPE_SLICER)) {
      if (leaf.view && leaf.view.render) {
        try {
          await leaf.view.render();
        } catch (error) {
          console.error('工程知识切片界面刷新失败', error);
          new Notice(`工程知识切片界面刷新失败：${error.message}`);
        }
      }
    }
  }

  // v1.1.8: 轻量级进度刷新，只更新进度条 DOM 属性 + 已用时文本
  // 不写盘、不重渲染整个 dashboard，给 1 秒一次心跳用
  // v1.1.9: 加 try/catch 兜底 + null-safe 迭代，避免心跳触发 "object is not iterable" 把插件炸掉
  refreshProgressOnly(task) {
    try {
      if (!this.app || !this.app.workspace || typeof this.app.workspace.getLeavesOfType !== 'function') return;
      const leaves = this.app.workspace.getLeavesOfType(VIEW_TYPE_SLICER) || [];
      for (const leaf of leaves) {
        if (leaf && leaf.view && typeof leaf.view.refreshProgress === 'function') {
          try { leaf.view.refreshProgress(task); } catch (_) { /* 单个视图失败不影响其他 */ }
        }
      }
    } catch (_) { /* 心跳失败不能炸插件 */ }
  }

  openSettings() {
    const setting = this.app.setting;
    if (!setting) {
      new Notice('当前 Obsidian 没有暴露设置面板接口。请从设置 > 第三方插件 > 工程知识切片进入。');
      return;
    }
    if (typeof setting.open === 'function') setting.open();
    if (typeof setting.openTabById === 'function') setting.openTabById(this.manifest.id);
  }

  async ensureFolders() {
    for (const path of [
      this.settings.bidIntakePath,
      this.settings.businessIntakePath,
      this.settings.bidOutputPath,
      this.settings.businessOutputPath,
      this.settings.artifactsPath,
      this.settings.draftPath,
      this.settings.logPath
    ]) {
      await ensureFolder(this.app, path);
    }
  }

  async scanSourceFiles(showNotice = false) {
    await this.ensureFolders();
    const tasks = await this.loadTasks();
    const files = this.app.vault.getFiles().filter((file) => this.isInIntake(file.path) && !this.isInternalSlicerFile(file.path));
    let added = 0;
    for (const file of files) {
      const buffer = Buffer.from(await this.app.vault.readBinary(file));
      const hash = sourceHash(buffer);
      const existing = tasks.find((task) => task.source_hash === hash && task.library === libraryForPath(file.path, this.settings));
      if (existing) {
        if (existing.source_path !== file.path && !existing.source_aliases.includes(file.path)) existing.source_aliases.push(file.path);
        continue;
      }
      const task = createTaskRecord({
        sourcePath: file.path,
        sourceHash: hash,
        sourceType: detectSourceType(file.path),
        library: libraryForPath(file.path, this.settings),
        versions: runtimeVersions(this.settings)
      });
      if (!isProcessableSource(file.path)) task.status = detectSourceType(file.path) === 'unknown' ? 'skipped' : 'unsupported';
      tasks.push(task);
      added += 1;
    }
    this.sessionStats.scanned += files.length;
    await this.saveTasks(tasks);
    if (showNotice) new Notice(`工程知识切片已扫描 ${files.length} 个文件，新增 ${added} 个任务。开始自动处理。`);
    await this.refreshViews();
    await this.autoProcessQueue(false);
    return { scanned: files.length, added };
  }

  isInIntake(path) {
    // v1.4: 统一用 normalizePathForCompare 入口
    const normalized = normalizePathForCompare(path);
    return [this.settings.bidIntakePath, this.settings.businessIntakePath]
      .some((root) => normalized.startsWith(`${normalizePathForCompare(root)}/`));
  }

  isInternalSlicerFile(path) {
    // v1.4: 统一用 normalizePathForCompare 入口；修复原代码对 draftPath/logPath 不 normalize 的 bug
    const normalized = normalizePathForCompare(path);
    return normalized.startsWith(`${normalizePathForCompare(this.settings.artifactsPath)}/`)
      || normalized.startsWith(`${normalizePathForCompare(this.settings.draftPath)}/`)
      || normalized.startsWith(`${normalizePathForCompare(this.settings.logPath)}/`);
  }

  async processSingleFile(file) {
    await this.ensureFolders();
    const buffer = Buffer.from(await this.app.vault.readBinary(file));
    const tasks = await this.loadTasks();
    const hash = sourceHash(buffer);
    const library = libraryForPath(file.path, this.settings);
    const existing = tasks.find((item) => item.source_hash === hash && item.library === library);
    if (existing) {
      if (!['queued', 'failed'].includes(existing.status)) {
        new Notice(`该文件已有处理记录：${existing.status}。如需重做，请在审核台使用“重新生成”或先清空插件缓存。`);
        await this.activateView();
        return;
      }
      existing.status = 'queued';
      existing.updated_at = new Date().toISOString();
      existing.errors = [];
    } else {
      const task = createTaskRecord({ sourcePath: file.path, sourceHash: hash, sourceType: detectSourceType(file.path), library, versions: runtimeVersions(this.settings) });
      tasks.push(task);
    }
    await this.saveTasks(tasks);
    await this.processTask(existing || tasks.at(-1));
  }

  async processNextQueuedTask() {
    const tasks = await this.loadTasks();
    const task = tasks.find((item) => item.status === 'queued');
    if (!task) {
      new Notice('没有待处理的工程知识切片任务。');
      return;
    }
    await this.processTask(task);
  }

  async autoProcessQueue(showNotice = false) {
    if (this.autoProcessing) {
      if (showNotice) new Notice('自动处理正在运行，请查看处理概览中的实时进度。');
      return { processed: 0, alreadyRunning: true };
    }
    this.autoProcessing = true;
    this.pauseRequested = false;
    let processed = 0;
    try {
      const resumable = await this.loadTasks();
      let resumed = false;
      for (const task of resumable) {
        if (task.status !== 'paused') continue;
        task.status = 'queued';
        task.updated_at = new Date().toISOString();
        resumed = true;
      }
      if (resumed) await this.saveTasks(resumable);
      this.sessionStats.lastMessage = '正在自动处理队列';
      while (!this.pauseRequested) {
        const tasks = await this.recoverStaleProcessingTasks(await this.loadTasks());
        const task = tasks.find((item) => item.status === 'queued');
        if (!task) break;
        await this.processTask(task);
        processed += 1;
        if (this.settings.rateLimitMs && !this.pauseRequested) {
          await new Promise(resolve => setTimeout(resolve, this.settings.rateLimitMs));
        }
        if (processed >= 500) {
          this.sessionStats.lastMessage = `已达到本轮 500 个任务上限，剩余任务将在下次运行时继续处理。`;
          if (showNotice) new Notice(`已处理 500 个任务，达到本轮上限。仍有未处理任务，请再次运行「自动处理」继续。`);
          break;
        }
      }
      this.sessionStats.lastMessage = `自动处理完成，本轮处理 ${processed} 个任务`;
      if (showNotice) new Notice(`自动处理完成，本轮处理 ${processed} 个任务。可信卡片已入库，疑问项进入审核台。`);
      return { processed, alreadyRunning: false };
    } finally {
      this.autoProcessing = false;
      this.sessionStats.current = '';
      await this.refreshViews();
    }
  }

  async retryFailedAndAutoProcess(showNotice = false) {
    const tasks = await this.loadTasks();
    let reset = 0;
    for (const task of tasks) {
      if (task.status !== 'failed') continue;
      task.status = 'queued';
      task.updated_at = new Date().toISOString();
      task.errors = [];
      task.review_atom_ids = [];
      reset += 1;
    }
    await this.saveTasks(tasks);
    // saveTasks 是防抖写盘；autoProcessQueue 会立即从磁盘重读账本。
    // 重试入口必须先 flush，否则可能仍读到 failed 状态而跳过刚重新入队的任务。
    await this.flushSaveTasksImmediate();
    this.sessionStats.lastMessage = `已重新入队 ${reset} 个失败任务`;
    if (showNotice) new Notice(`已重新入队 ${reset} 个失败任务，开始自动处理。`);
    await this.refreshViews();
    await this.autoProcessQueue(false);
  }

  async processSelectedTasks(taskIds) {
    for (const taskId of taskIds) {
      const tasks = await this.loadTasks();
      const task = tasks.find((item) => item.task_id === taskId);
      if (task) await this.processTask(task);
    }
  }

  pauseProcessing() {
    this.pauseRequested = true;
    this.sessionStats.lastMessage = '将在当前 API 阶段完成后暂停';
    new Notice('已请求暂停：当前 API 请求完成后保存进度并暂停。');
    this.refreshViews();
  }

  cancelCurrentTask(taskId) {
    this.cancelRequestedTaskId = taskId;
    this.sessionStats.lastMessage = '将在当前 API 阶段完成后取消当前任务';
    new Notice('已请求取消：当前 API 请求完成后停止该任务。');
    this.refreshViews();
  }

  async rollbackLastBatch() {
    const tasks = await this.loadTasks();
    const written = tasks.filter((t) => t.status === 'written' && t.writtenFiles && t.writtenFiles.length);
    if (!written.length) {
      new Notice('没有可回滚的已入库卡片批次。');
      return;
    }
    const lastBatch = written[written.length - 1];
    let deleted = 0;
    for (const filePath of lastBatch.writtenFiles) {
      const file = this.app.vault.getAbstractFileByPath(filePath);
      if (file instanceof TFile) {
        await this.app.vault.trash(file);
        deleted++;
      }
    }
    lastBatch.status = 'rolled_back';
    lastBatch.updated_at = new Date().toISOString();
    await this.saveTasks(upsertTask(tasks, lastBatch));
    this.sessionStats.lastMessage = `已回滚 ${deleted} 张卡片`;
    new Notice(`已回滚最近一批 ${deleted} 张知识卡片。`);
    await this.refreshViews();
  }

  assertTaskCanContinue(task) {
    if (this.cancelRequestedTaskId === task.task_id) {
      const error = new Error('任务已由使用者取消');
      error.code = 'TASK_CANCELLED';
      throw error;
    }
    if (this.pauseRequested) {
      const error = new Error('任务已由使用者暂停');
      error.code = 'TASK_PAUSED';
      throw error;
    }
  }

  async processTask(task) {
    const tasks = await this.loadTasks();
    const current = tasks.find((item) => item.task_id === task.task_id) || task;
    const startedAt = Date.now();
    try {
      // v1.1.2: 旧任务 / 第三方写入可能留下 source_path 为空的情况，统一兜底成空字符串
      // 防止后续 readBinary / Notice 拼接时出现 'undefined'/'null' 字面。
      // v1.4: 用 normalizePathForCompare 统一 normalize 顺序
      current.source_path = normalizePathForCompare(current.source_path || '');
      this.sessionStats.current = current.source_path;
      current.errors = [];
      current.review_atom_ids = [];
      current.written_card_ids = [];
      await this.setTaskProgress(current, '准备处理源文件', { stage: 'start', startedAt: new Date(startedAt).toISOString() });
      if (!current.source_path) throw new Error('源文件路径为空，请在扫描源文件后重试。');
      if (!isProcessableSource(current.source_path)) {
        current.status = 'unsupported';
        current.updated_at = new Date().toISOString();
        await this.saveTasks(upsertTask(tasks, current));
        this.sessionStats.skipped += 1;
        this.sessionStats.lastMessage = `已跳过暂不支持的文件：${current.source_path}`;
        return;
      }

      let parsePackage = await this.loadArtifact(current, 'parsed');
      if (!parsePackage) {
        current.status = 'parsing';
        await this.setTaskProgress(current, '正在调用文档解析 API', { stage: 'parsing', elapsedMs: Date.now() - startedAt });
        const file = this.app.vault.getAbstractFileByPath(current.source_path);
        if (!(file instanceof TFile)) throw new Error(`未找到源文件：${current.source_path}`);
        const buffer = Buffer.from(await this.app.vault.readBinary(file));
        const extracted = await extractTextFromBuffer(current.source_path, buffer, {
          pdfExtractor: await this.getPdfExtractorConfig(current)
        });
        if (extracted.status !== 'ok' || !extracted.parsePackage) throw new Error(extracted.message || '文档解析 API 未返回可用 Markdown');
        parsePackage = extracted.parsePackage;
        // v2.9.0: 邮件附件落盘 + 入队切片。只在首次解析执行；
        //   续传时 parsed artifact 已含 emailAttachments（保存路径），跳过本块。
        if (Array.isArray(extracted.attachments) && extracted.attachments.length) {
          const savedAttachments = await this.saveEmailAttachments(current, extracted.attachments);
          if (savedAttachments.length) {
            parsePackage.metadata = Object.assign({}, parsePackage.metadata, {
              emailAttachments: savedAttachments.map((item) => ({ filename: item.filename, path: item.path, size: item.size }))
            });
          }
        }
        current.status = 'parsed';
        await this.persistArtifact(current, 'parsed', parsePackage);
      }

      this.assertTaskCanContinue(current);

      const contracts = await this.loadRuntimeContracts();
      const tagLibraryText = await this.loadTagLibraryText();
      const tagLibrary = parseTagLibrary(tagLibraryText);
      const existingCards = await this.loadExistingCards(current.source_hash);
      // v1.1.8: 启动心跳，1 秒一次更新已用时 / 进度条，避免 18 分钟黑屏
      const heartbeat = startProgressHeartbeat(this, current, startedAt);
      diag('heartbeat.start', { sourcePath: current.source_path, intervalMs: 1000 });
      let workflow;
      try {
        workflow = await runKnowledgeWorkflow({
        parsePackage,
        folderMap: contracts.folderMap,
        schemas: contracts.schemas,
        prompts: contracts.prompts,
        classification: await this.loadArtifact(current, 'classification'),
        summary: await this.loadArtifact(current, 'summary'),
        atomResult: await this.loadArtifact(current, 'atoms'),
        loadTypePrompt: (route) => this.loadComponentText(route.prompt),
        sourceHash: current.source_hash,
        maxChunkChars: this.settings.aiChunkSize,
        maxPointsPerRequest: this.settings.maxPointsPerRequest,
        summaryConcurrency: this.settings.summaryConcurrency,
        atomizationConcurrency: this.settings.atomizationConcurrency,
        shortDocumentMaxCards: this.settings.shortDocumentMaxCards,
        chunkOverlapRatio: this.settings.chunkOverlapRatio,
        coalesceTinyChunks: this.settings.coalesceTinyChunks,
        versions: runtimeVersions(this.settings),
        existingCards,
        existingFingerprints: existingCards.map((card) => card.atom_fingerprint).filter(Boolean),
        validateLabels: (atom) => validateAtomLabels(tagLibrary, atom),
        requestJson: (prompt, context) => this.rateLimiter.run(() => requestMiniMaxJson({ settings: this.settings, prompt, context, fetchImpl: obsidianRequest })),
        requestStream: this.settings.useStreamingAi
          ? (prompt, context, hooks) => this.rateLimiter.run(() => requestMiniMaxStream({ settings: this.settings, prompt, context, onDelta: hooks && hooks.onDelta, onProgressText: hooks && hooks.onProgressText }))
          : null,

        onProgress: async (progress) => {
          this.assertTaskCanContinue(current);
          current.status = workflowStatus(progress.stage);
          // v1.1.8: 关键节点（batchComplete 或阶段变化）才走 setTaskProgress（写盘 + 全重渲染），
          // 其他进度回调走轻量级 refreshProgressOnly（只刷进度条 DOM + 已用时文本）
          const isKeyPoint = progress.batchComplete || progress.stage !== current.progress?.stage;
          const merged = Object.assign({}, progress, { elapsedMs: Date.now() - startedAt });
          current.progress = merged;
          if (isKeyPoint) {
            await this.setTaskProgress(current, progress.message, merged);
          } else {
            this.refreshProgressOnly(current);
          }
        },
        onArtifact: (name, value) => this.persistArtifact(current, name, value)
      });
      } finally {
        clearInterval(heartbeat);
        diag('heartbeat.stop', { sourcePath: current.source_path, totalElapsedMs: Date.now() - startedAt });
      }

      const summaryLink = current.artifacts.summary_markdown
        ? `[[${current.artifacts.summary_markdown.replace(/\.md$/i, '')}]]`
        : `[[${workflow.summary.document_title}]]`;
      for (const card of workflow.accepted) card.parent_summary = summaryLink;
      for (const item of workflow.review) {
        item.atom.source.parent_summary = summaryLink;
        item.proposed_card.parent_summary = summaryLink;
      }

      // v2.9.0: 邮件 ↔ 附件双向链接注入（writeAcceptedCard 负责落笔）。
      //   邮件任务：卡片带「关联附件」链接列表；附件任务：卡片带「来源邮件」回链。
      const emailAttachments = parsePackage.metadata && Array.isArray(parsePackage.metadata.emailAttachments)
        ? parsePackage.metadata.emailAttachments : [];
      const attachmentLinks = emailAttachments
        .map((item) => (item && item.filename ? `[[${item.filename}]]` : ''))
        .filter(Boolean);
      const parentSourceLink = current.parent_source_path
        ? `[[${normalizeVaultPath(current.parent_source_path).split('/').pop().replace(/\.[^.]+$/, '')}]]`
        : '';
      if (attachmentLinks.length || parentSourceLink) {
        for (const card of workflow.accepted) {
          if (attachmentLinks.length) card.attachment_links = attachmentLinks;
          if (parentSourceLink) card.parent_source_link = parentSourceLink;
        }
        for (const item of workflow.review) {
          if (attachmentLinks.length) item.proposed_card.attachment_links = attachmentLinks;
          if (parentSourceLink) item.proposed_card.parent_source_link = parentSourceLink;
        }
      }

      current.status = 'writing';
      await this.setTaskProgress(current, `正在写入 ${workflow.accepted.length} 张可信知识卡片`, {
        stage: 'writing', cardCount: workflow.accepted.length, reviewCount: workflow.review.length, elapsedMs: Date.now() - startedAt
      });
      for (const card of workflow.accepted) {
        await this.writeAcceptedCard(current, card, workflow.route);
        current.written_card_ids.push(card.card_id);
      }
      if (workflow.review.length) {
        await this.persistArtifact(current, 'review', { version: '1.1', task_id: current.task_id, items: workflow.review });
        current.review_atom_ids = workflow.review.map((item) => item.atom_id);
      }
      if (!workflow.accepted.length && !workflow.review.length) {
        // v2.8.1: 错误信息带上下文计数，告诉用户去 diag.log 看哪几个事件
        const pointCount = (workflow.summary && Array.isArray(workflow.summary.key_points)) ? workflow.summary.key_points.length : 0;
        const atomCount = (workflow.atomResult && Array.isArray(workflow.atomResult.atoms)) ? workflow.atomResult.atoms.length : 0;
        throw new Error(`MiniMax 未生成任何可用知识原子（总结含 ${pointCount} 个知识点，原子化产出 ${atomCount} 个原子）。请查看诊断日志中的 summary.merged / atomization.batch / atomization.normalize 事件定位丢点位置后重试。`);
      }

      current.status = workflow.review.length ? 'needs_review' : 'written';
      current.updated_at = new Date().toISOString();
      current.progress = {
        stage: 'complete',
        message: `处理完成：自动入库 ${workflow.accepted.length} 张，异常 ${workflow.review.length} 项`,
        elapsedMs: Date.now() - startedAt,
        at: current.updated_at
      };
      // v1.4 (M-07): 记录 AI 截断标志，dashboard 顶部 banner 与 Notice 会消费
      if (workflow.truncated) {
        current.truncated = true;
        current.truncated_completed = workflow.truncatedCompleted || 0;
        new Notice(`⚠️ AI 输出超过 8192 token 上限被截断。已成功 ${current.truncated_completed} 个原子。dashboard 顶部有警告。`);
        diag('workflow.truncated', { sourcePath: current.source_path, completed: current.truncated_completed });
      }
      await this.writeTaskLog(current);
      await this.saveTasks(upsertTask(await this.loadTasks(), current));
      this.sessionStats.processed += 1;
      this.sessionStats.review += workflow.review.length;
      this.sessionStats.written += workflow.accepted.length;
      this.sessionStats.lastMessage = current.progress.message;
      new Notice(current.progress.message);
    } catch (error) {
      if (error.code === 'TASK_PAUSED' || error.code === 'TASK_CANCELLED') {
        current.status = error.code === 'TASK_PAUSED' ? 'paused' : 'cancelled';
        current.updated_at = new Date().toISOString();
        current.progress = { stage: current.status, message: error.message, at: current.updated_at, elapsedMs: Date.now() - startedAt };
        await this.saveTasks(upsertTask(await this.loadTasks(), current));
        this.cancelRequestedTaskId = '';
        return;
      }
      current.status = 'failed';
      current.updated_at = new Date().toISOString();
      current.errors = [...(current.errors || []), { stage: current.progress?.stage || 'process', message: sanitizeSecret(error.message), at: current.updated_at }];
      await this.writeTaskLog(current);
      await this.saveTasks(upsertTask(await this.loadTasks(), current));
      this.sessionStats.failed += 1;
      this.sessionStats.lastMessage = `处理失败：${current.source_path}`;
      // v1.1.6: 诊断日志 + 更明确的 Notice（带阶段名），避免错误被截图渲染误导
      diag('processTask.failed', {
        sourcePath: current.source_path,
        stage: current.progress?.stage,
        errorClass: error && error.constructor ? error.constructor.name : typeof error,
        errorMessage: String(error && error.message || error)
      });
      new Notice(`工程知识切片处理失败（${current.progress?.stage || 'process'}）：${sanitizeSecret(error.message)}`);
    } finally {
      await this.refreshViews();
    }
  }

  async processTaskLegacy(task) {
    const tasks = await this.loadTasks();
    const current = tasks.find((item) => item.taskId === task.taskId) || task;
    try {
      this.sessionStats.current = current.sourcePath;
      current.errors = [];
      current.draftFiles = [];
      current.writtenFiles = [];
      await this.setTaskProgress(current, '准备处理源文件', { stage: 'start' });
      if (!isProcessableSource(current.sourcePath)) {
        current.status = detectSourceType(current.sourcePath) === 'pdf' ? 'needs_ocr' : 'unsupported_media';
        current.updatedAt = new Date().toISOString();
        await this.saveTasks(upsertTask(tasks, current));
        this.sessionStats.skipped += 1;
        this.sessionStats.lastMessage = `已跳过暂不支持文件：${current.sourcePath}`;
        await this.refreshViews();
        return;
      }

      current.status = 'extracting';
      await this.setTaskProgress(current, '正在抽取文本', { stage: 'extracting' });

      const file = this.app.vault.getAbstractFileByPath(current.sourcePath);
      if (!(file instanceof TFile)) throw new Error(`Source file not found: ${current.sourcePath}`);
      const buffer = Buffer.from(await this.app.vault.readBinary(file));
      const extracted = await extractTextFromBuffer(current.sourcePath, buffer, {
        pdfExtractor: await this.getPdfExtractorConfig(current)
      });
      if (extracted.status !== 'ok') {
        current.status = extracted.status;
        current.errors = [{ stage: 'extract', message: extracted.message || extracted.status, at: new Date().toISOString() }];
        await this.writeTaskLog(current);
        await this.saveTasks(upsertTask(await this.loadTasks(), current));
        if (extracted.status === 'failed') this.sessionStats.failed += 1;
        else this.sessionStats.review += 1;
        this.sessionStats.lastMessage = `抽取失败或需要人工处理：${current.sourcePath}`;
        await this.refreshViews();
        return;
      }

      current.status = 'slicing';
      await this.setTaskProgress(current, '正在准备 AI 切片提示词', { stage: 'slicing' });
      const tagLibraryText = await this.loadTagLibraryText();
      const library = parseTagLibrary(tagLibraryText);
      let cards = null;
      try {
        cards = await draftCardsWithProvider({
          settings: this.settings,
          task: current,
          extracted,
          library,
          tagLibraryText,
          onProgress: (progress) => this.setTaskProgress(current, progress.message, progress)
        });
      } catch (providerError) {
        current.errors = [...(current.errors || []), {
          stage: 'ai-provider',
          message: sanitizeSecret(providerError.message),
          settings: sanitizeSettingsForLog(this.settings),
          at: new Date().toISOString()
        }];
      }
      if (!cards || !cards.length) {
        current.status = 'failed';
        current.errors = [...(current.errors || []), {
          stage: 'ai-slicing',
          message: 'AI 未生成任何知识卡片。请检查 AI Key、模型、提示词或源文件可读性；插件不会再使用本地规则生成单张粗略卡片。',
          at: new Date().toISOString()
        }];
        current.updatedAt = new Date().toISOString();
        await this.writeTaskLog(current);
        await this.saveTasks(upsertTask(await this.loadTasks(), current));
        this.sessionStats.failed += 1;
        this.sessionStats.lastMessage = `AI 未生成卡片：${current.sourcePath}`;
        new Notice('AI 未生成知识卡片，已停止本文件处理。');
        await this.refreshViews();
        return;
      }
      const draftFiles = [];
      const writtenFiles = [];
      await this.setTaskProgress(current, `正在写入 ${cards.length} 张知识卡片`, { stage: 'writing', cardCount: cards.length });
      for (const card of cards) {
        if (!card.Map_Index || card.Map_Index === '[[MOC_待分类]]') {
          card.Map_Index = suggestMapIndex(library, card.Category, card.TagL1, card.TagL2);
        }
        const validation = validateCard(library, card);
        if (!validation.valid) {
          card.Status = '#status/needs_fix';
          card.Validation_Errors = validation.errors;
        }
        const markdown = renderKnowledgeCard(card);
        const question = this.isQuestionableCard(card, validation);
        if (question) {
          const draftPath = `${this.settings.draftPath}/${safeCardFileName(card.Title, current.sourceHash)}`;
          await writeUnique(this.app, draftPath, markdown);
          draftFiles.push(draftPath);
        } else {
          const approved = approveMarkdownStatus(markdown, approvedStatus(library));
          const outputPath = await writeUnique(this.app, cardOutputPath(this.settings, card, safeCardFileName(card.Title, current.sourceHash)), approved);
          writtenFiles.push(outputPath);
          await this.ensureMocForDraft(approved);
        }
      }

      current.status = draftFiles.length ? 'needs_review' : 'written';
      current.draftFiles = draftFiles;
      current.writtenFiles = writtenFiles;
      current.updatedAt = new Date().toISOString();
      delete current.progress;
      await this.writeTaskLog(current);
      await this.saveTasks(upsertTask(await this.loadTasks(), current));
      this.sessionStats.processed += 1;
      this.sessionStats.review += draftFiles.length;
      this.sessionStats.written += writtenFiles.length;
      this.sessionStats.lastMessage = `已入库 ${writtenFiles.length} 张，待审核 ${draftFiles.length} 张：${current.sourcePath}`;
      new Notice(`可信卡片已入库 ${writtenFiles.length} 张；疑问项 ${draftFiles.length} 张进入审核台。`);
    } catch (error) {
      current.status = 'failed';
      current.updatedAt = new Date().toISOString();
      current.errors = [{ stage: 'process', message: sanitizeSecret(error.message), at: new Date().toISOString() }];
      await this.writeTaskLog(current);
      await this.saveTasks(upsertTask(await this.loadTasks(), current));
      this.sessionStats.failed += 1;
      this.sessionStats.lastMessage = `处理失败：${current.sourcePath}`;
      new Notice(`工程知识切片处理失败：${error.message}`);
    } finally {
      await this.refreshViews();
    }
  }

  async loadComponentText(relativePath) {
    const path = normalizeVaultPath(`${this.settings.componentPackPath}/${relativePath}`);
    const file = this.app.vault.getAbstractFileByPath(path);
    if (!(file instanceof TFile)) throw new Error(`组件包文件不存在：${path}`);
    return this.app.vault.read(file);
  }

  async loadComponentJson(relativePath) {
    const text = await this.loadComponentText(relativePath);
    try { return JSON.parse(text); } catch (error) { throw new Error(`${relativePath} 不是有效 JSON：${error.message}`); }
  }

  async loadRuntimeContracts() {
    return {
      folderMap: await this.loadComponentJson('folder-map.json'),
      schemas: {
        classification: await this.loadComponentJson('schemas/classification.schema.json'),
        summary: await this.loadComponentJson('schemas/structured-summary.schema.json'),
        atoms: await this.loadComponentJson('schemas/knowledge-atoms.schema.json')
      },
      prompts: {
        classifier: await this.loadComponentText('提示词/00-类型判定.md'),
        summaryBase: await this.loadComponentText('提示词/01-结构化总结-基础.md'),
        atoms: await this.loadComponentText('提示词/99-知识原子生成.md'),
        typeMapping: await this.loadComponentText('模板/Type Mapping.md'),
        tagLibrary: await this.loadComponentText('Tag_Library.md')
      }
    };
  }

  async loadArtifact(task, name) {
    const path = task.artifacts && task.artifacts[name];
    if (!path) return null;
    const file = this.app.vault.getAbstractFileByPath(path);
    if (!(file instanceof TFile)) return null;
    try { return JSON.parse(await this.app.vault.read(file)); } catch { return null; }
  }

  async persistArtifact(task, name, value) {
    const path = normalizeVaultPath(`${this.settings.artifactsPath}/${task.run_id}/${name}.json`);
    await writeFile(this.app, path, JSON.stringify(value, null, 2));
    task.artifacts = Object.assign({}, task.artifacts || {}, { [name]: path });
    if (name === 'summary') {
      const markdownPath = normalizeVaultPath(`${this.settings.artifactsPath}/${task.run_id}/summary.md`);
      await writeFile(this.app, markdownPath, renderStructuredSummary(value, `[[${task.source_path}]]`));
      task.artifacts.summary_markdown = markdownPath;
    }
    task.updated_at = new Date().toISOString();
    await this.saveTasks(upsertTask(await this.loadTasks(), task));
    return path;
  }

  // v2.9.0: 写入二进制附件。writeUnique 只服务 .md（冲突时加 -N.md 后缀），
  //   附件需要按原扩展名避让冲突，且走 createBinary 保证字节完整。
  async writeUniqueBinary(targetPath, buffer) {
    const normalized = normalizeVaultPath(targetPath);
    const folder = normalized.split('/').slice(0, -1).join('/');
    const fileName = normalized.split('/').pop();
    const dot = fileName.lastIndexOf('.');
    const stem = dot > 0 ? fileName.slice(0, dot) : fileName;
    const ext = dot > 0 ? fileName.slice(dot) : '';
    await ensureFolder(this.app, folder);
    let candidate = normalized;
    let index = 1;
    while (this.app.vault.getAbstractFileByPath(candidate)) {
      candidate = `${folder}/${stem}-${index}${ext}`;
      index += 1;
    }
    const arrayBuffer = buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
    if (typeof this.app.vault.createBinary !== 'function') {
      throw new Error('当前 Obsidian 版本不支持写入二进制附件（缺少 vault.createBinary）。');
    }
    await this.app.vault.createBinary(candidate, arrayBuffer);
    return candidate;
  }

  // v2.9.0: 邮件附件保存 + 入队切片。
  //   保存位置：<邮件所在目录>/_attachments/<邮件名>/ 下，仍在 intake 根内，
  //   重新扫描时按 source_hash 天然去重；可处理类型的附件立即建任务入队，
  //   autoProcessQueue 同轮循环即接管，任务记录携带父邮件链接供双向链接使用。
  async saveEmailAttachments(task, attachments) {
    const sourcePath = normalizeVaultPath(task.source_path || '');
    const dir = sourcePath.includes('/') ? sourcePath.slice(0, sourcePath.lastIndexOf('/')) : '';
    const mailBaseName = (sourcePath.split('/').pop() || 'email').replace(/\.[^.]+$/, '');
    const tasks = await this.loadTasks();
    const saved = [];
    let enqueued = 0;
    for (const attachment of attachments || []) {
      if (!attachment || !attachment.data || !attachment.data.length) continue;
      const fileName = sanitizeAttachmentFileName(attachment.filename || `attachment-${saved.length + 1}`);
      const targetPath = `${dir ? dir + '/' : ''}_attachments/${mailBaseName}/${fileName}`;
      const writtenPath = await this.writeUniqueBinary(targetPath, attachment.data);
      saved.push({
        filename: writtenPath.split('/').pop(),
        path: writtenPath,
        size: attachment.data.length,
        contentType: attachment.contentType || ''
      });
      if (!isProcessableSource(writtenPath)) continue;
      const hash = sourceHash(attachment.data);
      const library = libraryForPath(writtenPath, this.settings);
      const existing = tasks.find((item) => item.source_hash === hash && item.library === library);
      if (existing) continue;
      const attachmentTask = createTaskRecord({
        sourcePath: writtenPath,
        sourceHash: hash,
        sourceType: detectSourceType(writtenPath),
        library,
        versions: runtimeVersions(this.settings)
      });
      attachmentTask.parent_task_id = task.task_id;
      attachmentTask.parent_source_path = task.source_path;
      tasks.push(attachmentTask);
      enqueued += 1;
    }
    if (enqueued) await this.saveTasks(tasks);
    diag('email.attachments', {
      sourcePath: task.source_path,
      count: (attachments || []).length,
      saved: saved.length,
      enqueued,
      files: saved.map((item) => item.path).slice(0, 10)
    });
    return saved;
  }

  async loadExistingFingerprints(excludeSourceHash = '') {
    const roots = [this.settings.bidOutputPath, this.settings.businessOutputPath].map(normalizeVaultPath);
    const fingerprints = [];
    for (const file of this.app.vault.getMarkdownFiles()) {
      if (!roots.some((root) => file.path.startsWith(`${root}/`))) continue;
      const markdown = await this.app.vault.cachedRead(file);
      if (excludeSourceHash && readFrontmatterValue(markdown, 'source_hash') === excludeSourceHash) continue;
      const value = readFrontmatterValue(markdown, 'atom_fingerprint');
      if (value) fingerprints.push(value);
    }
    return fingerprints;
  }

  async loadExistingCards(excludeSourceHash = '') {
    const roots = [this.settings.bidOutputPath, this.settings.businessOutputPath].map(normalizeVaultPath);
    const cards = [];
    for (const file of this.app.vault.getMarkdownFiles()) {
      if (!roots.some((root) => file.path.startsWith(`${root}/`)) || file.basename === '_索引') continue;
      const markdown = await this.app.vault.cachedRead(file);
      const source = readFrontmatterValue(markdown, 'source_hash');
      if (excludeSourceHash && source === excludeSourceHash) continue;
      const cardId = readFrontmatterValue(markdown, 'card_id');
      if (!cardId) continue;
      cards.push({
        card_id: cardId,
        atom_fingerprint: readFrontmatterValue(markdown, 'atom_fingerprint'),
        title: readFrontmatterValue(markdown, 'title') || getMarkdownTitle(markdown),
        Category: readFrontmatterValue(markdown, 'Category'),
        TagL1: readFrontmatterValue(markdown, 'TagL1'),
        TagL2: readFrontmatterValue(markdown, 'TagL2'),
        path: file.path,
        text: markdown.slice(0, 3000)
      });
    }
    return cards;
  }

  async writeAcceptedCard(task, card, route) {
    const path = normalizeVaultPath(`${route.output_folder}/${cardFileName(card)}`);
    const existing = this.app.vault.getAbstractFileByPath(path);
    const previous = existing instanceof TFile ? await this.app.vault.read(existing) : null;
    let markdown = renderKnowledgeCard(card);
    // v2.9.0: 邮件 ↔ 附件双向链接正文节（frontmatter 结构保持不变）。
    //   附件卡 → 来源邮件；邮件卡 → 关联附件清单。附件文件→卡片方向由
    //   Obsidian 反向链接面板天然提供（二进制文件无法内嵌链接）。
    const attachmentLinks = Array.isArray(card.attachment_links) ? card.attachment_links.filter(Boolean) : [];
    if (attachmentLinks.length) {
      markdown += `\n## 关联附件\n\n${attachmentLinks.map((link) => `- ${link}`).join('\n')}\n`;
    }
    if (card.parent_source_link) {
      markdown += `\n> 来源邮件：${card.parent_source_link}\n`;
    }
    await writeFile(this.app, path, markdown);
    await this.appendRollback({
      task_id: task.task_id,
      card_id: card.card_id,
      written_path: path,
      previous_content: previous,
      written_at: new Date().toISOString()
    });
    await this.ensureFolderIndex(route);
    return path;
  }

  async ensureFolderIndex(route) {
    const path = folderIndexPath(route);
    if (this.app.vault.getAbstractFileByPath(path)) return path;
    return writeFile(this.app, path, createFolderIndexMarkdown(route));
  }

  async applyReviewGroup(taskId, groupId, action, correction = {}) {
    const tasks = await this.loadTasks();
    const task = tasks.find((item) => item.task_id === taskId);
    if (!task) throw new Error('未找到审核任务');
    const artifact = await this.loadArtifact(task, 'review');
    if (!artifact) throw new Error('未找到审核产物');
    const group = groupReviewItems(artifact.items).find((item) => item.group_id === groupId);
    if (!group) throw new Error('未找到审核分组');

    if (action === 'regenerate_group') {
      delete task.artifacts.atoms;
      delete task.artifacts.review;
      task.review_atom_ids = [];
      task.status = 'queued';
      task.updated_at = new Date().toISOString();
      await this.saveTasks(upsertTask(tasks, task));
      await this.processTask(task);
      return;
    }

    const selectedIds = new Set(group.items.map((item) => item.atom_id));
    // v1.4 (M-05): apply_correction 必须先过白名单校验
    let safeCorrection = correction;
    if (action === 'apply_correction') {
      safeCorrection = validateCorrection(correction);
    }
    const changed = applyBatchAction(group.items, action, safeCorrection);
    const tagLibrary = await this.loadTagLibrary();
    const folderMap = (await this.loadRuntimeContracts()).folderMap;
    const unresolved = [];
    for (const item of changed) {
      if (item.status === 'discarded') continue;
      if (item.status === 'corrected' && !validateAtomLabels(tagLibrary, item.atom)) {
        item.status = 'pending';
        item.reasons = ['批量修正后仍未通过标签字典校验'];
        unresolved.push(item);
        continue;
      }
      const route = resolveFixedRoute(folderMap, item.atom);
      const card = Object.assign({}, item.proposed_card, {
        Category: item.atom.Category,
        TagL1: item.atom.TagL1,
        TagL2: item.atom.TagL2,
        Info_Type: item.atom.Info_Type,
        Event_Type: item.atom.Event_Type,
        output_folder: route.output_folder,
        status: 'confirmed'
      });
      await this.writeAcceptedCard(task, card, route);
      if (!task.written_card_ids.includes(card.card_id)) task.written_card_ids.push(card.card_id);
    }

    const untouched = artifact.items.filter((item) => !selectedIds.has(item.atom_id));
    artifact.items = [...untouched, ...unresolved];
    await this.persistArtifact(task, 'review', artifact);
    task.review_atom_ids = artifact.items.map((item) => item.atom_id);
    task.status = artifact.items.length ? 'needs_review' : 'written';
    task.updated_at = new Date().toISOString();
    await this.saveTasks(upsertTask(await this.loadTasks(), task));
    new Notice(`批量审核完成：处理 ${group.items.length} 项，剩余 ${artifact.items.length} 项`);
    await this.refreshViews();
  }

  async approveDraft(taskId, draftPath) {
    const file = this.app.vault.getAbstractFileByPath(draftPath);
    if (!(file instanceof TFile)) throw new Error(`未找到草稿：${draftPath}`);
    const draft = await this.app.vault.read(file);
    const library = await this.loadTagLibrary();
    const finalStatus = approvedStatus(library);
    const finalCard = cardFromMarkdown(draft);
    finalCard.Status = finalStatus;
    const validation = validateCard(library, finalCard);
    if (!validation.valid) {
      new Notice(`草稿标签或字段未通过校验，不能入库：${validation.errors.join('；')}`);
      await this.app.workspace.openLinkText(draftPath, '', false);
      return;
    }
    const approved = approveMarkdownStatus(draft, finalStatus);
    const title = getMarkdownTitle(draft) || file.basename;
    const routeCard = {
      Category: readFrontmatterValue(approved, 'Category'),
      TagL1: readFrontmatterValue(approved, 'TagL1'),
      TagL2: readFrontmatterValue(approved, 'TagL2')
    };
    const outputPath = await writeUnique(this.app, cardOutputPath(this.settings, routeCard, safeCardFileName(title, Date.now().toString(16))), approved);

    const tasks = await this.loadTasks();
    const task = tasks.find((item) => item.task_id === taskId);
    if (task) {
      task.draftFiles = (task.draftFiles || []).filter((item) => item !== draftPath);
      task.status = task.draftFiles.length ? 'needs_review' : 'written';
      task.updatedAt = new Date().toISOString();
      task.writtenFiles = [...(task.writtenFiles || []), outputPath];
    }
    await this.saveTasks(tasks);
    await this.appendRollback({ taskId, draftPath, writtenPath: outputPath, approvedAt: new Date().toISOString() });
    await this.ensureMocForDraft(approved);
    new Notice(`已批准入库：${outputPath}`);
    await this.refreshViews();
  }

  isQuestionableCard(card, validation) {
    if (!validation.valid) return true;
    if (card.Status === '#status/needs_fix' || card.Status === '#status/uncategorized') return true;
    if (!card.Map_Index || card.Map_Index === '[[MOC_待分类]]') return true;
    const threshold = Number(this.settings.autoApproveConfidenceThreshold || DEFAULT_SETTINGS.autoApproveConfidenceThreshold || 0.82);
    if (typeof card.Confidence !== 'number' || card.Confidence < threshold) return true;
    if (!card.Source_Excerpt || card.Source_Excerpt.length < 20) return true;
    return false;
  }

  async ensureMocForDraft(markdown) {
    const mapIndex = readFrontmatterValue(markdown, 'Map_Index');
    const category = readFrontmatterValue(markdown, 'Category');
    const tagL1 = readFrontmatterValue(markdown, 'TagL1');
    const tagL2 = readFrontmatterValue(markdown, 'TagL2');
    if (!mapIndex || !category || !tagL1 || !tagL2) return;
    const path = mapIndexToPath(mapIndex, this.settings.outputPath);
    if (this.app.vault.getAbstractFileByPath(path)) return;
    const title = path.split('/').pop().replace(/\.md$/, '');
    await writeUnique(this.app, path, createMocMarkdown({ title, category, tagL1, tagL2, outputPath: this.settings.outputPath }));
  }

  async retryTask(taskId) {
    const tasks = await this.loadTasks();
    const task = tasks.find((item) => item.task_id === taskId);
    if (!task) return;
    task.status = 'queued';
    task.errors = [];
    task.updated_at = new Date().toISOString();
    await this.saveTasks(tasks);
    // processTask 开头会重读账本，确保 queued 状态已对该读取可见。
    await this.flushSaveTasksImmediate();
    await this.processTask(task);
  }

  async skipTask(taskId) {
    const tasks = await this.loadTasks();
    const task = tasks.find((item) => item.task_id === taskId);
    if (!task) return;
    task.status = 'skipped';
    task.updated_at = new Date().toISOString();
    await this.saveTasks(tasks);
    await this.refreshViews();
  }

  // v2.9.0: 审核台失败区块「移除」按钮——从账本删除该记录（源文件不受影响，
  //   下次扫描可重新发现）。失败记录本来也会在重启时被 sessionStartupCleanup 清除。
  async dismissTask(taskId) {
    const tasks = await this.loadTasks();
    const next = tasks.filter((item) => item.task_id !== taskId);
    if (next.length === tasks.length) return;
    await this.saveTasks(next);
    await this.refreshViews();
  }

  async loadTagLibrary() {
    return parseTagLibrary(await this.loadTagLibraryText());
  }

  async loadTagLibraryText() {
    const primaryCandidates = [
      `${this.settings.componentPackPath}/Tag_Library.md`,
      `${this.settings.componentPackPath}/模板/Type Mapping.md`
    ];
    const sections = [];
    for (const candidate of primaryCandidates) {
      const file = this.app.vault.getAbstractFileByPath(candidate);
      if (file instanceof TFile) sections.push(await this.app.vault.read(file));
    }
    if (sections.length) return sections.join('\n\n');
    const fallback = this.app.vault.getAbstractFileByPath('docs/tag-library-full-lifecycle-draft.md');
    return fallback instanceof TFile ? this.app.vault.read(fallback) : '';
  }

  async loadTasks() {
    const path = tasksPath(this.settings);
    const file = this.app.vault.getAbstractFileByPath(path);
    if (!(file instanceof TFile)) return [];
    try {
      const parsed = JSON.parse(await this.app.vault.read(file));
      return migrateTaskLedgerV3(Array.isArray(parsed) ? parsed : [], runtimeVersions(this.settings));
    } catch {
      return [];
    }
  }

  // v1.6 (M-04): 写盘防抖。setTaskProgress / upsertTask 高频调用 saveTasks，
  //              一次 12 批次原子化可能触发 30+ 次磁盘 IO。改为 500ms 防抖，
  //              关键节点（status 转换 / 错误落库 / onunload）走 flushSaveTasksImmediate 立即落。
  async saveTasks(tasks) {
    this._pendingSaveTasks = tasks;
    this._pendingSaveDirty = true;
    if (this._saveTasksTimer) clearTimeout(this._saveTasksTimer);
    this._saveTasksTimer = setTimeout(() => {
      // 异步落盘；调用方 await 的话可以走 flushSaveTasksImmediate
      this._flushSaveTasks().catch((e) => {
        try { diag('tasks.save.flush.error', { message: String(e && e.message || e) }); } catch (_) {}
      });
    }, 500);
  }

  // v1.6 (M-04): 立即落盘（绕过防抖）。用在 status 转换 / 错误落库 / onunload 等关键节点。
  async flushSaveTasksImmediate() {
    if (this._saveTasksTimer) { clearTimeout(this._saveTasksTimer); this._saveTasksTimer = null; }
    await this._flushSaveTasks();
  }

  async _flushSaveTasks() {
    if (!this._pendingSaveDirty) return;
    const tasks = this._pendingSaveTasks;
    this._pendingSaveTasks = null;
    this._pendingSaveDirty = false;
    await this.ensureFolders();
    const target = tasksPath(this.settings);
    // v1.4 (M-11): 写盘前备份上一版 tasks.json，便于迁移出错时回退。
    // v2.9.3: 改为单一滚动备份。高频进度落盘若每次创建时间戳文件，
    //         会在 vault / 同步盘持续制造目录项与同步 IO，而恢复只需要上一版。
    if (this.settings.backupTasksOnSave !== false) {
      try {
        const existing = this.app.vault.getAbstractFileByPath(target);
        if (existing instanceof TFile) {
          const backupPath = target.replace(/\.json$/i, '.bak.json');
          const content = await this.app.vault.read(existing);
          await writeFile(this.app, backupPath, content);
        }
      } catch (e) {
        try { diag('tasks.backup.error', { message: String(e && e.message || e) }); } catch (_) {}
      }
    }
    await writeFile(this.app, target, JSON.stringify(tasks, null, 2));
  }

  // v1.4 (M-11): 手动把所有 paused 任务重新入队（dashboard 按钮触发）
  async restorePausedTasks() {
    const tasks = await this.loadTasks();
    let restored = 0;
    for (const task of tasks) {
      if (task.status !== 'paused') continue;
      task.status = 'queued';
      task.errors = (task.errors || []).filter((e) => e?.stage !== 'stale-processing');
      task.updated_at = new Date().toISOString();
      restored += 1;
    }
    if (restored > 0) await this.saveTasks(tasks);
    await this.refreshViews();
    return restored;
  }

  // v2.9.0: 会话级失败缓存 + 启动续传。每次启动执行一次：
  //   1) 失败任务只在上一次会话内展示（审核工作台），重启后从账本清除——
  //      因此 dashboard 的「失败」统计与审核台失败块天然只反映本次会话；
  //   2) 上次关闭时处于解析/总结/原子化/写入/排队中的任务，弹窗询问
  //      继续（重新入队，artifact 缓存自动断点续传）或放弃（移除记录）。
  async sessionStartupCleanup() {
    const tasks = await this.loadTasks();
    const failedTasks = tasks.filter((task) => task.status === 'failed');
    if (failedTasks.length) {
      const failedIds = new Set(failedTasks.map((task) => task.task_id));
      await this.saveTasks(tasks.filter((task) => !failedIds.has(task.task_id)));
      diag('startup.failedCleared', {
        count: failedTasks.length,
        files: failedTasks.slice(0, 10).map((task) => task.source_path)
      });
    }
    const interrupted = tasks.filter((task) => PROCESSING_STATUSES.has(task.status)
      || task.status === 'parsed' || task.status === 'queued');
    if (!interrupted.length) return;
    diag('startup.interruptedFound', {
      count: interrupted.length,
      statuses: interrupted.map((task) => task.status).slice(0, 20)
    });
    const interruptedIds = new Set(interrupted.map((task) => task.task_id));
    new InterruptedTasksModal(this.app, interrupted, {
      onResume: async () => {
        const latest = await this.loadTasks();
        for (const task of latest) {
          if (!interruptedIds.has(task.task_id)) continue;
          task.status = 'queued';
          task.updated_at = new Date().toISOString();
        }
        await this.saveTasks(latest);
        await this.refreshViews();
        await this.autoProcessQueue(false);
      },
      onDiscard: async () => {
        const latest = await this.loadTasks();
        await this.saveTasks(latest.filter((task) => !interruptedIds.has(task.task_id)));
        await this.refreshViews();
        diag('startup.interruptedDiscarded', { count: interrupted.length });
      }
    }).open();
  }

  async setTaskProgress(task, message, details = {}) {
    const now = new Date().toISOString();
    task.updated_at = now;
    task.progress = Object.assign({}, details, {
      message,
      at: now
    });
    this.sessionStats.current = task.source_path;
    this.sessionStats.lastMessage = message;
    await this.saveTasks(upsertTask(await this.loadTasks(), task));
    await this.refreshViews();
  }

  async recoverStaleProcessingTasks(tasks) {
    const minutes = Number(this.settings.staleProcessingMinutes || DEFAULT_SETTINGS.staleProcessingMinutes || 20);
    const staleMs = Math.max(5, minutes) * 60 * 1000;
    const now = Date.now();
    let changed = false;
    for (const task of tasks) {
      if (!PROCESSING_STATUSES.has(task.status)) continue;
      const updatedAt = Date.parse(task.updated_at || task.progress?.at || '');
      if (!updatedAt || now - updatedAt < staleMs) continue;
      // v1.4 (M-11): 改 'failed' 为 'paused'，避免被一刀切失败。
      //               用户可在 dashboard 点"恢复暂停任务"批量重排队。
      task.status = 'paused';
      task.updated_at = new Date().toISOString();
      task.errors = [...(task.errors || []), {
        stage: 'stale-processing',
        message: `任务在 ${minutes} 分钟内没有进度更新，已判定为中断并暂停。可在 dashboard 点"恢复暂停任务"重排队。`,
        at: task.updated_at
      }];
      task.progress = {
        stage: 'stale-processing',
        message: '任务长时间没有进度更新，已暂停等待恢复',
        at: task.updated_at
      };
      changed = true;
    }
    if (changed) await this.saveTasks(tasks);
    return tasks;
  }

  async clearPluginCache() {
    await this.ensureFolders();
    await deleteFolderContents(this.app, this.settings.artifactsPath);
    this.sessionStats = { scanned: 0, processed: 0, written: 0, review: 0, failed: 0, skipped: 0, current: '', lastMessage: '缓存已清空，等待重新扫描' };
    await this.ensureFolders();
    await this.refreshViews();
    new Notice('工程知识切片缓存已清空。源文件和已入库 wiki 卡片未删除。');
  }

  async writeTaskLog(task) {
    await this.ensureFolders();
    await writeFile(this.app, `${this.settings.logPath}/${task.task_id}.json`, JSON.stringify(task, null, 2));
  }

  async getPdfExtractorConfig(task = null) {
    return {
      enabled: true,
      order: 'mineru-api,paddleocr-api',
      // v2.8.1: 设置开关常开，或本次会话在确认弹窗点过"确认上传"，都视为已授权
      allowExternalUpload: this.settings.pdfAllowExternalUpload === true || eksSessionUploadApproved(),
      // v1.3: 上传前是否弹窗二次确认（默认开启）
      confirmUploads: this.settings.confirmUploads !== false,
      timeoutMs: Number(this.settings.pdfExternalTimeoutMs || 300000),
      pollIntervalMs: Number(this.settings.pdfApiPollIntervalMs || 5000),
      mineruApiKey: this.settings.pdfMineruApiKey || '',
      mineruApiEndpoint: this.settings.pdfMineruApiEndpoint || 'https://mineru.net/api/v4',
      mineruApiModel: this.settings.pdfMineruApiModel || 'vlm',
      mineruApiLanguage: this.settings.pdfMineruApiLanguage || 'ch_server',
      paddleOcrApiKey: this.settings.pdfPaddleOcrApiKey || '',
      paddleOcrApiEndpoint: this.settings.pdfPaddleOcrApiEndpoint || 'https://paddleocr.aistudio-app.com/api/v2/ocr/jobs',
      paddleOcrApiModel: this.settings.pdfPaddleOcrApiModel || 'PaddleOCR-VL-1.6',
      requestImpl: obsidianRequest,
      fileName: task?.source_path?.split('/').pop() || 'source.pdf',
      onProgress: task ? (progress) => this.setTaskProgress(task, progress.message, progress) : undefined
    };
  }

  async getPluginFilePath(relativePath) {
    const pluginRelativePath = normalizeVaultPath(`${this.manifest.dir || `.obsidian/plugins/${this.manifest.id}`}/${relativePath}`);
    const adapter = this.app.vault.adapter;
    if (adapter && typeof adapter.getFullPath === 'function') {
      return adapter.getFullPath(pluginRelativePath);
    }
    return pluginRelativePath;
  }

  async appendRollback(entry) {
    const path = rollbackPath(this.settings);
    let rows = [];
    const file = this.app.vault.getAbstractFileByPath(path);
    if (file instanceof TFile) {
      try { rows = JSON.parse(await this.app.vault.read(file)); } catch { rows = []; }
    }
    rows.push(entry);
    await writeFile(this.app, path, JSON.stringify(rows, null, 2));
  }

  async showHistoryForFile(file) {
    const tasks = await this.loadTasks();
    const related = tasks.filter((task) => task.source_path === file.path || (task.source_aliases || []).includes(file.path));
    new Notice(related.length ? related.map((task) => `${task.task_id}: ${task.status}`).join('\n') : '该文件没有切片处理历史。');
    await this.activateView();
  }
};

// v1.2: 审核工作台的"查看异常详情"按钮打开的 Modal —— 把整组的异常原子一一展开成可滚动列表，
// 每条显示标题、ID、原因、可信度和摘要，方便人工逐条确认。注意只读，不在这里改数据。
class ReviewExceptionModal extends Modal {
  constructor(app, group, sourcePath) {
    super(app);
    this.group = group;
    this.sourcePath = sourcePath;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass('eks-review-exception-modal');
    contentEl.createEl('h2', { text: `异常详情 · ${this.group.label}` });
    contentEl.createDiv({
      cls: 'eks-task-meta',
      text: `共 ${this.group.items.length} 项 · 源文档：${this.sourcePath || '(未知)'}`
    });
    contentEl.createDiv({
      cls: 'eks-task-meta',
      text: `类别：${this.group.library || '未知库'} · ${this.group.folder_type || '未知目录'}`
    });
    if (this.group.reasons && this.group.reasons.length) {
      contentEl.createDiv({
        cls: 'eks-task-meta',
        text: `整组原因：${this.group.reasons.join('；')}`
      });
    }

    const list = contentEl.createDiv({ cls: 'eks-review-exception-list' });
    for (let index = 0; index < this.group.items.length; index += 1) {
      const item = this.group.items[index];
      const block = list.createDiv({ cls: 'eks-review-exception-item' });
      const head = block.createDiv({ cls: 'eks-review-exception-head' });
      head.createSpan({ text: `${index + 1}. `, cls: 'eks-review-exception-index' });
      head.createEl('strong', { text: item.atom?.title || item.atom_id || '(无标题)' });
      if (item.atom_id) {
        head.createSpan({ text: ` · ${item.atom_id}`, cls: 'eks-task-meta' });
      }
      const reasons = (item.reasons || []).join('；');
      if (reasons) block.createDiv({ cls: 'eks-task-meta', text: `原因：${reasons}` });
      const score = Number(item.confidence?.score || 0);
      block.createDiv({
        cls: 'eks-task-meta',
        text: `可信度：${score.toFixed(2)} (${item.confidence?.decision || 'unknown'})`
      });
      const summary = String(
        item.atom?.content?.summary
        || item.atom?.content?.executive_summary
        || item.atom?.content?.description
        || ''
      ).trim();
      if (summary) {
        const preview = summary.length > 240 ? `${summary.slice(0, 240)}…` : summary;
        block.createDiv({ cls: 'eks-task-meta', text: `摘要：${preview}` });
      }
    }

    const actions = contentEl.createDiv({ cls: 'eks-review-exception-actions' });
    actions.createEl('button', { text: '打开源文档', cls: 'mod-cta' }).addEventListener('click', async () => {
      if (!this.sourcePath) { new Notice('源文档路径未知'); return; }
      const file = this.app.vault.getAbstractFileByPath(this.sourcePath);
      if (file instanceof TFile) {
        await this.app.workspace.openLinkText(this.sourcePath, '', false);
      } else {
        new Notice(`源文档不在 vault 中：${this.sourcePath}`);
      }
    });
    actions.createEl('button', { text: '关闭' }).addEventListener('click', () => this.close());
  }
  onClose() {
    this.contentEl.empty();
  }
}

// v1.3: 上传源文件到外部解析器（MinerU / PaddleOCR）前的二次确认弹窗。
//       通过 globalThis.__eksUploadConfirm 暴露给闭包模块（external-pdf.js）调用。
class UploadConfirmModal extends Modal {
  constructor(app, payload) {
    super(app);
    this.payload = payload || {};
    this.resolved = false;
    this.confirmed = false;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass('eks-upload-confirm-modal');
    contentEl.createEl('h2', { text: '确认上传源文件到外部解析器' });
    const bytes = Number(this.payload.sizeBytes || 0);
    const sizeText = bytes > 0
      ? `${(bytes / 1024 / 1024).toFixed(2)} MB`
      : '未知大小';
    const engineText = String(this.payload.engine || 'MinerU / PaddleOCR');
    contentEl.createDiv({
      cls: 'eks-task-meta',
      text: `源文件：${this.payload.fileName || '(未知文件名)'}（${sizeText}）`
    });
    contentEl.createDiv({
      cls: 'eks-task-meta',
      text: `目标解析器：${engineText}`
    });
    contentEl.createDiv({
      cls: 'eks-task-meta',
      text: '请确认该源文件可以合法上传到云端解析服务，并已通过公司保密审批。'
    });
    const remember = contentEl.createEl('label', { cls: 'eks-upload-confirm-remember' });
    const cb = remember.createEl('input', { attr: { type: 'checkbox' } });
    remember.createSpan({ text: '本次会话不再重复询问（仍可在设置里取消）' });
    const actions = contentEl.createDiv({ cls: 'eks-upload-confirm-actions' });
    const cancelBtn = actions.createEl('button', { text: '取消上传' });
    const confirmBtn = actions.createEl('button', { text: '确认上传', cls: 'mod-cta' });
    const finish = (ok) => {
      if (this.resolved) return;
      this.resolved = true;
      this.confirmed = !!ok;
      this.remember = !!cb.checked;
      this.close();
    };
    cancelBtn.addEventListener('click', () => finish(false));
    confirmBtn.addEventListener('click', () => finish(true));
  }
  onClose() {
    this.contentEl.empty();
    if (!this.resolved) {
      // 用户点了右上角 X → 当作取消
      this.resolved = true;
      this.confirmed = false;
    }
  }
}

// v1.3: globalThis 桥接：闭包模块（external-pdf.js 等）通过该入口弹上传确认弹窗。
//       每个会话内 confirmAll=true 后不再询问；同时尊重 settings.confirmUploads。
globalThis.__eksUploadConfirm = globalThis.__eksUploadConfirm || null;
// v2.8.1: 用户在确认弹窗里点了"确认上传" → 本次会话视为已授权上传。
//   修复旧行为：弹窗确认与 runEngine 的 allowExternalUpload 门是两套独立逻辑，
//   用户点确认后 9ms 仍被"未确认允许上传源文件到外部解析 API"拒绝，只能再去设置里手动开开关。
function eksSessionUploadApproved() {
  const state = typeof globalThis.__eksDiag === 'object' && globalThis.__eksDiag && globalThis.__eksDiag.state;
  return !!(state && state.uploadApprovedThisSession);
}
function setEksUploadConfirm(plugin) {
  if (plugin && plugin.app && typeof plugin.settings === 'object') {
    globalThis.__eksUploadConfirm = async function askUploadConfirm(payload) {
      if (plugin.settings.confirmUploads === false) return true; // 设置关闭 → 跳过
      const session = (typeof globalThis.__eksDiag === 'object' && globalThis.__eksDiag.state)
        ? globalThis.__eksDiag.state
        : {};
      if (session.uploadConfirmedAll) return true; // 用户本会话已选择"不再询问"
      const modal = new UploadConfirmModal(plugin.app, payload || {});
      modal.open();
      await new Promise((resolve) => {
        // Modal 关闭后给一点事件循环时间，确保 onClose 已执行
        const prevOnClose = modal.onClose.bind(modal);
        modal.onClose = function() {
          prevOnClose();
          resolve();
        };
        // 兜底：若 onClose 路径上没 resolve，5 秒后强制 resolve
        setTimeout(resolve, 5000);
      });
      if (modal.remember) session.uploadConfirmedAll = true;
      // v2.8.1: 弹窗确认 = 本次会话授权上传（runEngine 的 allowExternalUpload 门会认这个标记）；
      //   勾选"不再询问"时持久化为 settings.pdfAllowExternalUpload = true。
      if (modal.confirmed) {
        session.uploadApprovedThisSession = true;
        if (modal.remember && plugin.settings.pdfAllowExternalUpload !== true) {
          plugin.settings.pdfAllowExternalUpload = true;
          try { await plugin.saveData(plugin.settings); } catch (_) { /* 持久化失败不影响本次上传 */ }
        }
      }
      try {
        const diag = (typeof globalThis.__eksDiag === 'object' && globalThis.__eksDiag.diag) || (() => {});
        diag('upload.confirm', {
          fileName: payload?.fileName,
          sizeBytes: payload?.sizeBytes,
          engine: payload?.engine,
          confirmed: !!modal.confirmed,
          rememberAll: !!modal.remember,
          sessionApproved: !!session.uploadApprovedThisSession
        });
      } catch (_) {}
      return !!modal.confirmed;
    };
  }
}

// v2.9.0: 启动续传询问弹窗。上次关闭时有正在处理的任务 → 询问继续/放弃。
//   继续：任务重新入队，processTask 经 artifacts 缓存自动从断点阶段往下跑；
//   放弃：从任务账本移除这些记录，保持处理概览干净（源文件仍在，可重新扫描）。
class InterruptedTasksModal extends Modal {
  constructor(app, tasks, handlers) {
    super(app);
    this.tasks = Array.isArray(tasks) ? tasks : [];
    this.handlers = handlers || {};
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass('eks-interrupted-modal');
    contentEl.createEl('h2', { text: '检测到上次未完成的处理' });
    contentEl.createDiv({
      cls: 'eks-task-meta',
      text: `上次关闭软件时有 ${this.tasks.length} 个文件正在处理。「继续处理」将从上次缓存到的步骤接着往下；「放弃」则清空这些记录，保持处理概览干净。`
    });
    const list = contentEl.createEl('ul', { cls: 'eks-interrupted-list' });
    for (const task of this.tasks.slice(0, 10)) {
      list.createEl('li', { text: `${task.source_path || '(未知文件)'}（${stageLabel(task.status)}）` });
    }
    if (this.tasks.length > 10) {
      contentEl.createDiv({ cls: 'eks-task-meta', text: `… 还有 ${this.tasks.length - 10} 个` });
    }
    const actions = contentEl.createDiv({ cls: 'eks-actions' });
    actions.createEl('button', { text: '继续处理', cls: 'mod-cta' }).addEventListener('click', async () => {
      this.close();
      try { await this.handlers.onResume(); } catch (error) { new Notice(`恢复处理失败：${error.message}`); }
    });
    actions.createEl('button', { text: '放弃，保持概览干净' }).addEventListener('click', async () => {
      this.close();
      try { await this.handlers.onDiscard(); } catch (error) { new Notice(`清理中断任务失败：${error.message}`); }
    });
  }
}

class SlicerDashboardView extends ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    this.selectedTaskIds = new Set();
  }

  getViewType() { return VIEW_TYPE_SLICER; }
  getDisplayText() { return '工程知识切片'; }
  getIcon() { return 'layers'; }

  async onOpen() {
    await this.render();
  }

  async render() {
    const container = this.containerEl.children[1];
    container.empty();
    container.addClass('eks-view');
    try {
      await this.renderContent(container);
    } catch (error) {
      console.error('工程知识切片界面渲染失败', error);
      container.createEl('h2', { text: '工程知识切片' });
      container.createDiv({ cls: 'eks-empty', text: `界面渲染失败：${error.message}` });
      const fallback = container.createDiv('eks-actions');
      button(fallback, '重新渲染', () => this.render());
      button(fallback, '打开 Obsidian 设置', () => this.plugin.openSettings());
    }
  }

  // v1.1.8: 轻量级进度更新，1 秒一次心跳用，不重建整个 dashboard DOM
  refreshProgress(task) {
    if (!task || !task.progress) return;
    const root = this.containerEl;
    // 更新进度条
    const bar = root.querySelector('.eks-progress-bar');
    if (bar) {
      const batchIndex = Number(task.progress.batchIndex) || 0;
      const batchTotal = Number(task.progress.batchTotal) || 0;
      const chunkIndex = Number(task.progress.chunkIndex) || 0;
      const chunkTotal = Number(task.progress.chunkTotal) || 0;
      if (batchTotal > 0) {
        bar.max = String(batchTotal);
        bar.value = String(batchIndex);
      } else if (chunkTotal > 0) {
        bar.max = String(chunkTotal);
        bar.value = String(chunkIndex);
      }
    }
    // 更新已用时文本
    const elapsedEl = root.querySelector('.eks-task-meta.elapsed');
    if (elapsedEl && task.progress.elapsedMs !== undefined) {
      elapsedEl.textContent = `已用时：${formatDuration(task.progress.elapsedMs)} · 最后更新：${formatLocalTime(task.progress.at)}`;
    }
    // 更新进度消息文本
    const textEl = root.querySelector('.eks-progress-text');
    if (textEl && task.progress.message) {
      textEl.textContent = task.progress.message;
    }
    // 更新 ETA
    const etaEl = root.querySelector('.eks-task-meta.eta');
    if (etaEl) {
      etaEl.textContent = computeEtaText(task.progress);
    }
  }

  async renderContent(container) {
    const tasks = await this.plugin.loadTasks();
    const counts = statusCounts(tasks);

    // v1.4 (M-07): AI 截断 dashboard 顶部 banner
    const truncatedTasks = tasks.filter((t) => t.truncated === true);
    if (truncatedTasks.length) {
      const banner = container.createDiv({ cls: 'eks-banner eks-banner-warning' });
      banner.createEl('strong', { text: `⚠️ ${truncatedTasks.length} 个任务的 AI 输出被截断（8192 token 上限）。` });
      banner.createDiv({
        cls: 'eks-task-meta',
        text: `部分文档的知识点可能未生成完整。检查后可用「重试失败任务」重新处理。`
      });
      const list = banner.createDiv({ cls: 'eks-task-meta' });
      for (const t of truncatedTasks.slice(0, 5)) {
        const item = list.createDiv();
        item.createSpan({ text: `· ${t.source_path}` });
        if (t.truncated_completed) item.createSpan({ text: ` (已生成 ${t.truncated_completed} 个原子)` });
      }
      if (truncatedTasks.length > 5) {
        list.createDiv({ text: `… 还有 ${truncatedTasks.length - 5} 个` });
      }
    }

    const overview = container.createDiv('eks-panel eks-overview');
    const header = overview.createDiv('eks-header');
    header.createEl('h3', { text: '总览' });
    const actions = header.createDiv('eks-actions');
    button(actions, '扫描并自动处理', () => this.plugin.scanSourceFiles(true));
    button(actions, '继续自动处理', () => this.plugin.autoProcessQueue(true));
    button(actions, '重试失败任务', () => this.plugin.retryFailedAndAutoProcess(true));
    // v1.4 (M-11): 恢复所有 paused 任务（recoverStaleProcessingTasks / 用户暂停 → 重新入队）
    button(actions, '恢复暂停任务', async () => {
      const restored = await this.plugin.restorePausedTasks();
      new Notice(restored > 0 ? `已恢复 ${restored} 个暂停任务到队列` : '当前没有暂停任务');
    });
    button(actions, '打开设置', () => this.plugin.openSettings());

    const stats = overview.createDiv('eks-stats');
    stat(stats, '待处理', counts.pending);
    stat(stats, '处理中', counts.processing);
    stat(stats, '异常待审核', counts.needsReview);
    stat(stats, '失败', counts.failed);
    stat(stats, '已入库卡片', counts.written);
    stat(stats, '已跳过', counts.skipped);

    const queue = container.createDiv('eks-panel eks-queue');
    queue.createEl('h3', { text: '处理概览' });
    this.renderQueue(queue, tasks);

    const review = container.createDiv('eks-panel eks-review');
    review.createEl('h3', { text: '审核工作台（仅异常）' });
    const reviewScroll = review.createDiv('eks-review-scroll');
    await this.renderReview(reviewScroll, tasks);

    const paths = container.createDiv('eks-paths');
    paths.createSpan({ text: `源文件入口：${this.plugin.settings.bidIntakePath}；${this.plugin.settings.businessIntakePath}` });
    paths.createSpan({ text: `入库输出：${this.plugin.settings.bidOutputPath}；${this.plugin.settings.businessOutputPath}` });
    paths.createSpan({ text: '目录由 folder-map.json 固定映射；Category / TagL1 / TagL2 仅用于 MOC 索引。' });
  }

  async renderContentLegacy(container) {
    const tasks = await this.plugin.loadTasks();
    const counts = statusCounts(tasks);

    const overview = container.createDiv('eks-panel eks-overview');
    const header = overview.createDiv('eks-header');
    header.createEl('h3', { text: '总览' });
    const actions = header.createDiv('eks-actions');
    button(actions, '扫描并自动处理', () => this.plugin.scanSourceFiles(true));
    button(actions, '自动处理可信卡片', () => this.plugin.autoProcessQueue(true));
    button(actions, '重试失败并处理', () => this.plugin.retryFailedAndAutoProcess(true));
    button(actions, '打开设置', () => this.plugin.openSettings());

    const stats = overview.createDiv('eks-stats');
    stat(stats, '待处理', counts.pending);
    stat(stats, '处理中', counts.processing);
    stat(stats, '待审核', counts.needsReview);
    stat(stats, '失败', counts.failed);
    stat(stats, '已入库', counts.written);
    stat(stats, '已跳过', counts.skipped);

    const queue = container.createDiv('eks-panel eks-queue');
    queue.createEl('h3', { text: '处理概览' });
    this.renderQueue(queue, tasks);

    const review = container.createDiv('eks-panel eks-review');
    review.createEl('h3', { text: '审核工作台' });
    const reviewScroll = review.createDiv('eks-review-scroll');
    await this.renderReview(reviewScroll, tasks);

    const paths = container.createDiv('eks-paths');
    paths.createSpan({ text: `源文件入口：${this.plugin.settings.intakePath}` });
    paths.createSpan({ text: `入库输出：${this.plugin.settings.outputPath}` });
    paths.createSpan({ text: '可信卡片自动写入 wiki；疑问项进入审核台。' });
    paths.createSpan({ text: '默认分类目录：wiki/category/tagL1/tagL2' });
  }

  renderQueue(parent, tasks) {
    const historical = tasks.filter((task) => ['written', 'skipped', 'unsupported'].includes(task.status)).length;
    const pending = tasks.filter((task) => task.status === 'queued').length;
    const reviewCount = tasks.reduce((sum, task) => sum + (task.review_atom_ids || []).length, 0);
    const activeTask = tasks.find((task) => PROCESSING_STATUSES.has(task.status));
    const stats = this.plugin.sessionStats || {};
    const progressData = activeTask?.progress || {};
    const grid = parent.createDiv('eks-compact-stats');
    const progress = grid.createDiv('eks-progress-message');
    progress.createDiv({ cls: 'eks-progress-title', text: `当前进度 · ${stageLabel(activeTask?.status || progressData.stage)}` });
    progress.createDiv({ cls: 'eks-progress-text', text: progressData.message || stats.lastMessage || '等待开始处理' });
    // v1.1.8: HTML5 进度条，按 batch 或 chunk 进度填充
    const progressTotal = Number(progressData.batchTotal) || Number(progressData.chunkTotal) || 0;
    const progressIndex = Number(progressData.batchIndex) || Number(progressData.chunkIndex) || 0;
    if (progressTotal > 0) {
      progress.createEl('progress', {
        cls: 'eks-progress-bar',
        attr: { max: String(progressTotal), value: String(progressIndex) }
      });
      const etaText = computeEtaText(progressData);
      const label = progressData.batchTotal
        ? `原子化：${progressIndex}/${progressTotal}${etaText ? ' · ' + etaText : ''}`
        : `MiniMax 分块：${progressIndex}/${progressTotal}；第 ${progressData.attempt || 1} 次请求`;
      progress.createDiv({ cls: 'eks-task-meta', text: label });
    } else if (progressData.chunkTotal || progressData.chunkIndex) {
      progress.createDiv({ cls: 'eks-task-meta', text: `MiniMax 分块：${progressData.chunkIndex || 0}/${progressData.chunkTotal || '?'}；第 ${progressData.attempt || 1} 次请求` });
    }
    if (progressData.totalPages || progressData.extractedPages) {
      progress.createDiv({ cls: 'eks-task-meta', text: `解析页数：${progressData.extractedPages || 0}/${progressData.totalPages || '?'}` });
    }
    if (progressData.elapsedMs !== undefined) {
      progress.createDiv({
        cls: 'eks-task-meta elapsed',
        text: `已用时：${formatDuration(progressData.elapsedMs)} · 最后更新：${formatLocalTime(progressData.at)}`
      });
    } else if (progressData.at) {
      progress.createDiv({ cls: 'eks-task-meta', text: `最后更新：${formatLocalTime(progressData.at)}` });
    }
    stat(grid, '过往已处理', historical);
    stat(grid, '本次处理文件', stats.processed || 0);
    stat(grid, '本次已入库卡片', stats.written || 0);
    stat(grid, '异常项', reviewCount);
    stat(grid, '待自动处理', pending);
    const currentFile = activeTask?.source_path || stats.current;
    if (currentFile) parent.createDiv({ cls: 'eks-task-meta', text: `当前文件：${currentFile}` });
    const actions = parent.createDiv('eks-actions');
    button(actions, '继续自动处理', () => this.plugin.autoProcessQueue(true));
    if (activeTask) {
      button(actions, '完成当前阶段后暂停', () => this.plugin.pauseProcessing());
      button(actions, '取消当前任务', () => this.plugin.cancelCurrentTask(activeTask.task_id));
    }

    const exceptions = tasks.filter((task) => ['failed', 'skipped', 'unsupported'].includes(task.status));
    if (exceptions.length) {
      // v1.2: 失败/跳过原因不再直接展示在 dashboard 上（用户视角噪声太大）。
      //   改为只收集统计 + 写一条 diag 日志；详情见审核工作台 → "查看异常详情" 按钮。
      const reasons = new Map();
      for (const task of exceptions) {
        const reason = task.errors?.at(-1)?.message || stageLabel(task.status);
        reasons.set(reason, (reasons.get(reason) || 0) + 1);
      }
      const summary = [...reasons].map(([reason, count]) => `${reason} (${count})`).join('；');
      if (typeof globalThis.__eksDiag === 'object' && typeof globalThis.__eksDiag.diag === 'function') {
        globalThis.__eksDiag.diag('dashboard.exceptions.summary', { total: exceptions.length, breakdown: summary });
      }
    }
  }

  renderQueueLegacy(parent, tasks) {
    const historical = tasks.filter((task) => ['written', 'archived', 'skipped'].includes(task.status)).length;
    const pending = tasks.filter((task) => task.status === 'queued').length;
    const review = tasks.filter((task) => task.status === 'needs_review').length;
    const activeTask = tasks.find((task) => PROCESSING_STATUSES.has(task.status));
    const stats = this.plugin.sessionStats || {};
    const activeMessage = activeTask?.progress?.message || stats.lastMessage || '等待开始处理';
    const grid = parent.createDiv('eks-compact-stats');
    const progress = grid.createDiv('eks-progress-message');
    progress.createDiv({ cls: 'eks-progress-title', text: '当前进度' });
    progress.createDiv({ cls: 'eks-progress-text', text: activeMessage });
    if (activeTask?.progress?.chunkTotal) {
      progress.createDiv({
        cls: 'eks-task-meta',
        text: `AI 分段：${activeTask.progress.chunkIndex}/${activeTask.progress.chunkTotal}；累计卡片：${activeTask.progress.cardCount || 0}`
      });
    }
    if (activeTask?.progress?.at) {
      progress.createDiv({ cls: 'eks-task-meta', text: `最后更新：${formatLocalTime(activeTask.progress.at)}` });
    }
    stat(grid, '过往已处理', historical);
    stat(grid, '本次处理', stats.processed || 0);
    stat(grid, '本次已处理', stats.written || 0);
    stat(grid, '疑问项', review);
    stat(grid, '待自动处理', pending);
    const currentFile = activeTask?.sourcePath || stats.current;
    if (currentFile) parent.createDiv({ cls: 'eks-task-meta', text: `当前文件：${currentFile}` });
    const actions = parent.createDiv('eks-actions');
    button(actions, '继续自动处理', () => this.plugin.autoProcessQueue(true));
  }

  async renderReview(parent, tasks) {
    // v2.9.0: 会话级「处理失败」区块——失败记录重启后由 sessionStartupCleanup
    //   自动清除，所以这里只会展示本次会话内的失败，满足"关机即删、重开不显示"。
    const failedTasks = tasks.filter((task) => task.status === 'failed');
    if (failedTasks.length) {
      const block = parent.createDiv('eks-review-group eks-failed-group');
      block.createEl('h4', { text: `处理失败的文件（${failedTasks.length} 个 · 重启 Obsidian 后自动清空）` });
      for (const task of failedTasks) {
        const item = block.createDiv('eks-failed-item');
        item.createEl('strong', { text: task.source_path || '(未知文件)' });
        const lastError = Array.isArray(task.errors) && task.errors.length ? task.errors.at(-1) : null;
        item.createDiv({
          cls: 'eks-task-meta',
          text: `失败阶段：${stageLabel(lastError?.stage || task.progress?.stage || 'process')} · 原因：${lastError?.message || '未知错误'}`
        });
        const actions = item.createDiv('eks-actions');
        button(actions, '重试', () => this.plugin.retryTask(task.task_id));
        button(actions, '移除', () => this.plugin.dismissTask(task.task_id));
      }
    }
    const reviewTasks = tasks.filter((task) => task.status === 'needs_review' && task.artifacts?.review);
    if (!reviewTasks.length) {
      if (!failedTasks.length) {
        parent.createDiv({ cls: 'eks-empty', text: '暂无异常项。可信结果会自动入库，不需要逐条审核。' });
      }
      return;
    }
    for (const task of reviewTasks) {
      const artifact = await this.plugin.loadArtifact(task, 'review');
      if (!artifact) continue;
      for (const group of groupReviewItems(artifact.items)) {
        const block = parent.createDiv('eks-review-group');
        const header = block.createDiv('eks-review-group-header');
        header.createEl('h4', { text: `${group.label}（${group.items.length} 项）` });
        const scores = group.items.map((item) => Number(item.confidence?.score || 0));
        const average = scores.length ? scores.reduce((sum, value) => sum + value, 0) / scores.length : 0;
        block.createDiv({ cls: 'eks-task-meta', text: `${task.source_path} · 平均可信度 ${average.toFixed(2)}` });
        block.createDiv({ cls: 'eks-review-reason', text: `原因：${group.reasons.join('；') || '可信度未达到自动入库阈值'}` });
        const samples = group.items.slice(0, 3).map((item) => item.atom?.title).filter(Boolean);
        if (samples.length) block.createDiv({ cls: 'eks-task-meta', text: `示例：${samples.join('；')}${group.items.length > 3 ? '…' : ''}` });
        const actions = block.createDiv('eks-actions');
        button(actions, '整组批准入库', () => this.plugin.applyReviewGroup(task.task_id, group.group_id, 'approve_group'));
        button(actions, '批量修正标签', async () => {
          // v1.4 (M-05): prompt 文案明确白名单，避免用户误以为能改任意字段
          const initial = '{"Category":"","TagL1":"","TagL2":""}';
          const hint = '输入 JSON 修正标签；只接受白名单字段：Category / TagL1 / TagL2 / Info_Type / Event_Type / Card_Type / Map_Index；空字符串视为不修改该字段；其他字段或非字符串会被拒绝。';
          const raw = window.prompt(hint, initial);
          if (!raw) return;
          try {
            await this.plugin.applyReviewGroup(task.task_id, group.group_id, 'apply_correction', JSON.parse(raw));
          } catch (error) {
            new Notice(`批量修正失败：${error.message}`);
          }
        });
        button(actions, '仅重做知识原子', () => this.plugin.applyReviewGroup(task.task_id, group.group_id, 'regenerate_group'));
        button(actions, '整组丢弃', () => this.plugin.applyReviewGroup(task.task_id, group.group_id, 'discard_group'));
        // v1.2: 把该组所有异常原子展开到一个 Modal，方便人工逐条确认（标题/原因/可信度/摘要）
        button(actions, '查看异常详情', () => {
          new ReviewExceptionModal(this.app, group, task.source_path).open();
        });
      }
    }
  }

  async renderReviewLegacy(parent, tasks) {
    const reviewTasks = tasks.filter((task) => task.status === 'needs_review' && task.draftFiles && task.draftFiles.length);
    if (!reviewTasks.length) {
      parent.createDiv({ cls: 'eks-empty', text: '暂无待审核草稿卡片。' });
      return;
    }
    for (const task of reviewTasks) {
      const block = parent.createDiv('eks-draft-block');
      block.createEl('h4', { text: task.sourcePath });
      for (const draftPath of task.draftFiles) {
        const file = this.app.vault.getAbstractFileByPath(draftPath);
        const draft = file instanceof TFile ? await this.app.vault.read(file) : '';
        const item = block.createDiv('eks-draft');
        item.createDiv({ cls: 'eks-task-meta', text: draftPath });
        this.renderDraftSummary(item, draft, task);
        const actions = item.createDiv('eks-actions');
        button(actions, '批准入库', () => this.plugin.approveDraft(task.taskId, draftPath));
        button(actions, '打开草稿', () => this.app.workspace.openLinkText(draftPath, '', false));
        button(actions, '重新生成', () => this.plugin.retryTask(task.taskId));
        button(actions, '退回/跳过', () => this.plugin.skipTask(task.taskId));
      }
    }
  }

  renderDraftSummary(parent, draft, task) {
    parent.createEl('h4', { text: `疑问项 ${task.taskId}` });
    const fields = ['Map_Index', 'Category', 'TagL1', 'TagL2', 'Status', 'Confidence'];
    const table = parent.createEl('table', { cls: 'eks-draft-table' });
    for (const field of fields) {
      const tr = table.createEl('tr');
      tr.createEl('th', { text: field });
      tr.createEl('td', { text: readFrontmatterValue(draft, field) || '-' });
    }
  }
}

class SlicerSettingTab extends PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl('h2', { text: '工程知识切片设置' });
    // v1.2: 一键打开诊断日志，方便没 DevTools 环境的用户直接查看文件路径
    // v1.3: 默认日志在 vault 之外（~/.eks/logs/diag.log），避开同步冲突；
    //       勾选"写到 vault 内"则回退到 .obsidian/plugins/engineering-knowledge-slicer/diag.log。
    const diagPathDesc = (typeof globalThis.__eksDiag === 'object' && globalThis.__eksDiag.state && globalThis.__eksDiag.state.logPath)
      ? `所有 [EKS diag] 事件写入 ${globalThis.__eksDiag.state.logPath}。遇到问题时把文件内容发给我即可定位。`
      : '所有 [EKS diag] 事件写入 ~/.eks/logs/diag.log（默认）。遇到问题时把文件内容发给我即可定位。';
    new Setting(containerEl)
      .setName('诊断日志')
      .setDesc(diagPathDesc)
      .addToggle((toggle) => toggle
        .setValue(!!this.plugin.settings.diagLogInVault)
        .setTooltip('默认关闭：日志写到 ~/.eks/logs/diag.log（vault 之外）。打开后回到 vault 内的 .obsidian/plugins/engineering-knowledge-slicer/diag.log（重启后生效）。')
        .onChange(async (value) => {
          this.plugin.settings.diagLogInVault = !!value;
          await this.plugin.saveData(this.plugin.settings);
        }))
      .addButton((button) => button
        .setButtonText('打开诊断日志')
        .setCta()
        .onClick(async () => {
          const logPath = (typeof globalThis.__eksDiag === 'object' && globalThis.__eksDiag.state)
            ? globalThis.__eksDiag.state.logPath
            : null;
          if (!logPath) {
            new Notice('诊断日志尚未初始化，请先等待插件加载完成或重载。');
            return;
          }
          // 把 vault 绝对路径转回 vault-相对路径，以便 openLinkText 能在 vault 中定位文件
          let relPath = logPath;
          let inVault = false;
          try {
            const adapter = this.app.vault && this.app.vault.adapter;
            if (adapter && typeof adapter.getBasePath === 'function') {
              const basePath = adapter.getBasePath();
              if (basePath && relPath.startsWith(basePath)) {
                relPath = relPath.substring(basePath.length).replace(/^[\\/]+/, '');
                inVault = true;
              }
            }
          } catch (_) { /* fallback: 直接试绝对路径 */ }
          if (inVault) {
            let file = this.app.vault.getAbstractFileByPath(relPath);
            if (!file && relPath !== logPath) file = this.app.vault.getAbstractFileByPath(logPath);
            if (!file) {
              try { file = await this.app.vault.create(relPath, ''); } catch (_) { /* 文件可能已存在，忽略 */ }
            }
            if (file instanceof TFile) {
              await this.app.workspace.openLinkText(relPath, '', false);
              return;
            }
          }
          // 日志在 vault 之外 / openLinkText 不可用：先确保文件存在，再用系统默认编辑器打开
          try {
            const { shell } = require('electron');
            await shell.openPath(logPath);
            new Notice(`诊断日志：${logPath}`);
          } catch (e) {
            new Notice(`诊断日志路径：${logPath}\n请在系统文件管理器中手动打开。`);
          }
        }));
    pathSetting(containerEl, this.plugin, '招投标源文件路径', '固定读取招投标源文件。', 'bidIntakePath');
    pathSetting(containerEl, this.plugin, '业务库源文件路径', '固定读取业务库源文件。', 'businessIntakePath');
    pathSetting(containerEl, this.plugin, '招投标输出路径', '招投标知识卡片固定输出根目录。', 'bidOutputPath');
    pathSetting(containerEl, this.plugin, '业务库输出路径', '业务知识卡片固定输出根目录。', 'businessOutputPath');
    pathSetting(containerEl, this.plugin, '中间产物路径', '解析包、结构化总结、审核项和脱敏日志目录。', 'artifactsPath');
    pathSetting(containerEl, this.plugin, '组件包路径', '标签库、提示词、模板和映射规则所在目录。', 'componentPackPath');

    new Setting(containerEl)
      .setName('自动入库置信度门槛')
      .setDesc('低于该置信度的卡片进入审核台；字段非法、MOC 待分类或证据不足的卡片始终进入审核台。')
      .addText((text) => text
        .setPlaceholder('0.9')
        .setValue(String(this.plugin.settings.autoApproveConfidenceThreshold || 0.9))
        .onChange(async (value) => {
          const threshold = Number(value);
          if (Number.isFinite(threshold) && threshold >= 0 && threshold <= 1) {
            this.plugin.settings.autoApproveConfidenceThreshold = threshold;
            await this.plugin.saveSettings();
          }
        }));

    new Setting(containerEl)
      .setName('并发处理文档数')
      .setDesc('同时处理的源文件上限，建议 2-3，过高容易触发 API 限流。')
      .addText((text) => text
        .setPlaceholder('3')
        .setValue(String(this.plugin.settings.maxConcurrentDocuments || 3))
        .onChange(async (value) => {
          const n = Number(value);
          if (Number.isFinite(n) && n >= 1 && n <= 10) {
            this.plugin.settings.maxConcurrentDocuments = n;
            await this.plugin.saveSettings();
          }
        }));

    // v2.8: 自动扫描设置项，默认关闭
    new Setting(containerEl)
      .setName('启动时自动扫描')
      .setDesc('默认关闭。开启后每次打开 Obsidian 会自动扫描源文件目录（招投标 / 业务库）并开始自动处理。扫描会触发云端解析与 MiniMax 计费，建议保持关闭，需要时手动点控制台「扫描并自动处理」按钮或执行命令「扫描源文件」。')
      .addToggle((toggle) => toggle
        .setValue(this.plugin.settings.autoScanOnStartup === true)
        .onChange(async (value) => {
          this.plugin.settings.autoScanOnStartup = !!value;
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName('启用外部密钥文件')
      .setDesc('开启后从 ~/.eks-secrets.json 读取密钥，避免 OneDrive/iCloud 同步目录中的 data.json 泄露密钥。')
      .addToggle((toggle) => toggle
        .setValue(this.plugin.settings.useEnvKeys !== false)
        .onChange(async (value) => {
          this.plugin.settings.useEnvKeys = value;
          await this.plugin.saveSettings();
        }));

    containerEl.createEl('h3', { text: 'MiniMax 结构化处理' });

    passwordSetting(containerEl, this.plugin, 'MiniMax API Key', '用于调用 MiniMax 国内版。仅保存在本地插件设置中，不写入 Markdown 或任务日志。', 'minimaxApiKey', 'MiniMax API Key');
    textSetting(containerEl, this.plugin, 'MiniMax 模型', '默认使用 MiniMax-M3，可按账户实际可用模型修改。', 'minimaxModel', 'MiniMax-M3');
    textSetting(containerEl, this.plugin, 'MiniMax M3 接口地址', '国内版默认使用 Anthropic 兼容接口，以支持更长的结构化输出。', 'minimaxEndpoint', 'https://api.minimaxi.com/anthropic/v1/messages');
    new Setting(containerEl)
      .setName('启用 SSE 流式输出 (POC)')
      .setDesc('调用 MiniMax 时走 text/event-stream，逐 token 累积 JSON 文本；失败时自动回退到非流式。需 Obsidian 桌面端（Electron 27+）。')
      .addToggle((control) => control
        .setValue(Boolean(this.plugin.settings.useStreamingAi))
        .onChange(async (value) => {
          this.plugin.settings.useStreamingAi = Boolean(value);
          await this.plugin.saveData(this.plugin.settings);
        }));
    connectionTestSetting(containerEl, this.plugin, '测试 MiniMax 连接', 'minimax');

    new Setting(containerEl)
      .setName('知识卡片输出语言')
      .setDesc('源文件可为中文、英文或日文；调用 AI 时，标题、摘要和摘录统一生成中文。')
      .addDropdown((dropdown) => dropdown
        .addOption('zh-CN', '简体中文')
        .setValue(this.plugin.settings.targetLanguage || 'zh-CN')
        .onChange(async (value) => {
          this.plugin.settings.targetLanguage = value;
          await this.plugin.saveSettings();
        }));

    containerEl.createEl('h3', { text: '云端文档解析' });

    new Setting(containerEl)
      .setName('允许上传源文件到外部解析 API')
      .setDesc('开启后受支持的源文件会上传到 MinerU/PaddleOCR。请确认符合公司的保密与数据外发要求。')
      .addToggle((toggle) => toggle
        .setValue(this.plugin.settings.pdfAllowExternalUpload === true)
        .onChange(async (value) => {
          this.plugin.settings.pdfAllowExternalUpload = value;
          await this.plugin.saveSettings();
        }));

    // v1.3: 上传前是否弹窗二次确认。
    new Setting(containerEl)
      .setName('上传前弹窗确认')
      .setDesc('开启后每次解析源文件前都会显示文件名 / 大小 / 目标解析器，并要求点确认。自动流水线场景可关闭。')
      .addToggle((toggle) => toggle
        .setValue(this.plugin.settings.confirmUploads !== false)
        .onChange(async (value) => {
          this.plugin.settings.confirmUploads = value;
          await this.plugin.saveSettings();
        }));

    passwordSetting(containerEl, this.plugin, 'MinerU API Token', '精准解析 API Token，仅保存在本地插件设置中。', 'pdfMineruApiKey', 'MinerU Token');
    textSetting(containerEl, this.plugin, 'MinerU API 端点', '国内精准解析 API 基础地址。', 'pdfMineruApiEndpoint', 'https://mineru.net/api/v4');
    textSetting(containerEl, this.plugin, 'MinerU API 模型', '建议使用 vlm；复杂版面、表格和扫描件解析更完整。', 'pdfMineruApiModel', 'vlm');
    connectionTestSetting(containerEl, this.plugin, '测试 MinerU 连接', 'mineru');

    new Setting(containerEl)
      .setName('MinerU 文档语言')
      .setDesc('ch_server 同时覆盖中文、英文、繁体和日文；日文为主的资料可改为 japan。')
      .addDropdown((dropdown) => dropdown
        .addOption('ch_server', '中/英/日文混合')
        .addOption('ch', '中文/英文')
        .addOption('japan', '日文为主')
        .addOption('en', '英文为主')
        .setValue(this.plugin.settings.pdfMineruApiLanguage || 'ch_server')
        .onChange(async (value) => {
          this.plugin.settings.pdfMineruApiLanguage = value;
          await this.plugin.saveSettings();
        }));

    passwordSetting(containerEl, this.plugin, 'PaddleOCR API Token', 'AI Studio 文档解析 Token，仅保存在本地插件设置中。', 'pdfPaddleOcrApiKey', 'PaddleOCR Token');
    textSetting(containerEl, this.plugin, 'PaddleOCR API 端点', '国内 PaddleOCR 异步任务接口。', 'pdfPaddleOcrApiEndpoint', 'https://paddleocr.aistudio-app.com/api/v2/ocr/jobs');
    textSetting(containerEl, this.plugin, 'PaddleOCR API 模型', '用于扫描件和 MinerU 低质量结果补盲。', 'pdfPaddleOcrApiModel', 'PaddleOCR-VL-1.6');
    connectionTestSetting(containerEl, this.plugin, '测试 PaddleOCR 连接', 'paddleocr');

    new Setting(containerEl)
      .setName('云端解析轮询间隔')
      .setDesc('查询远程解析进度的间隔，默认 5 秒。')
      .addText((text) => text
        .setPlaceholder('5')
        .setValue(String(Math.round((this.plugin.settings.pdfApiPollIntervalMs || 5000) / 1000)))
        .onChange(async (value) => {
          const seconds = Number(value);
          if (Number.isFinite(seconds) && seconds >= 1 && seconds <= 60) {
            this.plugin.settings.pdfApiPollIntervalMs = seconds * 1000;
            await this.plugin.saveSettings();
          }
        }));

    new Setting(containerEl)
      .setName('外部 PDF 解析超时')
      .setDesc('MinerU/PaddleOCR 可能较慢，默认 600 秒；超时后会降级到下一解析器。')
      .addText((text) => text
        .setPlaceholder('600')
        .setValue(String(Math.round((this.plugin.settings.pdfExternalTimeoutMs || 600000) / 1000)))
        .onChange(async (value) => {
          const seconds = Number(value);
          if (Number.isFinite(seconds) && seconds > 0) {
            this.plugin.settings.pdfExternalTimeoutMs = Math.round(seconds * 1000);
            await this.plugin.saveSettings();
          }
        }));

    new Setting(containerEl)
      .setName('AI 请求超时')
      .setDesc('单次分段调用超过该时间仍无返回时，任务会失败并显示原因；长文档会分多段逐段调用。')
      .addText((text) => text
        .setPlaceholder('300')
        .setValue(String(Math.round((this.plugin.settings.aiRequestTimeoutMs || 300000) / 1000)))
        .onChange(async (value) => {
          const seconds = Number(value);
          if (Number.isFinite(seconds) && seconds >= 10) {
            this.plugin.settings.aiRequestTimeoutMs = Math.round(seconds * 1000);
            await this.plugin.saveSettings();
          }
        }));

    new Setting(containerEl)
      .setName('AI 单段字符数')
      .setDesc('每次交给 AI 的源文本长度。默认 8000；复杂表格较多时可适当调低。')
      .addText((text) => text
        .setPlaceholder('8000')
        .setValue(String(this.plugin.settings.aiChunkSize || 8000))
        .onChange(async (value) => {
          const chars = Number(value);
          if (Number.isFinite(chars) && chars >= 4000 && chars <= 30000) {
            this.plugin.settings.aiChunkSize = Math.round(chars);
            await this.plugin.saveSettings();
          }
        }));

    new Setting(containerEl)
      .setName('切片重叠比例')
      .setDesc('v2.7（借鉴 WeKnora）：相邻分块之间的重叠比例，避免段落语境在切点处断裂。范围 0–0.5，建议 0.05–0.2；设为 0 关闭重叠。重叠会略增 AI 输入 token。')
      .addText((text) => text
        .setPlaceholder('0.1')
        .setValue(String(this.plugin.settings.chunkOverlapRatio ?? 0.1))
        .onChange(async (value) => {
          const ratio = Number(value);
          if (Number.isFinite(ratio) && ratio >= 0 && ratio <= 0.5) {
            this.plugin.settings.chunkOverlapRatio = ratio;
            await this.plugin.saveSettings();
          }
        }));

    new Setting(containerEl)
      .setName('合并过小切片')
      .setDesc('v2.7（借鉴 WeKnora coalesceTinyChunks）：同一标题语境下过小的相邻切片自动合并，减少 AI 调用次数、提升处理速度。关闭后每个小节独立调用一次 AI。')
      .addToggle((toggle) => toggle
        .setValue(this.plugin.settings.coalesceTinyChunks !== false)
        .onChange(async (value) => {
          this.plugin.settings.coalesceTinyChunks = value;
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName('AI 最大分段数')
      .setDesc('限制单个文件的 AI 调用次数，默认 100。超过上限时任务会明确失败，不会静默遗漏后半部分。')
      .addText((text) => text
        .setPlaceholder('100')
        .setValue(String(this.plugin.settings.aiMaxChunks || 100))
        .onChange(async (value) => {
          const chunks = Number(value);
          if (Number.isFinite(chunks) && chunks >= 1 && chunks <= 200) {
            this.plugin.settings.aiMaxChunks = Math.round(chunks);
            await this.plugin.saveSettings();
          }
        }));

    new Setting(containerEl)
      .setName('每批知识点数')
      .setDesc('每次原子化请求处理的知识点数量。默认 3，可显著减少 API 调用；复杂内容可调低到 1-2。')
      .addDropdown((dropdown) => dropdown
        .addOption('1', '1（最细，最慢）').addOption('2', '2（平衡）').addOption('3', '3（推荐）')
        .setValue(String(this.plugin.settings.maxPointsPerRequest || 3))
        .onChange(async (value) => {
          this.plugin.settings.maxPointsPerRequest = Number(value);
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName('总结并发数')
      .setDesc('同时执行的逐段总结请求数。默认 2；与原子化并发独立，降低原子化并发不会拖慢总结。')
      .addDropdown((dropdown) => dropdown
        .addOption('1', '1（保守）').addOption('2', '2（推荐）').addOption('3', '3（较快）')
        .setValue(String(this.plugin.settings.summaryConcurrency || 2))
        .onChange(async (value) => {
          this.plugin.settings.summaryConcurrency = Number(value);
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName('原子化并发数')
      .setDesc('同时执行的原子化批次数。默认 2；出现 429 时建议调为 1。')
      .addDropdown((dropdown) => dropdown
        .addOption('1', '1（保守）').addOption('2', '2（推荐）').addOption('3', '3（较快）')
        .setValue(String(this.plugin.settings.atomizationConcurrency || 2))
        .onChange(async (value) => {
          this.plugin.settings.atomizationConcurrency = Number(value);
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName('短文档卡片异常阈值')
      .setDesc('3 页以内文档超过该数量时不自动入库，整批转入审核台；不会截断或丢弃卡片。默认 20。')
      .addText((text) => text.setPlaceholder('20')
        .setValue(String(this.plugin.settings.shortDocumentMaxCards || 20))
        .onChange(async (value) => {
          const count = Number(value);
          if (Number.isFinite(count) && count >= 5 && count <= 100) {
            this.plugin.settings.shortDocumentMaxCards = Math.round(count);
            await this.plugin.saveSettings();
          }
        }));

    new Setting(containerEl)
      .setName('卡住任务判定时间')
      .setDesc('处理中任务超过该时间没有任何进度更新，会自动转为失败，方便用“重试失败并处理”重新排队。')
      .addText((text) => text
        .setPlaceholder('20')
        .setValue(String(this.plugin.settings.staleProcessingMinutes || 20))
        .onChange(async (value) => {
          const minutes = Number(value);
          if (Number.isFinite(minutes) && minutes >= 5) {
            this.plugin.settings.staleProcessingMinutes = Math.round(minutes);
            await this.plugin.saveSettings();
          }
        }));

    containerEl.createEl('h3', { text: '生态插件检测' });
    for (const item of detectEcosystemPlugins(this.app)) {
      const setting = new Setting(containerEl)
        .setName(item.name)
        .setDesc(item.role);
      setting.addExtraButton((button) => button
        .setIcon(item.enabled ? 'check-circle' : (item.installed ? 'circle-dot' : 'circle'))
        .setTooltip(item.enabled ? '已启用' : (item.installed ? '已安装但未启用' : '可选增强')));
    }

    containerEl.createEl('h3', { text: '维护' });
    new Setting(containerEl)
      .setName('清空当前插件缓存')
      .setDesc('删除任务队列、处理日志和待审核草稿；不会删除源文件，也不会删除已经写入 wiki 的知识卡片。')
      .addButton((button) => button
        .setButtonText('清空缓存')
        .setWarning()
        .onClick(async () => {
          if (typeof window !== 'undefined' && !window.confirm('确认清空工程知识切片的任务队列、日志和草稿？源文件和已入库 wiki 卡片不会删除。')) return;
          await this.plugin.clearPluginCache();
          this.display();
        }));
  }
}

function pathSetting(containerEl, plugin, name, desc, key) {
  new Setting(containerEl)
    .setName(name)
    .setDesc(desc)
    .addText((text) => text
      .setValue(plugin.settings[key])
      .onChange(async (value) => {
        plugin.settings[key] = normalizeVaultPath(value);
        await plugin.saveSettings();
      }));
}

function textSetting(containerEl, plugin, name, desc, key, fallback = '') {
  new Setting(containerEl)
    .setName(name)
    .setDesc(desc)
    .addText((text) => text
      .setValue(plugin.settings[key] || fallback)
      .onChange(async (value) => {
        plugin.settings[key] = value.trim() || fallback;
        await plugin.saveSettings();
      }));
}

function passwordSetting(containerEl, plugin, name, desc, key, placeholder = '') {
  new Setting(containerEl)
    .setName(name)
    .setDesc(desc)
    .addText((text) => {
      text.inputEl.type = 'password';
      text
        .setPlaceholder(placeholder)
        .setValue(plugin.settings[key] || '')
        .onChange(async (value) => {
          plugin.settings[key] = value.trim();
          await plugin.saveSettings();
        });
    });
}

async function obsidianRequest(url, init = {}) {
  let body = init.body;
  if (Buffer.isBuffer(body) || ArrayBuffer.isView(body)) {
    const bytes = Buffer.from(body);
    body = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
  }
  const response = await requestUrl({
    url,
    method: init.method || 'GET',
    headers: init.headers || {},
    body,
    throw: false
  });
  const text = String(response.text || '');
  return {
    ok: response.status >= 200 && response.status < 300,
    status: response.status,
    async json() {
      if (response.json !== undefined && response.json !== null) return response.json;
      return JSON.parse(text);
    },
    async text() { return text; },
    async arrayBuffer() {
      if (response.arrayBuffer) return response.arrayBuffer;
      const bytes = Buffer.from(text, 'utf8');
      return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
    }
  };
}

function connectionTestSetting(containerEl, plugin, name, service) {
  new Setting(containerEl)
    .setName(name)
    .setDesc('验证鉴权和服务端是否可访问；不会上传知识库文件。')
    .addButton((control) => control
      .setButtonText('测试连接')
      .onClick(async () => {
        control.setDisabled(true);
        try { await plugin.testServiceConnection(service); } finally { control.setDisabled(false); }
      }));
}

function serviceConnectionConfig(service, settings) {
  if (service === 'minimax') {
    const endpoint = settings.minimaxEndpoint || 'https://api.minimaxi.com/anthropic/v1/messages';
    if (/\/anthropic\/v1\/messages\/?$/i.test(endpoint)) {
      return {
        label: 'MiniMax',
        apiKey: settings.minimaxApiKey || '',
        url: endpoint,
        request: {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-api-key': settings.minimaxApiKey || '', 'anthropic-version': '2023-06-01' },
          body: JSON.stringify({
            model: settings.minimaxModel || 'MiniMax-M3',
            messages: [{ role: 'user', content: '仅回答 OK' }],
            max_tokens: 32
          })
        }
      };
    }
    return {
      label: 'MiniMax',
      apiKey: settings.minimaxApiKey || '',
      url: endpoint,
      request: {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${settings.minimaxApiKey || ''}` },
        body: JSON.stringify({
          model: settings.minimaxModel || 'MiniMax-M3',
          messages: [{ role: 'user', content: '仅回复 OK' }],
          temperature: 0,
          max_tokens: 4
        })
      }
    };
  }
  if (service === 'mineru') {
    const endpoint = String(settings.pdfMineruApiEndpoint || 'https://mineru.net/api/v4').replace(/\/$/, '');
    return {
      label: 'MinerU',
      apiKey: settings.pdfMineruApiKey || '',
      url: `${endpoint}/extract/task/connection-test`,
      request: { method: 'GET', headers: { Authorization: `Bearer ${settings.pdfMineruApiKey || ''}` } }
    };
  }
  const endpoint = String(settings.pdfPaddleOcrApiEndpoint || 'https://paddleocr.aistudio-app.com/api/v2/ocr/jobs').replace(/\/$/, '');
  return {
    label: 'PaddleOCR',
    apiKey: settings.pdfPaddleOcrApiKey || '',
    url: `${endpoint}/connection-test`,
    request: { method: 'GET', headers: { Authorization: `bearer ${settings.pdfPaddleOcrApiKey || ''}` } }
  };
}

function button(parent, text, onClick) {
  const el = parent.createEl('button', { text });
  el.onclick = onClick;
  return el;
}

function stat(parent, label, value) {
  const el = parent.createDiv('eks-stat');
  el.createDiv({ cls: 'eks-stat-value', text: String(value) });
  el.createDiv({ cls: 'eks-stat-label', text: label });
}

function formatLocalTime(iso) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return date.toLocaleString('zh-CN', { hour12: false });
}

function formatDuration(milliseconds) {
  const seconds = Math.max(0, Math.floor(Number(milliseconds || 0) / 1000));
  if (seconds < 60) return `${seconds} 秒`;
  const minutes = Math.floor(seconds / 60);
  return `${minutes} 分 ${seconds % 60} 秒`;
}

function stageLabel(stage) {
  const labels = {
    start: '准备', queued: '排队', parsing: '文档解析', parsed: '解析完成', classifying: '类型判定', classification: '类型判定',
    summarizing: '结构化总结', 'summary-map': '逐段总结', 'summary-reduce': '合并总结', atomizing: '知识原子化', atomization: '知识原子化',
    validating: '可信度与契约校验', writing: '写入知识库', complete: '完成', failed: '失败', paused: '已暂停', cancelled: '已取消',
    skipped: '已跳过', unsupported: '不支持'
  };
  return labels[stage] || String(stage || '等待');
}

async function ensureFolder(app, folderPath) {
  const parts = normalizeVaultPath(folderPath).split('/').filter(Boolean);
  let current = '';
  for (const part of parts) {
    current = current ? `${current}/${part}` : part;
    if (!app.vault.getAbstractFileByPath(current)) {
      try { await app.vault.createFolder(current); } catch {}
    }
  }
}

async function writeFile(app, path, content) {
  await ensureFolder(app, path.split('/').slice(0, -1).join('/'));
  const existing = app.vault.getAbstractFileByPath(path);
  if (existing instanceof TFile) {
    await app.vault.modify(existing, content);
  } else {
    await app.vault.create(path, content);
  }
  return path;
}

async function writeUnique(app, targetPath, content) {
  const normalized = normalizeVaultPath(targetPath);
  const folder = normalized.split('/').slice(0, -1).join('/');
  const file = normalized.split('/').pop();
  const stem = file.replace(/\.md$/, '');
  let candidate = normalized;
  let index = 1;
  while (app.vault.getAbstractFileByPath(candidate)) {
    candidate = `${folder}/${stem}-${index}.md`;
    index += 1;
  }
  await writeFile(app, candidate, content);
  return candidate;
}

async function deleteFolderContents(app, folderPath) {
  const folder = app.vault.getAbstractFileByPath(normalizeVaultPath(folderPath));
  if (!(folder instanceof TFolder)) return;
  const children = [...folder.children];
  for (const child of children) {
    await app.vault.delete(child, true);
  }
}

function upsertTask(tasks, task) {
  const id = task.task_id || task.taskId;
  const index = tasks.findIndex((item) => (item.task_id || item.taskId) === id);
  if (index >= 0) tasks[index] = task;
  else tasks.push(task);
  return tasks;
}

function runtimeVersions(settings) {
  return {
    pipelineVersion: settings.pipelineVersion || '1.1.0',
    promptBundleVersion: settings.promptBundleVersion || '1.1',
    schemaVersion: settings.schemaVersion || '1.1'
  };
}

function libraryForPath(filePath, settings) {
  const path = normalizeVaultPath(filePath);
  if (path.startsWith(`${normalizeVaultPath(settings.businessIntakePath)}/`)) return 'business';
  return 'bid';
}

function workflowStatus(stage) {
  if (stage === 'classification') return 'classifying';
  if (stage === 'summary-map' || stage === 'summary-reduce') return 'summarizing';
  if (stage === 'atomization') return 'atomizing';
  return 'validating';
}

function validateAtomLabels(library, atom) {
  const required = [
    [library.categories, atom.Category],
    [library.tagL1, atom.TagL1],
    [library.tagL2, atom.TagL2]
  ];
  if (atom.card_kind === 'event') required.push([library.eventTypes, atom.Event_Type]);
  if (atom.card_kind === 'static') required.push([library.infoTypes, atom.Info_Type]);
  return required.every(([allowed, value]) => Boolean(value) && allowed && allowed.has(value));
}

// 统一遮蔽多种 API 密钥形态（OpenAI sk-、Bearer JWT、URL 里的 token= / api_key= / apikey=）
// v1.1.2 之前只匹配 sk-*，会把 MiniMax / PaddleOCR / MinerU 的密钥原样漏进 Notice。
// v1.4: 用户可见错误（Notice / dashboard）的密钥脱敏。
//       优先复用 redactCredential（更严格），再针对 URL query / Bearer 前缀等结构化场景做兜底。
function sanitizeSecret(message) {
  const text = String(message || '');
  // 1) URL query 参数（?token=xxx &api_key=yyy）—— redactCredential 不会触发
  let result = text.replace(/([?&](?:token|access_token|api[_-]?key|apikey|password|secret)=)[^&\s"']+/gi, '$1***');
  // 2) Bearer / Basic 前缀的 token
  result = result.replace(/(bearer\s+|basic\s+)[A-Za-z0-9._\-+/=]{12,}/gi, '$1***');
  // 3) 内容指纹级（覆盖所有凭证模式）—— 在已脱敏的基础上最后一道防线
  result = result.replace(/[A-Za-z0-9+/=_\-]{24,}/g, (match) => {
    // 对剩余长字符串也走一次 redactCredential（只对会触发指纹的子串替换）
    const fingerprinted = redactCredential(match);
    return fingerprinted === match ? match : fingerprinted;
  });
  return result;
}

function getMarkdownTitle(markdown) {
  const match = String(markdown || '').match(/^#\s+(.+)$/m);
  return match ? match[1].trim() : '';
}

// v1.9 (m-01): 读 frontmatter 单字段，支持：
//                - 纯字符串:  Key: value
//                - 双引号包:   Key: "value with spaces"
//                - YAML 列表:  Key: [a, b, c]   → 返回 "a, b, c"
//                - 多行列表:  Key:\n  - a\n  - b  → 返回 "a, b"
function readFrontmatterValue(markdown, key) {
  const text = String(markdown || '');
  const re = new RegExp(`^${key}:\\s*(.*?)(?=^\\w+:|\\Z)`, 'ms');
  const match = text.match(re);
  if (!match) return '';
  let raw = match[1].replace(/\s+$/, '');
  // 单行列表 [a, b, c]
  const inlineList = raw.match(/^\s*\[\s*(.+?)\s*\]\s*$/);
  if (inlineList) {
    return inlineList[1].split(',').map((s) => s.trim().replace(/^["']|["']$/g, '')).filter(Boolean).join(', ');
  }
  // 多行列表：key 后的所有 "- value"
  if (/^\s*$/.test(raw.split('\n')[0])) {
    const items = [];
    for (const line of raw.split('\n')) {
      const itemMatch = line.match(/^\s*-\s+(.+?)\s*$/);
      if (itemMatch) items.push(itemMatch[1].replace(/^["']|["']$/g, ''));
    }
    if (items.length) return items.join(', ');
  }
  // 单行值（去引号）
  raw = raw.replace(/^["']|["']$/g, '').trim();
  // 多行（普通换行 → 空格）
  raw = raw.replace(/\n+/g, ' ').replace(/\s+/g, ' ').trim();
  return raw;
}

function cardFromMarkdown(markdown) {
  const confidence = Number(readFrontmatterValue(markdown, 'Confidence'));
  return {
    Map_Index: readFrontmatterValue(markdown, 'Map_Index'),
    Card_Type: readFrontmatterValue(markdown, 'Card_Type'),
    Event_Type: readFrontmatterValue(markdown, 'Event_Type'),
    Info_Type: readFrontmatterValue(markdown, 'Info_Type'),
    Category: readFrontmatterValue(markdown, 'Category'),
    TagL1: readFrontmatterValue(markdown, 'TagL1'),
    TagL2: readFrontmatterValue(markdown, 'TagL2'),
    Status: readFrontmatterValue(markdown, 'Status'),
    Source_File: readFrontmatterValue(markdown, 'Source_File'),
    Source_Path: readFrontmatterValue(markdown, 'Source_Path'),
    Source_Hash: readFrontmatterValue(markdown, 'Source_Hash'),
    Confidence: Number.isFinite(confidence) ? confidence : undefined
  };
}

function approveMarkdownStatus(markdown, status = '#status/approved') {
  const text = String(markdown || '');
  if (/^Status:\s*.*$/m.test(text)) {
    return text.replace(/^Status:\s*.*$/m, `Status: ${JSON.stringify(status)}`);
  }
  return text.replace(/^---\n/, `---\nStatus: ${JSON.stringify(status)}\n`);
}

function approvedStatus(library) {
  if (library?.statuses?.has('#status/approved')) return '#status/approved';
  if (library?.statuses?.has('#status/confirmed')) return '#status/confirmed';
  return '#status/approved';
}

},
/**
 * @module src/core/task
 * 任务默认配置 / 运行时 schema 版本号常量
 * @exports DEFAULT_SETTINGS
 * @exports runtimeVersions
 */
"src/core/task.js": function(require, module, exports) {
const crypto = require("crypto");
const path = require("path");

const DEFAULT_SETTINGS = {
  settingsVersion: 17,
  intakePath: '06-知识库/源文件',
  outputPath: '06-知识库/wiki',
  bidIntakePath: '06-知识库/源文件/招投标',
  businessIntakePath: '06-知识库/源文件/业务库',
  bidOutputPath: '06-知识库/wiki/招投标',
  businessOutputPath: '06-知识库/wiki/业务库',
  artifactsPath: '06-知识库/源文件/_slicer_artifacts',
  componentPackPath: '06-知识库/组件包',
  draftPath: '06-知识库/源文件/_slicer_artifacts/review',
  logPath: '06-知识库/源文件/_slicer_artifacts/logs',
  tasksFileName: 'tasks.json',
  rollbackFileName: 'rollback.json',
  aiProvider: 'minimax',
  autoApproveConfidenceThreshold: 0.9,
  minimaxApiKey: '',
  minimaxModel: 'MiniMax-M3',
  minimaxEndpoint: 'https://api.minimaxi.com/anthropic/v1/messages',
  pdfExtractionOrder: 'mineru-api,paddleocr-api',
  pdfAllowExternalUpload: false,
  pdfMineruApiKey: '',
  pdfMineruApiEndpoint: 'https://mineru.net/api/v4',
  pdfMineruApiModel: 'vlm',
  pdfMineruApiLanguage: 'ch_server',
  pdfPaddleOcrApiKey: '',
  pdfPaddleOcrApiEndpoint: 'https://paddleocr.aistudio-app.com/api/v2/ocr/jobs',
  pdfPaddleOcrApiModel: 'PaddleOCR-VL-1.6',
  pdfApiPollIntervalMs: 5000,
  pdfExternalTimeoutMs: 600000,
  aiChunkSize: 8000,
  aiMaxChunks: 100,
  maxPointsPerRequest: 3,
  summaryConcurrency: 2,
  atomizationConcurrency: 2,
  shortDocumentMaxCards: 20,
  // v2.7（借鉴 WeKnora 切片引擎）：相邻切片重叠比例（0–0.5）。
  //   0.1 ≈ WeKnora 的 chunk_overlap 80 / chunk_size 512 ≈ 15% 思路，
  //   避免段落语境在切点处断裂；会略增 AI 输入 token。
  chunkOverlapRatio: 0.1,
  // v2.7：同一标题语境下过小的相邻切片自动合并（WeKnora coalesceTinyChunks），
  //   显著减少 AI 调用次数、提升整体处理速度。
  coalesceTinyChunks: true,
  aiRequestTimeoutMs: 300000,
  aiRequestMaxAttempts: 3,
  aiRetryBaseMs: 800,
  maxAutomaticRetries: 3,
  maxConcurrentDocuments: 3,
  rateLimitMs: 1000,
  rateLimitMaxConcurrent: 2,
  rateLimitBackoffMaxMs: 30000,
  rateLimitWindowSize: 10,
  useStreamingAi: false,
  useEnvKeys: true,
  staleProcessingMinutes: 20,
  targetLanguage: 'zh-CN',
  maxExcerptLength: 500,
  pipelineVersion: '1.1.1',
  promptBundleVersion: '1.1',
  schemaVersion: '1.1',
  // v1.3: 诊断日志默认写到 vault 之外（~/.eks/logs/diag.log），
  //        避免被 iCloud / OneDrive / Git 等同步工具重复上传/同步触发性能问题与隐私扩散。
  //        设为 true 时回到原行为（vault 内 .obsidian/plugins/.../diag.log）。
  diagLogInVault: false,
  // v1.3: 上传源文件到 MinerU/PaddleOCR 之前是否弹 Notice 二次确认。
  //        合规优先；设为 false 跳过确认（自动化流水线场景）。
  confirmUploads: true,
  // v1.4 (M-11): 写盘前是否自动备份上一版 tasks.json 到 tasks.json.bak.{ts}。
  //               关闭后回到原行为（仅写一份 tasks.json）。备份文件独立占用 vault 空间。
  backupTasksOnSave: true,
  // v2.8: 启动时自动扫描源文件目录，默认关闭。
  //   自动扫描会连带触发云端解析与 MiniMax 调用（计费），属于高成本行为，
  //   必须由用户在设置中明确开启；关闭时只能通过控制台「扫描并自动处理」
  //   按钮或「扫描源文件」命令手动触发。
  autoScanOnStartup: false
};

function migrateSettings(stored = {}) {
  const source = stored && typeof stored === 'object' ? stored : {};
  const migrated = {};
  for (const key of Object.keys(DEFAULT_SETTINGS)) {
    if (Object.hasOwn(source, key)) migrated[key] = source[key];
  }
  migrated.settingsVersion = 17;
  migrated.aiProvider = 'minimax';
  migrated.bidIntakePath = DEFAULT_SETTINGS.bidIntakePath;
  migrated.businessIntakePath = DEFAULT_SETTINGS.businessIntakePath;
  migrated.bidOutputPath = DEFAULT_SETTINGS.bidOutputPath;
  migrated.businessOutputPath = DEFAULT_SETTINGS.businessOutputPath;
  migrated.intakePath = DEFAULT_SETTINGS.intakePath;
  migrated.outputPath = DEFAULT_SETTINGS.outputPath;
  migrated.artifactsPath = DEFAULT_SETTINGS.artifactsPath;
  migrated.draftPath = DEFAULT_SETTINGS.draftPath;
  migrated.logPath = DEFAULT_SETTINGS.logPath;
  migrated.pdfExtractionOrder = DEFAULT_SETTINGS.pdfExtractionOrder;
  // v1.1.1 升级门槛：用户在 v1.1.0 之前 < 0.9 时全部提升到 0.9；用户主动调低的（< 0.85）保持原意
  const storedThreshold = Number(source.autoApproveConfidenceThreshold);
  if (Number.isFinite(storedThreshold) && storedThreshold < 0.9) {
    migrated.autoApproveConfidenceThreshold = storedThreshold < 0.85
      ? storedThreshold
      : DEFAULT_SETTINGS.autoApproveConfidenceThreshold;
  } else if (!Number.isFinite(storedThreshold)) {
    migrated.autoApproveConfidenceThreshold = DEFAULT_SETTINGS.autoApproveConfidenceThreshold;
  } else {
    migrated.autoApproveConfidenceThreshold = storedThreshold;
  }
  if (!migrated.minimaxEndpoint
    || migrated.minimaxEndpoint === 'https://api.minimax.chat/v1/chat/completions'
    || migrated.minimaxEndpoint === 'https://api.minimaxi.com/v1/chat/completions') {
    migrated.minimaxEndpoint = DEFAULT_SETTINGS.minimaxEndpoint;
  }
  if (!migrated.aiMaxChunks || Number(migrated.aiMaxChunks) <= 8) migrated.aiMaxChunks = DEFAULT_SETTINGS.aiMaxChunks;
  if (!migrated.aiChunkSize || Number(migrated.aiChunkSize) === 12000) migrated.aiChunkSize = DEFAULT_SETTINGS.aiChunkSize;
  if (!Number(migrated.maxPointsPerRequest)) migrated.maxPointsPerRequest = DEFAULT_SETTINGS.maxPointsPerRequest;
  migrated.maxPointsPerRequest = Math.max(1, Math.min(3, Math.round(Number(migrated.maxPointsPerRequest))));
  if (!Number(migrated.summaryConcurrency)) migrated.summaryConcurrency = DEFAULT_SETTINGS.summaryConcurrency;
  migrated.summaryConcurrency = Math.max(1, Math.min(3, Math.round(Number(migrated.summaryConcurrency))));
  if (!Number(migrated.atomizationConcurrency)) migrated.atomizationConcurrency = DEFAULT_SETTINGS.atomizationConcurrency;
  migrated.atomizationConcurrency = Math.max(1, Math.min(3, Math.round(Number(migrated.atomizationConcurrency))));
  if (!Number(migrated.shortDocumentMaxCards)) migrated.shortDocumentMaxCards = DEFAULT_SETTINGS.shortDocumentMaxCards;
  migrated.shortDocumentMaxCards = Math.max(5, Math.min(100, Math.round(Number(migrated.shortDocumentMaxCards))));
  // v2.7: 切片重叠比例与小节合并开关键迁移（非法值回退默认）
  const storedOverlapRatio = Number(migrated.chunkOverlapRatio);
  if (!Number.isFinite(storedOverlapRatio) || storedOverlapRatio < 0 || storedOverlapRatio > 0.5) {
    migrated.chunkOverlapRatio = DEFAULT_SETTINGS.chunkOverlapRatio;
  }
  if (migrated.coalesceTinyChunks === undefined) migrated.coalesceTinyChunks = DEFAULT_SETTINGS.coalesceTinyChunks;
  // v2.8: 自动扫描默认关闭，只有明确存过 true 的才保持开启（布尔强转，杜绝字符串 "false" 之类脏值）
  migrated.autoScanOnStartup = source.autoScanOnStartup === true;
  if (!Number(migrated.pdfExternalTimeoutMs) || Number(migrated.pdfExternalTimeoutMs) <= 300000) {
    migrated.pdfExternalTimeoutMs = DEFAULT_SETTINGS.pdfExternalTimeoutMs;
  }
  if (!Number(migrated.aiRequestTimeoutMs) || Number(migrated.aiRequestTimeoutMs) <= 180000) {
    migrated.aiRequestTimeoutMs = DEFAULT_SETTINGS.aiRequestTimeoutMs;
  }
  if (!Number(migrated.maxConcurrentDocuments) || Number(migrated.maxConcurrentDocuments) < 2) {
    migrated.maxConcurrentDocuments = DEFAULT_SETTINGS.maxConcurrentDocuments;
  }
  if (migrated.pdfAllowExternalUpload === undefined) migrated.pdfAllowExternalUpload = false;
  if (!Number(migrated.rateLimitMs)) migrated.rateLimitMs = DEFAULT_SETTINGS.rateLimitMs;
  if (!Number(migrated.rateLimitMaxConcurrent)) migrated.rateLimitMaxConcurrent = DEFAULT_SETTINGS.rateLimitMaxConcurrent;
  if (migrated.useEnvKeys === undefined) migrated.useEnvKeys = DEFAULT_SETTINGS.useEnvKeys;
  if (!Number(migrated.aiRequestMaxAttempts)) migrated.aiRequestMaxAttempts = DEFAULT_SETTINGS.aiRequestMaxAttempts;
  if (!Number(migrated.aiRetryBaseMs)) migrated.aiRetryBaseMs = DEFAULT_SETTINGS.aiRetryBaseMs;
  if (migrated.useStreamingAi === undefined) migrated.useStreamingAi = DEFAULT_SETTINGS.useStreamingAi;
  if (!Number(migrated.rateLimitBackoffMaxMs)) migrated.rateLimitBackoffMaxMs = DEFAULT_SETTINGS.rateLimitBackoffMaxMs;
  if (!Number(migrated.rateLimitWindowSize)) migrated.rateLimitWindowSize = DEFAULT_SETTINGS.rateLimitWindowSize;
  return migrated;
}

const SOURCE_TYPE_BY_EXT = {
  '.md': 'md',
  '.txt': 'txt',
  '.pdf': 'pdf',
  '.doc': 'docx',
  '.docx': 'docx',
  '.ppt': 'pptx',
  '.pptx': 'pptx',
  '.xls': 'xlsx',
  '.xlsx': 'xlsx',
  '.eml': 'email',
  '.msg': 'outlook-msg',
  '.html': 'html',
  '.htm': 'html',
  '.png': 'image',
  '.jpg': 'image',
  '.jpeg': 'image',
  '.webp': 'image',
  '.gif': 'image',
  '.tif': 'image',
  '.tiff': 'image',
  '.mp4': 'video',
  '.mov': 'video',
  '.avi': 'video',
  '.mkv': 'video',
  '.mp3': 'audio',
  '.wav': 'audio',
  '.m4a': 'audio'
};

const PROCESSABLE_TYPES = new Set(['md', 'txt', 'pdf', 'docx', 'pptx', 'xlsx', 'email', 'html', 'image']);

function normalizeVaultPath(filePath) {
  return String(filePath || '').replace(/\\/g, '/').replace(/^\/+/, '');
}

// v1.1.2: 把 Buffer.from 的副作用收拢到一处。
// 当 input 是 null / undefined / 字符串数字时，行为统一：空缓冲区。
// 同时避免 ArrayBuffer/SharedArrayBuffer/Uint8Array 等非 Buffer 输入在
// multipart / uploadBody 等路径中产生 Buffer.from(... ) 期待 Buffer 的边界 bug。
function safeBufferFrom(input, encoding) {
  if (input == null) return Buffer.alloc(0);
  if (Buffer.isBuffer(input)) return encoding ? input.toString(encoding) : input;
  if (input instanceof ArrayBuffer) return Buffer.from(input);
  if (ArrayBuffer.isView(input)) return Buffer.from(input.buffer, input.byteOffset, input.byteLength);
  if (typeof input === 'string') return encoding ? Buffer.from(input, encoding) : Buffer.from(input, 'utf8');
  try { return Buffer.from(String(input), 'utf8'); } catch { return Buffer.alloc(0); }
}


function detectSourceType(filePath) {
  const ext = path.extname(String(filePath || '')).toLowerCase();
  return SOURCE_TYPE_BY_EXT[ext] || 'unknown';
}

function isProcessableSource(filePath) {
  return PROCESSABLE_TYPES.has(detectSourceType(filePath));
}

function sourceHash(buffer) {
  return crypto.createHash('sha256').update(buffer || Buffer.alloc(0)).digest('hex');
}

function buildTaskFromFile(sourcePath, buffer, now = new Date()) {
  const normalized = normalizeVaultPath(sourcePath);
  const hash = sourceHash(buffer);
  const time = now.toISOString();
  return {
    taskId: `slicer-${hash.slice(0, 12)}`,
    sourcePath: normalized,
    sourceHash: hash,
    sourceType: detectSourceType(normalized),
    status: isProcessableSource(normalized) ? 'queued' : futureMediaStatus(normalized),
    createdAt: time,
    updatedAt: time,
    draftFiles: [],
    errors: []
  };
}

function futureMediaStatus(filePath) {
  const sourceType = detectSourceType(filePath);
  if (sourceType === 'video' || sourceType === 'audio') return 'unsupported_media';
  if (sourceType === 'outlook-msg') return 'unsupported_media';
  return 'skipped';
}

function statusCounts(tasks) {
  const counts = {
    total: tasks.length,
    pending: 0,
    processing: 0,
    needsReview: 0,
    failed: 0,
    written: 0,
    skipped: 0
  };
  const processing = new Set(['parsing', 'classifying', 'summarizing', 'atomizing', 'validating', 'writing']);
  for (const task of tasks) {
    if (task.status === 'queued' || task.status === 'discovered') counts.pending += 1;
    if (processing.has(task.status)) counts.processing += 1;
    if (task.status === 'needs_review') counts.needsReview += 1;
    if (task.status === 'failed') counts.failed += 1;
    if (Array.isArray(task.written_card_ids) && task.written_card_ids.length) counts.written += task.written_card_ids.length;
    else if (Array.isArray(task.writtenFiles) && task.writtenFiles.length) counts.written += task.writtenFiles.length;
    else if (task.status === 'written' || task.status === 'archived') counts.written += 1;
    if (task.status === 'skipped' || task.status === 'unsupported' || task.status === 'unsupported_media' || task.status === 'needs_ocr') counts.skipped += 1;
  }
  return counts;
}

function tasksPath(settings = DEFAULT_SETTINGS) {
  return normalizeVaultPath(`${settings.logPath}/${settings.tasksFileName || 'tasks.json'}`);
}

function rollbackPath(settings = DEFAULT_SETTINGS) {
  return normalizeVaultPath(`${settings.logPath}/${settings.rollbackFileName || 'rollback.json'}`);
}

module.exports = {
  DEFAULT_SETTINGS,
  buildTaskFromFile,
  detectSourceType,
  futureMediaStatus,
  isProcessableSource,
  migrateSettings,
  normalizeVaultPath,
  rollbackPath,
  sourceHash,
  statusCounts,
  tasksPath
};

},
/**
 * @module src/core/tags
 * 标签库解析 / Map_Index 建议 / 卡片字段校验
 * @exports parseTagLibrary
 * @exports suggestMapIndex
 * @exports validateCard
 */
"src/core/tags.js": function(require, module, exports) {
function emptyLibrary() {
  return {
    all: new Set(),
    categories: new Set(),
    tagL1: new Set(),
    tagL2: new Set(),
    eventTypes: new Set(),
    infoTypes: new Set(),
    statuses: new Set(),
    mapByCategory: new Map(),
    mapByTriplet: new Map()
  };
}

function parseTagLibrary(markdown) {
  const library = emptyLibrary();
  const tagPattern = /`(#[a-zA-Z0-9/_-]+)`/g;
  const mapPattern = /`\[\[([^`\]]+)\]\]`|\[\[([^\]]+)\]\]/;
  for (const line of String(markdown || '').split(/\r?\n/)) {
    const tags = [...line.matchAll(tagPattern)].map((match) => match[1]);
    if (tags.length === 0) continue;
    const mapMatch = line.match(mapPattern);
    const mapIndex = mapMatch ? `[[${mapMatch[1] || mapMatch[2]}]]` : '';
    for (const tag of tags) {
      library.all.add(tag);
      if (tag.startsWith('#cat/') || tag.startsWith('#domain/')) {
        library.categories.add(tag);
        if (mapIndex) library.mapByCategory.set(tag, mapIndex);
      }
      if (tag.startsWith('#l1/')) library.tagL1.add(tag);
      if (tag.startsWith('#l2/')) library.tagL2.add(tag);
      if (tag.startsWith('#event/') || tag.startsWith('#type/')) library.eventTypes.add(tag);
      if (tag.startsWith('#info/')) library.infoTypes.add(tag);
      if (tag.startsWith('#status/')) library.statuses.add(tag);
    }
    if (tags.length >= 3 && mapIndex) {
      library.mapByTriplet.set(tripletKey(tags[0], tags[1], tags[2]), mapIndex);
    }
  }
  seedFallbacks(library);
  return library;
}

function seedFallbacks(library) {
  const defaults = {
    categories: ['#cat/general-knowledge', '#cat/design', '#cat/quality'],
    tagL1: ['#l1/document-control', '#l1/hvac', '#l1/ncr-defect'],
    tagL2: ['#l2/requirement', '#l2/value-engineering', '#l2/corrective-action'],
    eventTypes: ['#event/meeting', '#event/decision', '#event/issue', '#event/nonconformance'],
    infoTypes: ['#info/spec', '#info/requirement', '#info/method'],
    statuses: ['#status/pending_review', '#status/needs_fix', '#status/approved', '#status/uncategorized']
  };
  for (const [field, tags] of Object.entries(defaults)) {
    if (library[field].size) continue;
    for (const tag of tags) {
      library[field].add(tag);
      library.all.add(tag);
    }
  }
  if (!library.mapByCategory.has('#cat/general-knowledge')) {
    library.mapByCategory.set('#cat/general-knowledge', '[[MOC_通用知识库]]');
  }
  if (!library.mapByCategory.has('#cat/design')) {
    library.mapByCategory.set('#cat/design', '[[MOC_设计管理]]');
  }
  if (!library.mapByCategory.has('#cat/quality')) {
    library.mapByCategory.set('#cat/quality', '[[MOC_质量管理]]');
  }
  const domainMaps = {
    '#domain/arch': '[[MOC_建筑工程]]',
    '#domain/struct': '[[MOC_结构工程]]',
    '#domain/process': '[[MOC_工艺生产线]]',
    '#domain/hvac': '[[MOC_暖通空调]]',
    '#domain/elec': '[[MOC_电气工程]]',
    '#domain/plumb': '[[MOC_给排水]]',
    '#domain/cost': '[[MOC_成本与VECD优化]]',
    '#domain/safe': '[[MOC_安全与合规]]'
  };
  for (const [tag, moc] of Object.entries(domainMaps)) {
    if (library.categories.has(tag) && !library.mapByCategory.has(tag)) {
      library.mapByCategory.set(tag, moc);
    }
  }
}

function tripletKey(category, tagL1, tagL2) {
  return `${category}|${tagL1}|${tagL2}`;
}

function suggestMapIndex(library, category, tagL1, tagL2) {
  return library.mapByTriplet.get(tripletKey(category, tagL1, tagL2))
    || library.mapByCategory.get(category)
    || '[[MOC_待分类]]';
}

function validateCard(library, card) {
  const errors = [];
  requireInSet(errors, library.categories, card.Category, 'Category');
  requireInSet(errors, library.tagL1, card.TagL1, 'TagL1');
  requireInSet(errors, library.tagL2, card.TagL2, 'TagL2');
  requireInSet(errors, library.statuses, card.Status, 'Status');

  if (card.Card_Type === 'event') {
    requireInSet(errors, library.eventTypes, card.Event_Type, 'Event_Type');
  } else if (card.Card_Type === 'info') {
    requireInSet(errors, library.infoTypes, card.Info_Type, 'Info_Type');
  } else {
    errors.push(`Card_Type must be event or info: ${card.Card_Type || ''}`);
  }

  for (const field of ['Source_File', 'Source_Path', 'Source_Hash']) {
    if (!card[field]) errors.push(`${field} is required`);
  }
  if (typeof card.Confidence !== 'number') errors.push('Confidence must be a number');

  return { valid: errors.length === 0, errors };
}

function requireInSet(errors, set, value, label) {
  if (!value || !set.has(value)) errors.push(`${label} is not in Tag Library: ${value || ''}`);
}

module.exports = {
  parseTagLibrary,
  suggestMapIndex,
  validateCard
};

},
/**
 * @module src/core/extractors
 * 二进制 / 纯文本文件解析入口；委托给 document-parser + external-pdf
 * @exports extractTextFromBuffer
 */
"src/core/extractors.js": function(require, module, exports) {
const { createParsePackage, documentPlan } = require("src/core/document-parser.js");
const { extractDocumentWithApis } = require("src/core/external-pdf.js");

async function extractTextFromBuffer(filePath, buffer, options = {}) {
  const plan = documentPlan(filePath);
  if (plan.mode === 'unsupported') {
    return {
      status: 'unsupported_media',
      text: '',
      sourceType: plan.sourceType,
      message: unsupportedMessage(plan.sourceType)
    };
  }
  if (plan.mode === 'text') {
    return withParsePackage(textResult(buffer, plan.sourceType), {
      sourcePath: filePath,
      buffer,
      sourceType: plan.sourceType,
      parser: 'text-normalizer'
    });
  }
  if (plan.mode === 'email') {
    // v2.9.0: 改走 MIME 解析（parseEmailMessage），提取附件二进制与完整头部。
    const email = parseEmailMessage(buffer);
    const attachmentMeta = (email.attachments || []).map((item) => ({
      filename: item.filename,
      contentType: item.contentType,
      size: item.data ? item.data.length : 0
    }));
    // v2.9.0: 空正文但有附件的邮件不再判 failed，合成占位正文，
    //   保证附件一定能进入保存/切片流程，同时给总结阶段附件上下文。
    const bodyText = email.text || (attachmentMeta.length
      ? `本邮件正文为空，包含 ${attachmentMeta.length} 个附件：${attachmentMeta.map((item) => item.filename).join('、')}。`
      : '');
    const metadata = {
      subject: email.subject,
      from: email.from,
      to: email.to,
      cc: email.cc,
      date: email.date,
      messageId: email.messageId,
      sourceEncoding: 'mime',
      attachments: attachmentMeta
    };
    const result = readableTextResult(bodyText, 'email', { encoding: 'mime' });
    result.title = email.subject;
    result.metadata = metadata;
    // 附件二进制挂在 result 上（不进 parsePackage 的 JSON 序列化），
    // 由 processTask 落盘到 _attachments 并入队切片。
    result.attachments = email.attachments || [];
    return withParsePackage(result, {
      sourcePath: filePath,
      buffer,
      sourceType: 'email',
      parser: 'eml-parser',
      metadata
    });
  }

  const fileName = String(filePath || '').split(/[\\/]/).pop() || 'source';
  const config = Object.assign({}, options.pdfExtractor || {}, options.documentExtractor || {}, {
    fileName,
    order: plan.engines.join(','),
    mineruApiModel: plan.mineruModel
  });
  const external = await extractDocumentWithApis(buffer, config);
  if (!external || external.status !== 'ok') {
    return {
      status: 'failed',
      text: '',
      sourceType: plan.sourceType,
      sourceEncoding: external?.engine || '',
      sourceLanguage: 'unknown',
      extractor: external?.engine || 'document-api',
      message: external?.message || '云端文档解析失败。'
    };
  }
  const text = String(external.text || '').trim();
  return withParsePackage({
    status: 'ok',
    text,
    sourceType: plan.sourceType,
    sourceEncoding: external.engine || 'document-api',
    sourceLanguage: detectDominantLanguage(text),
    extractor: external.engine || 'document-api',
    metadata: external.metadata || {}
  }, {
    sourcePath: filePath,
    buffer,
    sourceType: plan.sourceType,
    parser: external.engine,
    parserModel: config.mineruApiModel,
    remoteJobId: external.remoteJobId,
    pages: external.pages,
    images: external.images
  });
}

function withParsePackage(result, options) {
  if (!result || result.status !== 'ok') return result;
  result.parsePackage = createParsePackage(Object.assign({}, options, {
    markdown: result.text,
    language: result.sourceLanguage || 'unknown'
  }));
  return result;
}

function unsupportedMessage(sourceType) {
  if (sourceType === 'outlook-msg') return '暂不支持 Outlook MSG，请导出为 EML 后处理。';
  if (sourceType === 'video' || sourceType === 'audio') return '音视频处理属于后续版本能力。';
  return '不支持的文件类型。';
}

function textResult(buffer, sourceType) {
  const decoded = decodeTextBuffer(buffer);
  return readableTextResult(decoded.text, sourceType, decoded);
}

function readableTextResult(text, sourceType, decoded = {}) {
  const clean = String(text || '').trim();
  if (looksLikeGibberish(clean)) {
    return {
      status: 'failed',
      text: '',
      sourceType,
      sourceEncoding: decoded.encoding || '',
      sourceLanguage: detectDominantLanguage(clean),
      message: '文本内容疑似编码错误或二进制乱码，请转换为受支持的文本编码后重试。'
    };
  }
  return {
    status: clean ? 'ok' : 'failed',
    text: clean,
    sourceType,
    sourceEncoding: decoded.encoding || '',
    sourceLanguage: detectDominantLanguage(clean),
    message: clean ? '' : '未读取到可用文本。'
  };
}

function decodeTextBuffer(buffer) {
  const input = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer || '');
  if (input.length === 0) return decodedCandidate('utf-8', '');
  // v2.9.2: 增强二进制检测——常见二进制文件魔数优先拒收
  // PNG: 89 50 4E 47 0D 0A 1A 0A
  // JPEG: FF D8 FF
  // PDF: 25 50 44 46
  // ZIP: 50 4B 03 04 或 50 4B 05 06 或 50 4B 07 08
  // RAR: 52 61 72 21
  if (input.length >= 4) {
    // PNG检测：前8字节完整匹配
    if (input.length >= 8 && input[0] === 0x89 && input[1] === 0x50 && input[2] === 0x4E && input[3] === 0x47) {
      return decodedCandidate('binary-rejected', '');
    }
    // JPEG检测：FF D8 FF
    if (input[0] === 0xFF && input[1] === 0xD8 && input[2] === 0xFF) {
      return decodedCandidate('binary-rejected', '');
    }
    // PDF检测：25 50 44 46 (%PDF)
    if (input[0] === 0x25 && input[1] === 0x50 && input[2] === 0x44 && input[3] === 0x46) {
      return decodedCandidate('binary-rejected', '');
    }
    // ZIP检测：50 4B (PK)
    if (input[0] === 0x50 && input[1] === 0x4B) {
      return decodedCandidate('binary-rejected', '');
    }
    // RAR检测：52 61 72 21 (Rar!)
    if (input[0] === 0x52 && input[1] === 0x61 && input[2] === 0x72 && input[3] === 0x21) {
      return decodedCandidate('binary-rejected', '');
    }
  }
  // 文本缓冲区告警：含 NUL 字节的文件几乎可以肯定是二进制（PDF/ZIP/图片等），
  // 即便扩展名是 .md/.txt 也要拒收，避免二进制字节流被当文本送进 AI。
  const nulCount = countByte(input, 0x00);
  if (nulCount > 0 && (!looksLikeLegitimateText(input) || nulCount > 2)) {
    // v2.9.1: 无 BOM 的 UTF-16 文本（ASCII 字符隔字节为 0x00）含大量 NUL，
    //   旧逻辑直接按二进制拒收。字节分布符合 UTF-16 特征时放行，交给候选评分。
    if (!looksLikeUtf16Bytes(input)) return decodedCandidate('binary-rejected', '');
  }
  if (input.length >= 3 && input[0] === 0xef && input[1] === 0xbb && input[2] === 0xbf) {
    return decodedCandidate('utf-8-bom', input.slice(3).toString('utf8'));
  }
  if (input.length >= 2 && input[0] === 0xff && input[1] === 0xfe) {
    return decodedCandidate('utf-16le-bom', input.slice(2).toString('utf16le'));
  }
  if (input.length >= 2 && input[0] === 0xfe && input[1] === 0xff) {
    return decodeWithTextDecoder(input.slice(2), 'utf-16be')
      || decodedCandidate('utf-16be-bom', swapUtf16Bytes(input.slice(2)).toString('utf16le'));
  }

  // v2.9.2: 性能优化——先尝试 UTF-8 快速路径
  // 对于纯 ASCII 或有效 UTF-8，直接返回不尝试其他编码
  const utf8Text = input.toString('utf8');
  const utf8Valid = !utf8Text.includes('\uFFFD') && utf8Text.length > 0;
  let hasNonAscii = false;
  for (let i = 0; i < utf8Text.length && i < 1000; i += 1) {
    if (utf8Text.charCodeAt(i) > 127) { hasNonAscii = true; break; }
  }
  // UTF-8 快速路径：有效 UTF-8 + 含非ASCII → 直接返回
  // v2.9.2: 不再检查ShiftJIS字节特征，因为有效UTF-8本身已经是强信号
  if (utf8Valid && hasNonAscii) {
    const score = readabilityScore(utf8Text);
    if (score > 0.8) return decodedCandidate('utf-8', utf8Text);
  }

  // v2.9.1: gb18030 提到 shift_jis/windows-31j 之前——评分平手时 GB 优先。
  //   真日文文档靠 looksLikeShiftJisBytes 的 +0.35 加分仍会胜出，不受影响；
  //   而 GBK 文档被 ShiftJIS 解成半角片假名是最常见的静默乱码（评分经常打平）。
  const candidates = [
    decodedCandidate('utf-8', utf8Text),
    decodedCandidate('utf-16le', input.toString('utf16le')),
    decodeWithTextDecoder(input, 'utf-16be'),
    decodeWithTextDecoder(input, 'gb18030'),
    decodeWithTextDecoder(input, 'shift_jis'),
    decodeWithTextDecoder(input, 'windows-31j'),
    decodeWithTextDecoder(input, 'big5'),
    // v2.9.1: 韩文 EUC-KR 与西欧 windows-1252 候选。
    //   旧版缺 euc-kr → 韩文被 gb18030 静默误解成错误汉字（无任何报错）；
    //   缺 windows-1252 → cp1252 特有字符（€ ’ “ 等 0x80-0x9F 区）按 latin1 解出 C1 控制符。
    //   gb18030 排在 big5/euc-kr 之前：平分时 GB 优先（本插件语料以大陆简体为主）。
    decodeWithTextDecoder(input, 'euc-kr'),
    decodeWithTextDecoder(input, 'windows-1252'),
    decodedCandidate('latin1', input.toString('latin1'))
  ].filter(Boolean);
  for (const candidate of candidates) {
    candidate.score += encodingHeuristicBonus(input, candidate.encoding, candidate.text);
  }
  candidates.sort((a, b) => b.score - a.score);
  // 自适应兜底：当最优候选的 readability 分数仍低于阈值时，认为解码失败。
  // 返回 'utf-8' 空文本而不是乱码文本，让调用方走 failed 分支。
  const best = candidates[0];
  if (!best || best.score < DECODE_MIN_CONFIDENCE) {
    return decodedCandidate('low-confidence', best ? best.text : '');
  }
  return best;
}

// 文本缓冲区中含 NUL 字节时是否仍可能是合法文本？
// 唯一例外是使用了 PUA/控制字符的某些专业日志，但通用插件场景下 NUL ≈ 二进制。
function looksLikeLegitimateText(buffer) {
  if (Buffer.isBuffer(buffer) && buffer.length >= 3) {
    if (buffer[0] === 0xef && buffer[1] === 0xbb && buffer[2] === 0xbf) return true;
    if (buffer[0] === 0xff && buffer[1] === 0xfe) return true;
    if (buffer[0] === 0xfe && buffer[1] === 0xff) return true;
  }
  return false;
}

function countByte(buffer, byte) {
  let n = 0;
  const len = Buffer.isBuffer(buffer) ? buffer.length : 0;
  for (let i = 0; i < len; i += 1) if (buffer[i] === byte) n += 1;
  return n;
}

const DECODE_MIN_CONFIDENCE = -0.15;

function encodingHeuristicBonus(buffer, encoding, text) {
  const enc = String(encoding || '').toLowerCase();
  const looksSjis = looksLikeShiftJisBytes(buffer);

  // v2.9.2: Shift_JIS 最高优先级——如果字节符合SJIS特征
  if (looksSjis) {
    // Shift_JIS / windows-31j 且包含日文字符（假名或汉字）
    if (enc === 'shift_jis' || enc === 'windows-31j') {
      if (/[぀-ヿ一-鿿]/.test(text)) return 0.65;  // 强于其他编码
      return 0.45;  // 即使没有日文字符，字节特征也是强信号
    }
    // 其他编码尝试解码SJIS字节流，降低优先级
    if (enc === 'windows-1252' || enc === 'latin1' || enc === 'gb18030') {
      return -0.5;
    }
  }

  // v2.9.1: UTF-8 优先门。旧版仅在「有效 UTF-8 且含 CJK」时加分，导致
  //   越南语/俄语/法语等无 CJK 的合法 UTF-8 文档被 ShiftJIS/GB18030 候选
  //   的伪 CJK 解码反超（UTF-8 三字节序列与 SJIS/GBK 双字节区间高度重叠）。
  //   新判据：零替换字符 + 含任意非 ASCII 字节 → 该字节流几乎不可能是其他
  //   编码（GBK/SJIS/Big5/EUC-KR 文本同时构成合法 UTF-8 序列的概率趋近于 0；
  //   纯 ASCII 各编码解码相同，不需要仲裁）→ 强倾向 UTF-8 并压制误码候选。
  const utf8Text = buffer.toString('utf8');
  const utf8Valid = !utf8Text.includes('\uFFFD') && utf8Text.length > 0;
  let hasNonAscii = false;
  for (let i = 0; i < utf8Text.length; i += 1) {
    if (utf8Text.charCodeAt(i) > 127) { hasNonAscii = true; break; }
  }
  if (utf8Valid && hasNonAscii) {
    if (enc === 'utf-8' || enc === 'utf-8-bom') return hasCjk(utf8Text) ? 0.5 : 0.45;
    if (enc === 'shift_jis' || enc === 'windows-31j' || enc === 'gb18030' || enc === 'big5' || enc === 'euc-kr') return -0.5;
  }
  if ((enc === 'utf-16le' || enc === 'utf-16be') && !looksLikeUtf16Bytes(buffer)) return -2;
  if ((enc === 'gb18030' || enc === 'big5') && looksSjis) return -0.12;
  // v2.9.1: 韩文 EUC-KR——字节符合 KS X 1001 韩文字区特征且解码后出现
  //   韩文音节、无替换字符 → 强烈倾向 euc-kr；符合该字节特征的缓冲同时
  //   惩罚 gb18030/big5/sjis，避免韩文被静默误解成错误汉字。
  const eucKrBytes = looksLikeEucKrBytes(buffer);
  if (enc === 'euc-kr' && eucKrBytes && /[가-힣]/.test(text) && !text.includes('�')) return 0.6;
  if ((enc === 'gb18030' || enc === 'big5' || enc === 'shift_jis' || enc === 'windows-31j') && eucKrBytes) return -0.3;
  // v2.9.1: Big5——解码出现注音符号即可较有把握判定为台湾内容。
  //   不单独按字节结构加分：Big5 与 GB2312 字节段高度重叠，字节启发会把
  //   简体中文误判成 Big5（静默乱码），平分时保持 gb18030 优先。
  if (enc === 'big5' && /[ㄅ-ㄯ]/.test(text)) return 0.35;
  // v2.9.1: 西欧单字节编码——合法重音字母现已计入可读字符不再扣分。
  //   仅当「高字节密度异常（>15%）且解码文本确实带乱码证据」才惩罚：
  //   GBK 误解成 latin1 会产生大量 C1 控制符，误解成 cp1252 会产生乱码
  //   二联体（C0-DF 后跟 80-BF 区符号）；真西欧文本（含 € " ' 等
  //   cp1252 专有符号）两个信号都为 0，不受惩罚。
  if ((enc === 'latin1' || enc === 'windows-1252') && highByteRatio(buffer) > 0.15) {
    const chars = [...String(text || '')];
    const tn = chars.length || 1;
    const c1 = chars.filter((ch) => { const cp = ch.codePointAt(0); return cp >= 0x80 && cp <= 0x9f; }).length / tn;
    const dig = countMojibakeDigraphs(text) / tn;
    if (c1 > 0.01 || dig > 0.02) return -0.6;
  }
  // v2.9.2: 单字节 windows-1252 专有符号（0x80-0x9F 区）强倾向 cp1252
  //   例如：0x80 = €，0x93/0x94 = ""，0x96 = –，0x97 = —
  //   这些字节在 GB18030/ShiftJIS/EUC-KR 中都不构成有意义的单字符，只有 cp1252 能正确解码
  if (enc === 'windows-1252' && !looksSjis) {
    // 检查是否包含 cp1252 专有符号（€ "' 等 0x80-0x9F 区）
    if (/[€\u201A\u0192\u201E\u2026\u2020\u2021\u02C6\u2030\u0160\u2039\u0152\u017D\u2018\u2019\u201C\u201D\u2022\u2013\u2014\u0161\u203A\u0153\u017E\u0178]/.test(text)) {
      return 0.4;
    }
  }
  if (enc === 'latin1') return -0.2;
  return 0;
}

// v2.9.1: KS X 1001 韩文字区字节特征：首字节 B0-C8 / 尾字节 A1-FE 的双字节对
//   占绝对多数（其他高位双字节对不超过其 35%），且 ASCII 可打印字节（空格、
//   英文、数字——韩文有词间空格而中文几乎没有）占比 > 12%。
//   双条件排除 GBK 简体中文：GB2312 一级汉字区（B0A1-D7F9）虽也产生 B0-C8 对，
//   但同时有大量 C9+ 首字节对（otherPairs 超标）且几乎没有 ASCII 空格。
function looksLikeEucKrBytes(buffer) {
  let hangulPairs = 0;
  let otherPairs = 0;
  let ascii = 0;
  const len = Buffer.isBuffer(buffer) ? buffer.length : 0;
  for (let i = 0; i < len; i += 1) {
    const byte = buffer[i];
    if (byte >= 0x20 && byte <= 0x7e) ascii += 1;
    if (i + 1 >= len) break;
    const trail = buffer[i + 1];
    if (byte >= 0xb0 && byte <= 0xc8 && trail >= 0xa1 && trail <= 0xfe) {
      hangulPairs += 1;
      i += 1;
    } else if (byte >= 0x81 && byte <= 0xfe && trail >= 0x41 && trail <= 0xfe && trail !== 0x7f) {
      otherPairs += 1;
      i += 1;
    }
  }
  // 阈值说明：韩文词间空格使 ASCII 占比通常 >15%，但密集短句可低至 5-7%；
  //   简体中文几乎无空格，otherPairs 条件（<35%）已排除 GB2312 一级汉字区误命中。
  //   v2.9.2: 短文本（仅1-2个韩文对）放宽阈值，避免极短韩文被GB18030反超。
  if (hangulPairs === 0) return false;
  // 超短文本：所有双字节对都是韩文音节区，无其他高位字节对 → 高置信度韩文
  if (hangulPairs <= 2 && otherPairs === 0) return true;
  // 常规文本：韩文音节区占优，其他字节对 <35%，ASCII 占比合理
  return hangulPairs >= 2 && otherPairs <= hangulPairs * 0.35;
}

function highByteRatio(buffer) {
  const len = Buffer.isBuffer(buffer) ? buffer.length : 0;
  if (!len) return 0;
  let high = 0;
  for (let i = 0; i < len; i += 1) if (buffer[i] >= 0x80) high += 1;
  return high / len;
}

function looksLikeUtf16Bytes(buffer) {
  if (buffer.length < 4) return false;
  let evenZeros = 0;
  let oddZeros = 0;
  const pairs = Math.floor(buffer.length / 2);
  for (let i = 0; i + 1 < buffer.length; i += 2) {
    if (buffer[i] === 0) evenZeros += 1;
    if (buffer[i + 1] === 0) oddZeros += 1;
  }
  return evenZeros / pairs > 0.25 || oddZeros / pairs > 0.25;
}

// v2.9.1 收紧：旧版「有一个合法双字节对就判定 ShiftJIS」——GBK 文档里
//   E0-FC 首字节约占 13%，短文极易偶然凑出一两对，被加 SJIS 分后
//   中文静默解成半角片假名乱码。新增条件：合法对覆盖的高位字节须占
//   全部高位字节的 60% 以上（真 SJIS 文档高位字节几乎都是成对的；
//   GBK 误凑对只占 ~13%；极短日文如「日本」4 字节 2 对仍满足）。
function looksLikeShiftJisBytes(buffer) {
  let pairs = 0;
  let validPairs = 0;
  let highBytes = 0;
  for (let i = 0; i < buffer.length; i += 1) {
    const lead = buffer[i];
    if (lead >= 0x80) highBytes += 1;
    if (i + 1 >= buffer.length) break;
    const trail = buffer[i + 1];
    if ((lead >= 0x81 && lead <= 0x9f) || (lead >= 0xe0 && lead <= 0xfc)) {
      pairs += 1;
      if ((trail >= 0x40 && trail <= 0x7e) || (trail >= 0x80 && trail <= 0xfc)) validPairs += 1;
      i += 1;
    }
  }
  return pairs > 0 && validPairs / pairs >= 0.75 && validPairs * 2 >= highBytes * 0.6;
}

function hasCjk(text) {
  return /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}]/u.test(String(text || ''));
}

function decodeWithTextDecoder(buffer, encoding) {
  try {
    if (typeof TextDecoder !== 'function') return null;
    return decodedCandidate(encoding, new TextDecoder(encoding, { fatal: false }).decode(buffer));
  } catch {
    return null;
  }
}

function decodedCandidate(encoding, text) {
  return { encoding, text, score: readabilityScore(text) };
}

// v2.9.1: \u4E71\u7801\u4E8C\u8054\u4F53\uFF08mojibake digraph\uFF09\u2014\u2014UTF-8 \u591A\u5B57\u8282\u5E8F\u5217\u88AB\u8BEF\u6309 latin1/cp1252 \u5355\u5B57\u8282
//   \u89E3\u7801\u7684\u5178\u578B\u4EA7\u7269\uFF1A\u9AD8\u4F4D\u9996\u5B57\u8282\uFF08\u00C0-\u00FF\uFF09\u7D27\u8DDF\u4E00\u4E2A\u7EED\u5B57\u8282\uFF08\u20AC-\u00BF\uFF09\u3002\u5408\u6CD5\u897F\u6B27\u8BED\u8A00\u6587\u672C\u91CC
//   \u300C\u91CD\u97F3\u5B57\u6BCD + \u7EED\u5B57\u8282\u533A\u5B57\u7B26\u300D\u7684\u7EC4\u5408\u51E0\u4E4E\u4E0D\u51FA\u73B0\uFF0C\u662F\u6BD4\u300C\u811A\u672C\u767D\u540D\u5355\u300D\u53EF\u9760\u5F97\u591A\u7684\u4E71\u7801\u4FE1\u53F7\u3002
const MOJIBAKE_DIGRAPH_PATTERN = /[\u00C0-\u00DF][\u0080-\u00BF]/g;

function countMojibakeDigraphs(text) {
  const matches = String(text || '').match(MOJIBAKE_DIGRAPH_PATTERN);
  return matches ? matches.length : 0;
}

// v2.9.1: \u8BC4\u5206\u91CD\u6784\u2014\u2014\u65E7\u7248\u628A C0-FF \u91CD\u97F3\u5B57\u6BCD\u4E00\u5F8B\u5F53 mojibake \u6309\u300C\u4E2A\u6570\u300D\u6263\u5206\uFF0C
//   \u6CD5\u8BED\u6587\u6863\u91CC\u51E0\u5341\u4E2A \u00E9/\u00E0 \u5C31\u80FD\u628A\u5206\u6570\u6263\u7A7F\uFF08\u5B9E\u6D4B -5.7\uFF09\uFF0C\u5408\u6CD5\u6587\u6863\u88AB\u8BEF\u5224\u4E71\u7801\u4E22\u5F03\u3002
//   \u65B0\u7248\u5168\u90E8\u6309\u300C\u6BD4\u4F8B\u300D\u6263\u5206\uFF0C\u4E71\u7801\u4FE1\u53F7\u6362\u6210\u771F\u6B63\u7684\u4E09\u4EF6\u5957\uFF1A\u66FF\u6362\u5B57\u7B26 / \u63A7\u5236\u5B57\u7B26\uFF08\u542B
//   C1 \u533A 80-9F\uFF0CUTF-8 \u7EED\u5B57\u8282\u8BEF\u8BFB\u7684\u5178\u578B\u4EA7\u7269\uFF09/ \u4E71\u7801\u4E8C\u8054\u4F53\u3002
// v2.9.2: 性能优化版——避免对大文本创建字符数组
function readabilityScore(text) {
  const value = String(text || '');
  if (!value) return -100;
  const n = value.length;
  if (n === 0) return -100;

  // 性能优化：对大文本采样评估而非遍历全部
  const maxScan = n > 5000 ? Math.min(5000, Math.floor(n * 0.1)) : n;
  const step = n > maxScan ? Math.floor(n / maxScan) : 1;

  let replacement = 0;
  let controls = 0;
  let unexpected = 0;
  let readable = 0;
  let scanned = 0;

  for (let i = 0; i < n && scanned < maxScan; i += step) {
    const ch = value[i];
    const cp = ch.codePointAt(0);
    scanned += 1;

    if (ch === '\uFFFD') replacement += 1;
    else if (cp >= 0x00 && cp <= 0x08 || cp >= 0x0B && cp <= 0x0C || cp >= 0x0E && cp <= 0x1F || cp >= 0x80 && cp <= 0x9F) {
      controls += 1;
    }
    else if (cp >= 0xE000 && cp <= 0xF8FF || cp >= 0xF0000 && cp <= 0xFFFFD || cp >= 0x100000 && cp <= 0x10FFFD) {
      unexpected += 1;
    }
    else {
      // 简化的可读字符判断：大部分Unicode字符都是可读的
      readable += 1;
    }
  }

  const mojibake = countMojibakeDigraphs(value.slice(0, maxScan));
  const scale = n / scanned;

  return (readable * scale / n)
    - ((replacement * scale / n) * 0.9)
    - ((controls * scale / n) * 1.5)
    - ((mojibake / n) * 0.6)
    - ((unexpected * scale / n) * 0.8);
}

// v2.9.1: 补充韩/俄/阿/泰/印地语识别——sourceLanguage 会作为语言提示影响
//   AI 总结/原子化措辞，旧版对非中日英一律返回 'unknown'。
function detectDominantLanguage(text) {
  const value = String(text || '');
  const scriptCount = (pattern) => (value.match(pattern) || []).length;
  const kana = scriptCount(/[\p{Script=Hiragana}\p{Script=Katakana}]/gu);
  const hangul = scriptCount(/\p{Script=Hangul}/gu);
  const han = scriptCount(/\p{Script=Han}/gu);
  const cyrillic = scriptCount(/\p{Script=Cyrillic}/gu);
  const arabic = scriptCount(/\p{Script=Arabic}/gu);
  const thai = scriptCount(/\p{Script=Thai}/gu);
  const devanagari = scriptCount(/\p{Script=Devanagari}/gu);
  const latin = (value.match(/[A-Za-z]/g) || []).length;
  if (hangul > 0) return 'ko';
  if (kana > 0) return 'ja';
  const others = Math.max(cyrillic, arabic, thai, devanagari);
  if (han > latin && han >= others) return 'zh';
  if (cyrillic > latin && cyrillic >= others) return 'ru';
  if (arabic > latin && arabic >= others) return 'ar';
  if (thai > latin && thai >= devanagari) return 'th';
  if (devanagari > latin) return 'hi';
  if (latin > 0) return 'en';
  return 'unknown';
}

function swapUtf16Bytes(buffer) {
  const out = Buffer.from(buffer);
  for (let i = 0; i + 1 < out.length; i += 2) {
    const first = out[i];
    out[i] = out[i + 1];
    out[i + 1] = first;
  }
  return out;
}

function parseEmail(raw) {
  const normalizedRaw = String(raw || '').replace(/\\r\\n/g, '\n').replace(/\\n/g, '\n');
  const [headerPart, ...bodyParts] = normalizedRaw.split(/\r?\n\r?\n/);
  const headers = {};
  for (const line of headerPart.split(/\r?\n/)) {
    const match = line.match(/^([^:]+):\s*(.*)$/);
    if (match) headers[match[1].toLowerCase()] = match[2].trim();
  }
  const body = bodyParts.join('\n\n');
  return {
    subject: headers.subject || '',
    from: headers.from || '',
    to: headers.to || '',
    date: headers.date || '',
    text: stripHtml(body).trim()
  };
}

// v2.9.1: HTML 实体完整解码——旧版只解 4 个命名实体，邮件 HTML 正文里的
//   &#20013; / &#x4E2D; / &eacute; / &copy; 等会原样漏进知识卡片（内容级乱码）。
//   数字实体用 String.fromCodePoint 按码点还原（增补平面字符生成合法代理对）；
//   代理区码点（0xD800-0xDFFF）会抛 RangeError，捕获后保留原文，杜绝孤立代理。
const HTML_NAMED_ENTITIES = {
  nbsp: ' ', amp: '&', lt: '<', gt: '>', quot: '"', apos: "'",
  copy: '©', reg: '®', trade: '™', deg: '°', plusmn: '±', micro: 'µ',
  mdash: '—', ndash: '–', hellip: '…', bull: '•', middot: '·',
  lsquo: '‘', rsquo: '’', ldquo: '“', rdquo: '”', laquo: '«', raquo: '»',
  times: '×', divide: '÷', frac12: '½', frac14: '¼', sup2: '²', sup3: '³',
  euro: '€', yen: '¥', pound: '£', cent: '¢', sect: '§', para: '¶',
  dagger: '†', permil: '‰', larr: '←', rarr: '→', uarr: '↑', darr: '↓',
  eacute: 'é', egrave: 'è', agrave: 'à', ccedil: 'ç', ntilde: 'ñ',
  auml: 'ä', ouml: 'ö', uuml: 'ü', szlig: 'ß', iexcl: '¡', iquest: '¿'
};

function decodeHtmlEntities(text) {
  return String(text || '').replace(/&(#x[0-9a-fA-F]+|#[0-9]+|[a-zA-Z][a-zA-Z0-9]*);/g, (whole, body) => {
    if (body[0] === '#') {
      const code = body[1] === 'x' || body[1] === 'X'
        ? parseInt(body.slice(2), 16)
        : parseInt(body.slice(1), 10);
      if (!Number.isFinite(code) || code < 0 || code > 0x10ffff || (code >= 0xd800 && code <= 0xdfff)) return whole;
      try { return String.fromCodePoint(code); } catch (_) { return whole; }
    }
    return Object.prototype.hasOwnProperty.call(HTML_NAMED_ENTITIES, body) ? HTML_NAMED_ENTITIES[body] : whole;
  });
}

function stripHtml(html) {
  return decodeHtmlEntities(String(html || '')
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/p>/gi, '\n')
    .replace(/<[^>]+>/g, ''))
    .replace(/\n{3,}/g, '\n\n');
}

// ---------------------------------------------------------------------------
// v2.9.0: MIME multipart 邮件解析（含附件二进制提取）
//   设计约束：附件是二进制，必须对原始 Buffer 做字节级结构解析。
//   latin1 是 1:1 字节映射，用它定位边界/头部后，载荷用 Buffer.slice 按
//   相同索引切出，二进制字节不受损。parseEmail（纯文本版）保留兼容旧调用。
// ---------------------------------------------------------------------------

const MIME_EXTENSIONS = {
  'application/pdf': 'pdf',
  'application/zip': 'zip',
  'application/msword': 'doc',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
  'application/vnd.ms-excel': 'xls',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
  'application/vnd.ms-powerpoint': 'ppt',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
  'application/json': 'json',
  'application/xml': 'xml',
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/gif': 'gif',
  'image/webp': 'webp',
  'image/tiff': 'tiff',
  'text/plain': 'txt',
  'text/html': 'html',
  'text/csv': 'csv',
  'message/rfc822': 'eml'
};

function mimeExtension(subtype) {
  return MIME_EXTENSIONS[String(subtype || '').toLowerCase()] || 'bin';
}

function mimeHeader(headers, name) {
  return headers ? String(headers[String(name || '').toLowerCase()] || '') : '';
}

// 从 Content-Type / Content-Disposition 里取参数值（支持引号包裹）
function mimeParam(headerValue, name) {
  const match = String(headerValue || '').match(new RegExp(`${name}\\s*=\\s*("([^"]*)"|([^;\\s]+))`, 'i'));
  if (!match) return '';
  return match[2] !== undefined ? match[2] : (match[3] || '');
}

// 头部解析：支持 RFC 2822 折叠行续行（以空格/制表符开头的行并入上一行）
function parseMimeHeaders(headerText) {
  // headerText 来自 latin1 结构解析（1:1 字节映射）。真实邮件中未走
  // RFC 2047 编码词的 8-bit 头部几乎都是 UTF-8 字节，统一转回 UTF-8；
  // 纯 ASCII（含编码词本身）转换是恒等的，不影响后续 decodeMimeWords。
  const toUtf8 = (value) => Buffer.from(value, 'latin1').toString('utf8');
  const headers = {};
  let currentKey = null;
  for (const line of String(headerText || '').split(/\r?\n/)) {
    if (/^[ \t]/.test(line) && currentKey) {
      headers[currentKey] = `${headers[currentKey]} ${toUtf8(line.trim())}`.trim();
      continue;
    }
    const match = line.match(/^([^:]+):\s*(.*)$/);
    if (match) {
      currentKey = match[1].toLowerCase();
      headers[currentKey] = toUtf8(match[2].trim());
    }
  }
  return headers;
}

// 解析单个 MIME 实体：返回 { headers, body } 或 { headers, children }（multipart）
function parseMimeEntity(buf) {
  const input = Buffer.isBuffer(buf) ? buf : Buffer.from(buf || '');
  const text = input.toString('latin1');
  let headerEnd = text.indexOf('\r\n\r\n');
  let separatorLength = 4;
  if (headerEnd < 0) {
    headerEnd = text.indexOf('\n\n');
    separatorLength = 2;
  }
  if (headerEnd < 0) {
    headerEnd = input.length;
    separatorLength = 0;
  }
  const headers = parseMimeHeaders(text.slice(0, headerEnd));
  const bodyStart = headerEnd + separatorLength;
  const contentType = mimeHeader(headers, 'content-type') || 'text/plain';
  const boundary = mimeParam(contentType, 'boundary');
  if (/^multipart\//i.test(contentType) && boundary) {
    return { headers, children: splitMultipart(input, text, bodyStart, boundary) };
  }
  return { headers, body: input.slice(bodyStart) };
}

// 按 boundary 切分子部件；起止边界之间的前言/尾声按 MIME 规范丢弃
function splitMultipart(buf, text, bodyStart, boundary) {
  const delimiter = `--${boundary}`;
  const children = [];
  let cursor = text.indexOf(delimiter, bodyStart);
  while (cursor >= 0) {
    let after = cursor + delimiter.length;
    if (text.startsWith('--', after)) break; // 结束边界 --boundary--
    if (text.startsWith('\r\n', after)) after += 2;
    else if (text.startsWith('\n', after)) after += 1;
    const next = text.indexOf(delimiter, after);
    if (next < 0) break;
    let partEnd = next;
    if (partEnd >= 2 && text.startsWith('\r\n', partEnd - 2)) partEnd -= 2;
    else if (partEnd >= 1 && text.startsWith('\n', partEnd - 1)) partEnd -= 1;
    if (partEnd > after) children.push(parseMimeEntity(buf.slice(after, partEnd)));
    cursor = next;
  }
  return children;
}

// Content-Transfer-Encoding 解码，输出原始字节
function decodePartPayload(entity) {
  const body = entity.body || Buffer.alloc(0);
  const encoding = mimeHeader(entity.headers, 'content-transfer-encoding').toLowerCase().trim();
  if (encoding === 'base64') {
    return Buffer.from(body.toString('latin1').replace(/[^A-Za-z0-9+/=]/g, ''), 'base64');
  }
  if (encoding === 'quoted-printable') return decodeQuotedPrintable(body);
  return body;
}

// quoted-printable：=XX 十六进制字节 + 软换行（行尾 =）
function decodeQuotedPrintable(buf) {
  const text = (Buffer.isBuffer(buf) ? buf : Buffer.from(buf || '')).toString('latin1');
  const bytes = [];
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (ch === '=') {
      if (text[i + 1] === '\r' && text[i + 2] === '\n') { i += 2; continue; }
      if (text[i + 1] === '\n') { i += 1; continue; }
      const hex = text.slice(i + 1, i + 3);
      if (/^[0-9A-Fa-f]{2}$/.test(hex)) {
        bytes.push(parseInt(hex, 16));
        i += 2;
        continue;
      }
      bytes.push(0x3d);
      continue;
    }
    bytes.push(text.charCodeAt(i) & 0xff);
  }
  return Buffer.from(bytes);
}

// 按声明 charset 解码字节；声明编码出现替换字符或不受支持时回退自适应探测
function decodeBufferWithCharset(buf, charset) {
  const aliases = { 'gb2312': 'gbk', 'ascii': 'utf-8', 'us-ascii': 'utf-8', 'utf8': 'utf-8' };
  const cs = aliases[String(charset || '').trim().toLowerCase()] || String(charset || '').trim().toLowerCase();
  if (cs && typeof TextDecoder === 'function') {
    try {
      const text = new TextDecoder(cs, { fatal: false }).decode(buf);
      if (text && !text.includes('�')) return text;
    } catch { /* 未知 charset 标签 → 走自适应兜底 */ }
  }
  return decodeTextBuffer(buf).text;
}

// RFC 2047 编码词：=?UTF-8?B?…?= / =?GBK?Q?…?=（常见于中文主题与附件名）
function decodeMimeWords(value) {
  const collapsed = String(value || '').replace(/\?=\s+=\?/g, '?==?');
  return collapsed.replace(/=\?([^?]+)\?([BbQq])\?([^?]*)\?=/g, (whole, charset, kind, data) => {
    try {
      const buf = kind.toLowerCase() === 'b'
        ? Buffer.from(data, 'base64')
        : decodeQuotedPrintable(Buffer.from(data.replace(/_/g, ' '), 'latin1'));
      return decodeBufferWithCharset(buf, charset);
    } catch { return whole; }
  });
}

function sanitizeAttachmentFileName(name) {
  const cleaned = String(name || '')
    .replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_')
    .replace(/^[\s.]+|[\s.]+$/g, '')
    .slice(0, 120);
  return cleaned || 'attachment';
}

function decodeTextPart(entity) {
  const contentType = mimeHeader(entity.headers, 'content-type');
  const subtype = (contentType.split(';')[0].trim().split('/')[1] || 'plain').toLowerCase();
  const charset = mimeParam(contentType, 'charset');
  let text = decodeBufferWithCharset(decodePartPayload(entity), charset);
  if (subtype === 'html') text = stripHtml(text);
  return { subtype, text: text.replace(/\r\n/g, '\n').trim() };
}

// 叶子部件分流：文本进正文候选；带文件名 / 非文本 / 嵌套邮件 进附件
function handleMimeLeaf(entity, textParts, attachments) {
  const contentType = mimeHeader(entity.headers, 'content-type') || 'text/plain';
  const fullType = contentType.split(';')[0].trim().toLowerCase();
  const disposition = mimeHeader(entity.headers, 'content-disposition');
  const filename = decodeMimeWords(mimeParam(disposition, 'filename') || mimeParam(contentType, 'name'));

  if (fullType === 'message/rfc822') {
    // 嵌套邮件整体存为 .eml，随后作为新邮件源递归进入切片流水线
    const inner = parseMimeEntity(entity.body || Buffer.alloc(0));
    const innerSubject = decodeMimeWords(mimeHeader(inner.headers, 'subject'));
    attachments.push({
      filename: `${sanitizeAttachmentFileName(innerSubject || 'nested-message')}.eml`,
      contentType: 'message/rfc822',
      data: Buffer.from(entity.body || Buffer.alloc(0))
    });
    return;
  }

  // 无文件名的内联 CID 图片（签名/企业 logo 等装饰图）不进附件，避免垃圾任务
  const inlineDecorative = /inline/i.test(disposition) && !!mimeHeader(entity.headers, 'content-id') && !filename;
  if ((fullType.startsWith('text/') && !filename) || inlineDecorative) {
    textParts.push(decodeTextPart(entity));
    return;
  }

  const payload = decodePartPayload(entity);
  if (!payload.length) return;
  attachments.push({
    filename: sanitizeAttachmentFileName(filename || `attachment-${attachments.length + 1}.${mimeExtension(fullType)}`),
    contentType: fullType,
    data: payload
  });
}

// 递归遍历部件树；multipart/alternative 内按 text/plain 优先取一份正文
function collectMimeParts(entity, textParts, attachments) {
  if (Array.isArray(entity.children)) {
    const contentType = mimeHeader(entity.headers, 'content-type').toLowerCase();
    if (contentType.startsWith('multipart/alternative')) {
      const alternatives = [];
      for (const child of entity.children) {
        const childType = (mimeHeader(child.headers, 'content-type') || 'text/plain').toLowerCase();
        if (Array.isArray(child.children) || childType.startsWith('multipart/')) {
          collectMimeParts(child, textParts, attachments);
        } else if (childType.startsWith('text/') && !mimeParam(mimeHeader(child.headers, 'content-disposition') || mimeHeader(child.headers, 'content-type'), 'filename')) {
          alternatives.push(child);
        } else {
          handleMimeLeaf(child, textParts, attachments);
        }
      }
      const chosen = alternatives.find((child) => (mimeHeader(child.headers, 'content-type') || '').toLowerCase().startsWith('text/plain')) || alternatives[0];
      if (chosen) textParts.push(decodeTextPart(chosen));
      return;
    }
    for (const child of entity.children) collectMimeParts(child, textParts, attachments);
    return;
  }
  handleMimeLeaf(entity, textParts, attachments);
}

function pickEmailBody(textParts) {
  const plain = textParts.filter((part) => part.subtype === 'plain').map((part) => part.text).filter(Boolean).join('\n\n').trim();
  if (plain) return plain;
  return textParts.filter((part) => part.subtype !== 'plain').map((part) => part.text).filter(Boolean).join('\n\n').trim();
}

// 解析整封 .eml：头部元数据 + 正文 + 附件二进制
function parseEmailMessage(buffer) {
  const raw = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer || '');
  try {
    const root = parseMimeEntity(raw);
    const textParts = [];
    const attachments = [];
    collectMimeParts(root, textParts, attachments);
    return {
      subject: decodeMimeWords(mimeHeader(root.headers, 'subject')),
      from: decodeMimeWords(mimeHeader(root.headers, 'from')),
      to: decodeMimeWords(mimeHeader(root.headers, 'to')),
      cc: decodeMimeWords(mimeHeader(root.headers, 'cc')),
      date: mimeHeader(root.headers, 'date'),
      messageId: mimeHeader(root.headers, 'message-id'),
      text: pickEmailBody(textParts),
      attachments
    };
  } catch (error) {
    // 畸形邮件兜底：退回纯文本旧路径，行为不差于 v2.8
    const decoded = decodeTextBuffer(raw);
    const simple = parseEmail(decoded.text);
    return Object.assign({}, simple, { cc: '', messageId: '', attachments: [] });
  }
}

// v2.9.1: 乱码判定重构（配合 readabilityScore / isExpectedReadableChar 改造）：
//   旧版把拉丁扩展（U+00C0-U+00FF）占比当乱码信号，合法法语/越南语文档被误杀；
//   且「符号占比 > 0.22」一条就判死韩文/俄文/阿拉伯文等非白名单文字。
//   新版只认真正的乱码信号：替换字符 U+FFFD、控制字符（含 C1 区 U+0080-U+009F，
//   即 UTF-8 续字节被误按 latin1 单字节解码的产物）、乱码二联体、私用区字符。
//   定位：解码阶段已尽量产出正确文本，本函数只是最后一道防线。
function looksLikeGibberish(text) {
  const value = String(text || '');
  if (!value) return false;
  if (/\\u[0-9a-f]{4}/i.test(value)) return true;
  const chars = [...value];
  const n = chars.length;
  const replacement = chars.filter((ch) => ch === '\uFFFD').length;
  const controls = chars.filter((ch) => /[\x00-\x08\x0B\x0C\x0E-\x1F\u0080-\u009F]/.test(ch)).length;
  const mojibake = countMojibakeDigraphs(value);
  const unexpected = chars.filter(isUnexpectedScriptOrPrivate).length;
  const readable = chars.filter(isExpectedReadableChar).length;
  // v2.9.2: 放宽短文本阈值，替换字符密集（>10%）直接判为乱码
  if (replacement > 0 && replacement / n > 0.1) return true;
  if (n < 80 && controls === 0 && replacement === 0 && unexpected === 0 && readable / n > 0.75) return false;
  return n > 30 && (
    replacement / n > 0.02
    || controls / n > 0.03
    || mojibake / n > 0.05
    || unexpected / n > 0.05
    || readable / n < 0.62
  );
}

// v2.9.1: 「可读字符」不再用 CJK+ASCII 白名单——那会把法/越/韩/俄/阿/泰等一切
//   非白名单文字当符号，合法文档被误判乱码。改用 Unicode 属性：任何人类语言文字
//   （字母/标记/数字）、任何标点、任何符号、空白都算可读；真正的异常字符
//   （控制符 / 替换符 / 私用区）由 readabilityScore 与 isUnexpectedScriptOrPrivate 负责。
function isExpectedReadableChar(ch) {
  return /[\p{L}\p{M}\p{N}\p{P}\p{S}\p{Z}\s]/u.test(ch);
}

// v1.5 (m-05): \u4E4B\u524D\u628A\u97E9/\u963F/\u6CF0/\u5370\u5730\u7B49\u5408\u6CD5\u811A\u672C\u5F53 unexpected_script\uFF0C
//              \u5BFC\u81F4\u97E9\u6587 / \u963F\u62C9\u4F2F\u6587\u6587\u6863\u88AB\u8BEF\u5224\u4E3A\u4E71\u8BED\u76F4\u63A5\u8D70 failed\u3002
//              \u6539\u4E3A\u53EA\u628A"\u79C1\u6709\u533A + \u66FF\u6362\u5B57\u7B26 + \u4EE3\u7406\u5BF9"\u8FD9\u4E9B\u771F\u6B63\u53EF\u7591\u7684\u5224\u4E3A unexpected\u3002
// v2.9.1 \u4FEE\u590D\uFF1A\u65E7\u7248\u6B63\u5219\u6F0F\u5199 /u \u6807\u5FD7\u2014\u2014\u65E0 u \u6807\u5FD7\u65F6 \uF0000 \u88AB\u89E3\u6790\u6210
//   \uF000 \u540E\u8DDF\u5B57\u9762\u5B57\u7B26 0\uFF0C0-\uFFFF \u9000\u5316\u6210\u300C0x30-0xFFFF \u5168\u5B57\u7B26\u8303\u56F4\u300D\uFF0C
//   \u4EFB\u4F55\u5B57\u6BCD/\u6570\u5B57/CJK/\u97E9\u6587\u90FD\u88AB\u8BA1\u4E3A unexpected\uFF0C\u6240\u6709\u6587\u6863\u53EF\u8BFB\u6027\u8BC4\u5206\u88AB
//   \u538B\u5230 0.2-0.4\uFF08\u6B63\u5E38\u5E94\u63A5\u8FD1 1.0\uFF09\u3002\u8865 u \u6807\u5FD7\u5E76\u6539\u7528 \u{...} \u62EC\u53F7\u5199\u6CD5\u3002
function isUnexpectedScriptOrPrivate(ch) {
  return /[\uE000-\uF8FF\u{F0000}-\u{FFFFD}\u{100000}-\u{10FFFD}\uFFFD]/u.test(ch);
}

module.exports = {
  countMojibakeDigraphs,
  decodeHtmlEntities,
  decodeMimeWords,
  decodeQuotedPrintable,
  decodeTextBuffer,
  detectDominantLanguage,
  extractTextFromBuffer,
  looksLikeGibberish,
  parseEmail,
  parseEmailMessage,
  readabilityScore,
  sanitizeAttachmentFileName,
  stripHtml
};

},
/**
 * @module src/core/moc
 * 工程资料文件夹的 Map-of-Content（索引）Markdown 生成
 * @exports createFolderIndexMarkdown
 * @exports folderIndexPath
 */
"src/core/moc.js": function(require, module, exports) {
function folderIndexPath(route) {
  return `${String(route.output_folder || '').replace(/\/$/, '')}/_索引.md`;
}

function createFolderIndexMarkdown(route) {
  const title = `${route.folder_type} 索引`;
  return `---\ntitle: ${JSON.stringify(title)}\nlibrary: ${JSON.stringify(route.library)}\nfolder_type: ${JSON.stringify(route.folder_type)}\nindex_type: fixed-folder\n---\n\n# ${title}\n\n## 知识卡片\n\n\`\`\`dataview\nTABLE card_kind AS 类型, Category, TagL1, TagL2, confidence AS 可信度, source_file AS 来源\nFROM ${JSON.stringify(route.output_folder)}\nWHERE library = ${JSON.stringify(route.library)}\n  AND folder_type = ${JSON.stringify(route.folder_type)}\n  AND file.name != "_索引"\nSORT updated DESC\n\`\`\`\n\n## 标签三元组索引\n\nCategory / TagL1 / TagL2 仅用于 MOC 查询与筛选，文件目录由 folder-map.json 固定映射。\n`;
}

module.exports = { createFolderIndexMarkdown, folderIndexPath };


},
/**
 * @module src/core/ecosystem
 * 检测 vault 中已安装的 Obsidian 生态插件（dataview / templater / quickadd 等）
 * 用于自适应地插入 MOC / frontmatter 链接
 * @exports detectEcosystemPlugins
 */
"src/core/ecosystem.js": function(require, module, exports) {
const OPTIONAL_PLUGINS = [
  { id: 'dataview', name: 'Dataview', role: 'MOC 表格和动态查询' },
  { id: 'tag-wrangler', name: 'Tag Wrangler', role: '标签重命名、合并与治理' },
  { id: 'quickadd', name: 'QuickAdd', role: '快捷捕获命令和手动建卡' },
  { id: 'obsidian-tasks-plugin', name: 'Tasks', role: '待办查询和任务视图' },
  { id: 'obsidian-kanban', name: 'Kanban', role: '可选审核看板' },
  { id: 'metadata-menu', name: 'Metadata Menu', role: 'Frontmatter 字段编辑辅助' },
  { id: 'obsidian-linter', name: 'Linter', role: 'Markdown 和 frontmatter 格式整理' },
  { id: 'templater-obsidian', name: 'Templater', role: '模板渲染兼容' },
  { id: 'templates', name: 'Templates', role: '核心模板兼容' }
];

function detectEcosystemPlugins(app) {
  const installed = (app && app.plugins && app.plugins.plugins) || {};
  const enabled = (app && app.plugins && app.plugins.enabledPlugins) || new Set();
  return OPTIONAL_PLUGINS.map((plugin) => ({
    id: plugin.id,
    name: plugin.name,
    installed: Boolean(installed[plugin.id]),
    enabled: typeof enabled.has === 'function' ? enabled.has(plugin.id) : Boolean(enabled[plugin.id]),
    role: plugin.role
  }));
}

module.exports = {
  OPTIONAL_PLUGINS,
  detectEcosystemPlugins
};

},
/**
 * @module src/core/routing
 * 卡片输出路径解析：folder_type → 实际 vault 路径
 * 处理 EPC / 安全 / 质量 等不同 folder_type 的固定路由
 * @exports cardOutputPath
 * @exports resolveFixedRoute
 */
"src/core/routing.js": function(require, module, exports) {
// v1.8 (M-09): 解析固定目录映射。优先精确匹配；找不到时退化到前缀匹配（处理 EPC 工程类合并条目）。
//       例如 AI 输出 "04-设计优化方案(EPC工程)" 但 folder-map 只有 "04-设计优化方案及设计方案(EPC工程)"，
//       走前缀匹配把两者归到同一个目录。
function resolveFixedRoute(folderMap, value) {
  const routes = (folderMap && folderMap.routes || []);
  const exact = routes.find((item) => (
    item.library === value.library && item.folder_type === value.folder_type
  ));
  if (exact) return exact;
  // 前缀 fallback：同 library 下找 folder_type 包含 value 的
  if (value.folder_type) {
    const prefix = routes.find((item) => (
      item.library === value.library && item.folder_type.includes(value.folder_type)
    ));
    if (prefix) return prefix;
    // 反向：value 包含某个 route
    const contain = routes.find((item) => (
      item.library === value.library && value.folder_type.includes(item.folder_type)
    ));
    if (contain) return contain;
  }
  // 公共前缀（N- 段）：截断到第一个 "（" 或 "(" 之前再试一次
  if (value.folder_type) {
    const baseType = value.folder_type.split(/[（(]/)[0].trim();
    if (baseType && baseType !== value.folder_type) {
      const baseRoute = routes.find((item) => (
        item.library === value.library && item.folder_type === baseType
      ));
      if (baseRoute) return baseRoute;
    }
  }
  throw new Error(`固定目录映射中不存在：${value.library || 'unknown'} / ${value.folder_type || 'unknown'}`);
}

// v1.5 (M-02 + m-03): cardOutputFolder 折入 cardOutputPath 内部，避免外部多跳一层。
//                     sanitizeFileName 同步处理 '..' 路径穿越（m-03）。
function cardOutputPath(folderMap, card, fileName) {
  const outputFolder = resolveFixedRoute(folderMap, card).output_folder.replace(/\/$/, '');
  return `${outputFolder}/${sanitizeFileName(fileName)}`;
}

function sanitizeFileName(value) {
  let fileName = String(value || 'card.md').replace(/[\\/:*?"<>|#\[\]]+/g, '-').replace(/-+/g, '-');
  // v1.5 (m-03): 防 '..' 路径穿越（用户可能把 title 写为 ".."）
  fileName = fileName.replace(/\.\.+/g, '-').replace(/^\.+/, '');
  return fileName.toLowerCase().endsWith('.md') ? fileName : `${fileName}.md`;
}

module.exports = { cardOutputPath, resolveFixedRoute, sanitizeFileName };


},
/**
 * @module src/core/external-pdf
 * 外部 OCR/PDF API 调度：MinerU 与 PaddleOCR，按文件类型 / 配置路由
 * @exports extractDocumentWithApis
 */
"src/core/external-pdf.js": function(require, module, exports) {
const { runMineruApi } = require("src/core/mineru-api.js");
const { runPaddleOcrApi } = require("src/core/paddleocr-api.js");

const DEFAULT_ORDER = ['mineru-api', 'paddleocr-api'];
const MAX_MINERU_FILE_BYTES = 200 * 1024 * 1024;

async function extractDocumentWithApis(buffer, config = {}) {
  if (Number(buffer?.length || 0) > MAX_MINERU_FILE_BYTES) {
    return {
      status: 'failed',
      engine: 'document-api',
      text: '',
      message: '源文件超过 MinerU 精准解析 API 的 200 MB 上限，请拆分后重试。'
    };
  }
  if (Number(config.pageCount || 0) > 200) {
    return {
      status: 'failed',
      engine: 'document-api',
      text: '',
      message: '文档超过 MinerU 精准解析 API 的 200 页上限，请拆分后重试。'
    };
  }

  // v1.3: 上传源文件到外部解析器前的二次确认。
  //       通过 globalThis.__eksUploadConfirm 弹窗；用户取消时直接返回 cancelled。
  if (config.confirmUploads !== false && typeof globalThis.__eksUploadConfirm === 'function') {
    const engines = parseOrder(config.order || config.pdfExtractionOrder);
    const primaryEngine = engines[0] || 'mineru-api';
    const confirmed = await globalThis.__eksUploadConfirm({
      fileName: config.fileName || '',
      sizeBytes: Number(buffer?.length || 0),
      engine: engineLabel(primaryEngine)
    });
    if (!confirmed) {
      return {
        status: 'cancelled',
        engine: 'document-api',
        text: '',
        message: '用户取消上传源文件到外部解析器。'
      };
    }
    // v2.9.2: 弹窗确认 = 用户对本次上传的明确授权。必须把它写回 config.allowExternalUpload，
    //   因为该字段在 getPdfExtractorConfig 创建配置时就已经快照（彼时本会话尚未授权，值为 false），
    //   而 runEngine 只读这个快照。不回写会导致"用户点确认后仍被『未确认允许上传』拒绝"，
    //   每次重启后第一个文件都得确认两次才成功（见 2026-07-20/23/24 诊断日志）。
    config.allowExternalUpload = true;
  }

  if (typeof config.run === 'function') {
    const injected = await config.run(buffer, config);
    return normalizeResult(injected, 'document-api');
  }

  const errors = [];
  for (const engine of parseOrder(config.order || config.pdfExtractionOrder)) {
    await emitProgress(config, {
      stage: 'document-engine',
      engine,
      message: `正在尝试云端文档解析器：${engineLabel(engine)}`
    });
    const result = await runEngine(engine, buffer, config);
    if (result && result.status === 'ok' && isUsableMarkdown(result.text)) return result;
    if (result && result.status === 'ok') errors.push(`${engine}: 解析结果未通过可读性检查`);
    if (result && result.message) errors.push(`${engine}: ${result.message}`);
  }

  return {
    status: 'failed',
    engine: 'document-api',
    text: '',
    message: errors.length ? errors.join(' | ') : '云端文档解析未返回可读 Markdown。'
  };
}

async function extractPdfWithExternal(buffer, config = {}) {
  return extractDocumentWithApis(buffer, config);
}

function parseOrder(value) {
  const requested = String(value || '')
    .split(',')
    .map((item) => item.trim().toLowerCase())
    .filter((item) => DEFAULT_ORDER.includes(item));
  return requested.length ? [...new Set(requested)] : [...DEFAULT_ORDER];
}

async function runEngine(engine, buffer, config) {
  if (config.engineRunners && typeof config.engineRunners[engine] === 'function') {
    return config.engineRunners[engine]({ buffer, config });
  }
  if (!config.allowExternalUpload) return { status: 'unavailable', message: '未确认允许上传源文件到外部解析 API。' };
  if (engine === 'mineru-api') {
    return runMineruApi(buffer, {
      apiKey: config.mineruApiKey,
      endpoint: config.mineruApiEndpoint,
      model: config.mineruApiModel,
      language: config.mineruApiLanguage,
      fileName: config.fileName,
      timeoutMs: config.timeoutMs,
      pollIntervalMs: config.pollIntervalMs,
      requestImpl: config.requestImpl,
      fetchImpl: config.fetchImpl,
      sleep: config.sleep,
      onProgress: config.onProgress
    });
  }
  if (engine === 'paddleocr-api') {
    return runPaddleOcrApi(buffer, {
      apiKey: config.paddleOcrApiKey,
      endpoint: config.paddleOcrApiEndpoint,
      model: config.paddleOcrApiModel,
      fileName: config.fileName,
      timeoutMs: config.timeoutMs,
      pollIntervalMs: config.pollIntervalMs,
      requestImpl: config.requestImpl,
      fetchImpl: config.fetchImpl,
      sleep: config.sleep,
      onProgress: config.onProgress
    });
  }
  return { status: 'unavailable', message: `不支持的云端解析器：${engine}` };
}

function normalizeResult(result, fallbackEngine) {
  if (!result || result.status !== 'ok') {
    return {
      status: result?.status || 'failed',
      engine: result?.engine || fallbackEngine,
      text: '',
      message: result?.message || '云端文档解析失败。'
    };
  }
  if (!isUsableMarkdown(result.text)) {
    return {
      status: 'failed',
      engine: result.engine || fallbackEngine,
      text: '',
      message: result.message || '云端解析结果未通过可读性检查。'
    };
  }
  return result;
}

function isUsableMarkdown(text) {
  const value = String(text || '').trim();
  if (value.length < 20 || /\\u[0-9a-f]{4}/i.test(value)) return false;
  const chars = [...value];
  const corrupt = chars.filter((char) => char === '\uFFFD' || /[\x00-\x08\x0B\x0C\x0E-\x1F\uD800-\uDFFF]/.test(char)).length;
  const readable = chars.filter((char) => /[\p{L}\p{N}\s，。、“”‘’：；！？（）【】《》,.()[\]{}:;!?/+=_%#&'"|@<>·…—-]/u.test(char)).length;
  return corrupt / chars.length <= 0.02 && readable / chars.length >= 0.72;
}

function engineLabel(engine) {
  return engine === 'mineru-api' ? 'MinerU API' : 'PaddleOCR API';
}

async function emitProgress(config, payload) {
  if (typeof config.onProgress === 'function') await config.onProgress(payload);
}

module.exports = {
  DEFAULT_ORDER,
  MAX_MINERU_FILE_BYTES,
  extractDocumentWithApis,
  extractPdfWithExternal,
  isUsableMarkdown,
  parseOrder
};

},
/**
 * @module src/core/mineru-api
 * MinerU 云端 OCR API 调用层：上传 + 轮询 + 下载 zip
 * @exports runMineruApi
 */
"src/core/mineru-api.js": function(require, module, exports) {
const { extractZipEntryEndingWith } = require("src/core/zip.js");

async function runMineruApi(buffer, options = {}) {
  if (!options.apiKey) return unavailable('未配置 MinerU API Token。');
  if (typeof (options.requestImpl || options.fetchImpl || globalThis.fetch) !== 'function') return unavailable('当前环境不支持网络请求。');

  const fetcher = options.requestImpl || options.fetchImpl || globalThis.fetch;
  const endpoint = String(options.endpoint || 'https://mineru.net/api/v4').replace(/\/$/, '');
  const headers = {
    Authorization: `Bearer ${options.apiKey}`,
    'Content-Type': 'application/json'
  };
  const fileName = safeFileName(options.fileName || 'source.pdf');
  const pollIntervalMs = Math.max(500, Number(options.pollIntervalMs) || 5000);
  const maxPolls = Math.max(1, Math.ceil((Number(options.timeoutMs) || 300000) / pollIntervalMs));
  const sleep = options.sleep || ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));

  try {
    await emit(options, { stage: 'mineru-api-request', message: 'MinerU：正在申请上传地址' });
    const createResponse = await fetcher(`${endpoint}/file-urls/batch`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        files: [{ name: fileName, is_ocr: true }],
        model_version: options.model || 'vlm',
        language: options.language || 'ch_server',
        enable_table: options.enableTable !== false,
        enable_formula: options.enableFormula !== false
      })
    });
    const createPayload = await readJson(createResponse, 'MinerU 申请上传地址');
    const batchId = createPayload?.data?.batch_id;
    const uploadUrl = createPayload?.data?.file_urls?.[0];
    if (!batchId || !uploadUrl) throw new Error(createPayload?.msg || 'MinerU 未返回上传地址或批次 ID。');

    await emit(options, { stage: 'mineru-api-upload', message: 'MinerU：正在上传源文件' });
    const uploadResponse = await fetcher(uploadUrl, { method: 'PUT', body: Buffer.from(buffer || []) });
    if (!uploadResponse.ok) throw new Error(`MinerU 文件上传失败（HTTP ${uploadResponse.status}）。`);

    for (let attempt = 0; attempt < maxPolls; attempt += 1) {
      if (attempt > 0) await sleep(pollIntervalMs);
      const resultResponse = await fetcher(`${endpoint}/extract-results/batch/${encodeURIComponent(batchId)}`, {
        method: 'GET',
        headers: { Authorization: headers.Authorization }
      });
      const resultPayload = await readJson(resultResponse, 'MinerU 查询任务');
      const result = resultPayload?.data?.extract_result?.[0];
      if (!result) throw new Error(resultPayload?.msg || 'MinerU 未返回任务状态。');
      const progress = result.extract_progress || {};
      await emit(options, {
        stage: 'mineru-api-poll',
        message: progress.total_pages
          ? `MinerU：已解析 ${progress.extracted_pages || 0}/${progress.total_pages} 页`
          : `MinerU：${stateLabel(result.state)}`,
        extractedPages: progress.extracted_pages || 0,
        totalPages: progress.total_pages || 0,
        remoteState: result.state
      });
      if (result.state === 'failed') throw new Error(result.err_msg || 'MinerU 解析失败。');
      if (result.state !== 'done') continue;
      if (!result.full_zip_url) throw new Error('MinerU 完成任务未返回结果下载地址。');

      await emit(options, { stage: 'mineru-api-download', message: 'MinerU：正在下载 Markdown 结果' });
      const zipResponse = await fetcher(result.full_zip_url, { method: 'GET' });
      if (!zipResponse.ok) throw new Error(`MinerU 结果下载失败（HTTP ${zipResponse.status}）。`);
      const zipBuffer = Buffer.from(await zipResponse.arrayBuffer());
      const markdown = extractZipEntryEndingWith(zipBuffer, 'full.md').trim();
      if (!markdown) throw new Error('MinerU 结果 ZIP 中未找到 full.md。');
      return { status: 'ok', engine: 'mineru-api-markdown', text: markdown, message: '' };
    }
    throw new Error(`MinerU 解析超时（${Math.round(maxPolls * pollIntervalMs / 1000)} 秒）。`);
  } catch (error) {
    return { status: 'failed', engine: 'mineru-api', text: '', message: safeError(error) };
  }
}

async function readJson(response, operation) {
  if (!response || !response.ok) throw new Error(`${operation}失败（HTTP ${response?.status || 0}）。`);
  const payload = await response.json();
  if (payload?.code !== undefined && payload.code !== 0) throw new Error(`${operation}失败：${payload.msg || payload.code}`);
  return payload;
}

function stateLabel(state) {
  return ({ 'waiting-file': '等待文件上传', pending: '排队中', running: '正在解析', converting: '正在转换格式' })[state] || String(state || '处理中');
}

function safeFileName(value) {
  return String(value || 'source.pdf').split(/[\\/]/).pop().replace(/[^\p{L}\p{N}._()（）\- ]/gu, '_') || 'source.pdf';
}

function safeError(error) {
  return String(error?.message || error || '未知错误').replace(/Bearer\s+\S+/gi, 'Bearer ***');
}

function unavailable(message) {
  return Promise.resolve({ status: 'unavailable', engine: 'mineru-api', text: '', message });
}

async function emit(options, payload) {
  if (typeof options.onProgress === 'function') await options.onProgress(payload);
}

module.exports = { runMineruApi };

},
/**
 * @module src/core/paddleocr-api
 * 飞桨 PaddleOCR API 调用层：单页/多页图像 OCR
 * @exports runPaddleOcrApi
 */
"src/core/paddleocr-api.js": function(require, module, exports) {
async function runPaddleOcrApi(buffer, options = {}) {
  if (!options.apiKey) return unavailable('未配置 PaddleOCR API Token。');
  const fetcher = options.requestImpl || options.fetchImpl || globalThis.fetch;
  const FormDataCtor = options.FormDataCtor || globalThis.FormData;
  const BlobCtor = options.BlobCtor || globalThis.Blob;
  if (typeof fetcher !== 'function' || (!options.requestImpl && (typeof FormDataCtor !== 'function' || typeof BlobCtor !== 'function'))) {
    return unavailable('当前环境不支持 PaddleOCR 文件上传。');
  }

  const endpoint = String(options.endpoint || 'https://paddleocr.aistudio-app.com/api/v2/ocr/jobs').replace(/\/$/, '');
  const headers = { Authorization: `bearer ${options.apiKey}` };
  const pollIntervalMs = Math.max(500, Number(options.pollIntervalMs) || 5000);
  const maxPolls = Math.max(1, Math.ceil((Number(options.timeoutMs) || 300000) / pollIntervalMs));
  const sleep = options.sleep || ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));

  try {
    const optionalPayload = JSON.stringify({
      useDocOrientationClassify: options.useDocOrientationClassify === true,
      useDocUnwarping: options.useDocUnwarping === true,
      useChartRecognition: options.useChartRecognition === true
    });
    const upload = options.requestImpl
      ? multipartUpload(buffer, options, optionalPayload)
      : browserFormUpload(buffer, options, optionalPayload, FormDataCtor, BlobCtor);

    await emit(options, { stage: 'paddleocr-api-submit', message: 'PaddleOCR：正在提交解析任务' });
    const createResponse = await fetcher(endpoint, {
      method: 'POST',
      headers: Object.assign({}, headers, upload.headers),
      body: upload.body
    });
    const createPayload = await readJson(createResponse, 'PaddleOCR 提交任务');
    const jobId = createPayload?.data?.jobId;
    if (!jobId) throw new Error('PaddleOCR 未返回任务 ID。');

    for (let attempt = 0; attempt < maxPolls; attempt += 1) {
      if (attempt > 0) await sleep(pollIntervalMs);
      const jobResponse = await fetcher(`${endpoint}/${encodeURIComponent(jobId)}`, { method: 'GET', headers });
      const jobPayload = await readJson(jobResponse, 'PaddleOCR 查询任务');
      const data = jobPayload?.data || {};
      const progress = data.extractProgress || {};
      await emit(options, {
        stage: 'paddleocr-api-poll',
        message: progress.totalPages
          ? `PaddleOCR：已解析 ${progress.extractedPages || 0}/${progress.totalPages} 页`
          : `PaddleOCR：${stateLabel(data.state)}`,
        extractedPages: progress.extractedPages || 0,
        totalPages: progress.totalPages || 0,
        remoteState: data.state
      });
      if (data.state === 'failed') throw new Error(data.errorMsg || 'PaddleOCR 解析失败。');
      if (data.state !== 'done') continue;
      const jsonUrl = data.resultUrl?.jsonUrl;
      if (!jsonUrl) throw new Error('PaddleOCR 完成任务未返回 JSONL 下载地址。');

      await emit(options, { stage: 'paddleocr-api-download', message: 'PaddleOCR：正在下载 Markdown 结果' });
      const resultResponse = await fetcher(jsonUrl, { method: 'GET' });
      if (!resultResponse.ok) throw new Error(`PaddleOCR 结果下载失败（HTTP ${resultResponse.status}）。`);
      const text = await resultResponse.text();
      const markdown = parsePaddleJsonl(text);
      if (!markdown) throw new Error('PaddleOCR 结果中没有可用的 Markdown。');
      return { status: 'ok', engine: 'paddleocr-api-markdown', text: markdown, message: '' };
    }
    throw new Error(`PaddleOCR 解析超时（${Math.round(maxPolls * pollIntervalMs / 1000)} 秒）。`);
  } catch (error) {
    return { status: 'failed', engine: 'paddleocr-api', text: '', message: safeError(error) };
  }
}

function browserFormUpload(buffer, options, optionalPayload, FormDataCtor, BlobCtor) {
  const form = new FormDataCtor();
  form.append('model', options.model || 'PaddleOCR-VL-1.6');
  form.append('optionalPayload', optionalPayload);
  form.append(
    'file',
    new BlobCtor([Buffer.from(buffer || [])], { type: 'application/pdf' }),
    safeFileName(options.fileName || 'source.pdf')
  );
  return { headers: {}, body: form };
}

function multipartUpload(buffer, options, optionalPayload) {
  const boundary = `----eks-${Date.now().toString(16)}-${Math.random().toString(16).slice(2)}`;
  const fileName = safeFileName(options.fileName || 'source.pdf').replace(/"/g, '_');
  const chunks = [];
  const field = (name, value) => {
    chunks.push(Buffer.from(
      `--${boundary}\r\nContent-Disposition: form-data; name="${name}"\r\n\r\n${value}\r\n`,
      'utf8'
    ));
  };
  field('model', options.model || 'PaddleOCR-VL-1.6');
  field('optionalPayload', optionalPayload);
  chunks.push(Buffer.from(
    `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${fileName}"\r\nContent-Type: application/pdf\r\n\r\n`,
    'utf8'
  ));
  chunks.push(Buffer.from(buffer || []));
  chunks.push(Buffer.from(`\r\n--${boundary}--\r\n`, 'utf8'));
  return {
    headers: { 'Content-Type': `multipart/form-data; boundary=${boundary}` },
    body: Buffer.concat(chunks)
  };
}

function parsePaddleJsonl(value) {
  const pages = [];
  for (const line of String(value || '').split(/\r?\n/)) {
    if (!line.trim()) continue;
    const parsed = JSON.parse(line);
    for (const result of parsed?.result?.layoutParsingResults || []) {
      const markdown = String(result?.markdown?.text || '').trim();
      if (markdown) pages.push(markdown);
    }
  }
  return pages.join('\n\n').trim();
}

async function readJson(response, operation) {
  if (!response || !response.ok) throw new Error(`${operation}失败（HTTP ${response?.status || 0}）。`);
  return response.json();
}

function stateLabel(state) {
  return ({ pending: '排队中', running: '正在解析' })[state] || String(state || '处理中');
}

function safeFileName(value) {
  return String(value || 'source.pdf').split(/[\\/]/).pop().replace(/[^\p{L}\p{N}._()（）\- ]/gu, '_') || 'source.pdf';
}

function safeError(error) {
  return String(error?.message || error || '未知错误').replace(/bearer\s+\S+/gi, 'bearer ***');
}

function unavailable(message) {
  return Promise.resolve({ status: 'unavailable', engine: 'paddleocr-api', text: '', message });
}

async function emit(options, payload) {
  if (typeof options.onProgress === 'function') await options.onProgress(payload);
}

module.exports = { parsePaddleJsonl, runPaddleOcrApi };

},
/**
 * @module src/core/zip
 * 轻量 zip 解压（仅 zip.js / fflate-free，避免大依赖）
 * @exports extractZipEntryEndingWith
 */
"src/core/zip.js": function(require, module, exports) {
const zlib = require("zlib");

function extractZipEntryEndingWith(buffer, suffix) {
  const input = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer || []);
  const endOffset = findEndOfCentralDirectory(input);
  if (endOffset < 0) return '';

  const entryCount = input.readUInt16LE(endOffset + 10);
  let cursor = input.readUInt32LE(endOffset + 16);
  for (let index = 0; index < entryCount; index += 1) {
    if (cursor + 46 > input.length || input.readUInt32LE(cursor) !== 0x02014b50) break;
    const method = input.readUInt16LE(cursor + 10);
    const compressedSize = input.readUInt32LE(cursor + 20);
    const fileNameLength = input.readUInt16LE(cursor + 28);
    const extraLength = input.readUInt16LE(cursor + 30);
    const commentLength = input.readUInt16LE(cursor + 32);
    const localHeaderOffset = input.readUInt32LE(cursor + 42);
    const name = decodeZipFileName(input, cursor).replace(/\\/g, '/');
    if (name.toLowerCase().endsWith(String(suffix || '').toLowerCase())) {
      const content = readLocalEntry(input, localHeaderOffset, compressedSize, method);
      return content.toString('utf8');
    }
    cursor += 46 + fileNameLength + extraLength + commentLength;
  }
  return '';
}

// v2.9.1: ZIP 文件名解码。旧版一律按 UTF-8 解，而 Windows 资源管理器压缩、
//   旧版 7-Zip 等会把文件名以 GBK 字节直接写入且不设 EFS 标志
//   （通用位标志 bit 11 = 0x800），中文条目名变成「娴嬭瘯.md」式乱码，
//   按后缀查找 .md 条目时匹配不到。规则：
//   EFS 置位 → UTF-8；否则字节流构成合法 UTF-8（纯 ASCII 或含非 ASCII 均算）
//   → UTF-8；含非法序列 → 试 GBK（Windows 中文环境最常见）；最终兜底 latin1。
function decodeZipFileName(input, centralDirOffset) {
  const flags = input.readUInt16LE(centralDirOffset + 8);
  const fileNameLength = input.readUInt16LE(centralDirOffset + 28);
  const raw = input.slice(centralDirOffset + 46, centralDirOffset + 46 + fileNameLength);
  if (flags & 0x800) return raw.toString('utf8');
  const utf8 = raw.toString('utf8');
  if (!utf8.includes('\uFFFD')) return utf8;
  // 含非法序列 → 不是 UTF-8，按 GBK 解码（Windows 中文压缩工具最常见）
  try {
    if (typeof TextDecoder === 'function') {
      const gbk = new TextDecoder('gbk', { fatal: false }).decode(raw);
      if (gbk && !gbk.includes('\uFFFD')) return gbk;
    }
  } catch {
    // 忽略：落到 latin1 兜底
  }
  return raw.toString('latin1');
}

function readLocalEntry(buffer, offset, compressedSize, method) {
  if (offset + 30 > buffer.length || buffer.readUInt32LE(offset) !== 0x04034b50) return Buffer.alloc(0);
  const fileNameLength = buffer.readUInt16LE(offset + 26);
  const extraLength = buffer.readUInt16LE(offset + 28);
  const start = offset + 30 + fileNameLength + extraLength;
  const compressed = buffer.slice(start, start + compressedSize);
  if (method === 0) return compressed;
  if (method === 8) return zlib.inflateRawSync(compressed);
  throw new Error(`不支持的 ZIP 压缩方式：${method}`);
}

function findEndOfCentralDirectory(buffer) {
  const minimum = Math.max(0, buffer.length - 65557);
  for (let offset = buffer.length - 22; offset >= minimum; offset -= 1) {
    if (buffer.readUInt32LE(offset) === 0x06054b50) return offset;
  }
  return -1;
}

module.exports = { extractZipEntryEndingWith };

},
/**
 * @module src/core/component-contracts
 * 跨模块共享的契约 / 类型守卫 / 卡片字段约束
 */
"src/core/component-contracts.js": function(require, module, exports) {
function parseFolderMap(text) {
  let parsed;
  try {
    parsed = JSON.parse(String(text || ''));
  } catch (error) {
    throw new Error(`folder-map.json is not valid JSON: ${error.message}`);
  }
  return parsed;
}

function validateFolderMap(folderMap, promptExists = () => true) {
  const errors = [];
  if (!folderMap || typeof folderMap !== 'object') return ['folder map must be an object'];
  if (folderMap.version !== '1.1') errors.push('folder map version must be 1.1');
  if (!Array.isArray(folderMap.routes)) return [...errors, 'folder map routes must be an array'];

  const seen = new Set();
  let bidCount = 0;
  let businessCount = 0;
  for (const [index, route] of folderMap.routes.entries()) {
    const label = `route ${index + 1}`;
    if (!route || typeof route !== 'object') {
      errors.push(`${label} must be an object`);
      continue;
    }
    if (!['bid', 'business'].includes(route.library)) errors.push(`${label} library must be bid or business`);
    if (route.library === 'bid') bidCount += 1;
    if (route.library === 'business') businessCount += 1;
    if (!String(route.folder_type || '').trim()) errors.push(`${label} folder_type is required`);

    const key = `${route.library}:${route.folder_type}`;
    if (seen.has(key)) errors.push(`duplicate route: ${key}`);
    seen.add(key);

    const root = route.library === 'bid'
      ? '06-知识库/wiki/招投标/'
      : route.library === 'business'
        ? '06-知识库/wiki/业务库/'
        : '';
    const output = String(route.output_folder || '').replace(/\\/g, '/');
    if (!root || !output.startsWith(root) || /category|tagl1|tagl2/i.test(output)) {
      errors.push(`${label} output_folder must use its fixed wiki root`);
    }
    if (!String(route.prompt || '').startsWith('提示词/')) errors.push(`${label} prompt path is invalid`);
    else if (!promptExists(route.prompt)) errors.push(`${label} prompt does not exist: ${route.prompt}`);
  }

  if (bidCount !== 19) errors.push(`expected 19 bid routes, got ${bidCount}`);
  if (businessCount !== 9) errors.push(`expected 9 business routes, got ${businessCount}`);
  return errors;
}

function validateSchemaDocument(schema) {
  const errors = [];
  if (!schema || typeof schema !== 'object' || Array.isArray(schema)) return ['schema must be an object'];
  if (schema.$schema !== 'https://json-schema.org/draft/2020-12/schema') errors.push('schema draft must be 2020-12');
  if (!String(schema.$id || '').startsWith('engineering-knowledge-slicer://schema/')) errors.push('schema $id is invalid');
  if (schema.type !== 'object') errors.push('root schema type must be object');
  if (!schema.properties || typeof schema.properties !== 'object') errors.push('schema properties are required');
  if (!Array.isArray(schema.required)) errors.push('schema required must be an array');
  if (typeof schema.additionalProperties !== 'boolean') errors.push('schema must decide additionalProperties explicitly');
  return errors;
}

module.exports = {
  parseFolderMap,
  validateFolderMap,
  validateSchemaDocument
};

},
/**
 * @module src/core/migration
 * tasks.json 老格式迁移：v1/v2 ledger → v3 标准格式
 * 含字段补全 / 状态重映射 / 备份
 * @exports migrateTaskLedgerV3
 */
"src/core/migration.js": function(require, module, exports) {
const crypto = require("crypto");

const LEGACY_ACTIVE = new Set(['extracting', 'parsing', 'classifying', 'summarizing', 'slicing', 'atomizing', 'validating', 'writing']);
const VALID_TERMINAL = new Set(['queued', 'written', 'needs_review', 'failed', 'skipped', 'cancelled', 'unsupported', 'paused']);

// v1.1.3: bundle 内每个模块都是独立作用域，main.js 顶层定义进不来。
// 这里保留一份与主定义完全一致的局部副本，专门给 migrateTaskLedgerV3 用。
function normalizeUnicodeForm(value) {
  let str = String(value || '');
  if (!str) return str;
  if (typeof str.normalize === 'function') {
    try { str = str.normalize('NFC'); } catch { /* 不可用则忽略 */ }
  }
  str = str.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]﻿/g, '');
  str = str.replace(/[  ]/g, ' ');
  return str;
}

function migrateTaskLedgerV3(tasks, versions = {}) {
  const pipelineVersion = versions.pipelineVersion || '1.1.1';
  const promptBundleVersion = versions.promptBundleVersion || '1.1';
  return (Array.isArray(tasks) ? tasks : []).map((task) => {
    const canonical = task.schema_version === '1.1' && Boolean(task.task_id) && Boolean(task.run_id);
    // v1.1.2: 旧任务 source_path 可能在 macOS 上是 NFD 编码、Windows 上是 GBK，统一规范成 NFC，
    // 避免按路径查文件时因编码不一致出现"找不到源文件"。
    const sourcePath = normalizeUnicodeForm(String(task.source_path || task.sourcePath || '').replace(/\\/g, '/'));
    const sourceHash = String(task.source_hash || task.sourceHash || '');
    const taskId = task.task_id || task.taskId || `slicer-${sourceHash.slice(0, 12)}`;
    const library = task.library || (sourcePath.includes('/业务库/') ? 'business' : 'bid');
    const wasActive = !canonical && LEGACY_ACTIVE.has(task.status);
    const status = canonical
      ? task.status
      : wasActive
      ? 'failed'
      : task.status === 'archived'
        ? 'written'
        : VALID_TERMINAL.has(task.status)
          ? task.status
          : 'failed';
    const errors = [...(Array.isArray(task.errors) ? task.errors : [])];
    if (wasActive) {
      errors.push({
        stage: 'migration',
        message: '版本升级后旧处理中任务无法安全续接，请手动重试。',
        at: new Date().toISOString()
      });
    }
    const runId = task.run_id || stableId(`${library}:${sourceHash}:${pipelineVersion}:${promptBundleVersion}`);
    return {
      task_id: taskId,
      run_id: runId,
      source_path: sourcePath,
      source_aliases: Array.isArray(task.source_aliases) ? task.source_aliases : [],
      source_hash: sourceHash,
      source_type: task.source_type || task.sourceType || 'unknown',
      library,
      pipeline_version: pipelineVersion,
      prompt_bundle_version: promptBundleVersion,
      schema_version: '1.1',
      status,
      remote_jobs: Array.isArray(task.remote_jobs) ? task.remote_jobs : [],
      retry_counts: task.retry_counts || {},
      artifacts: task.artifacts || {},
      written_card_ids: task.written_card_ids || task.writtenFiles || [],
      review_atom_ids: task.review_atom_ids || task.draftFiles || [],
      errors,
      progress: task.progress || {},
      lease: null,
      created_at: task.created_at || task.createdAt || new Date().toISOString(),
      updated_at: task.updated_at || task.updatedAt || new Date().toISOString()
    };
  });
}

function readinessIssues(settings = {}, contractResult = { valid: true, errors: [] }) {
  const issues = [];
  if (!String(settings.minimaxApiKey || '').trim()) issues.push(issue('minimax-key-missing', 'MiniMax API Key 未配置。'));
  if (!String(settings.pdfMineruApiKey || '').trim()) issues.push(issue('mineru-key-missing', 'MinerU API Token 未配置。'));
  if (settings.pdfAllowExternalUpload !== true) issues.push(issue('external-upload-not-confirmed', '尚未确认允许上传源文件到外部解析 API。'));
  if (!contractResult || contractResult.valid !== true) {
    issues.push(issue('component-contract-invalid', `组件包契约无效：${(contractResult?.errors || []).join('；')}`));
  }
  if (!String(settings.pdfPaddleOcrApiKey || '').trim()) {
    issues.push(issue('paddleocr-key-missing', 'PaddleOCR Token 未配置，PDF/图片补盲不可用。', false));
  }
  return issues;
}

function issue(code, message, blocking = true) {
  return { code, message, blocking };
}

function stableId(value) {
  return `run-${crypto.createHash('sha256').update(String(value)).digest('hex').slice(0, 16)}`;
}

module.exports = {
  migrateTaskLedgerV3,
  readinessIssues
};

},
/**
 * @module src/core/document-parser
 * 文档解析计划 / 解析包产出：根据文件类型选 OCR / 直读 / 拆分
 * @exports documentPlan
 * @exports createParsePackage
 */
"src/core/document-parser.js": function(require, module, exports) {
const crypto = require("crypto");

const MAX_MINERU_FILE_BYTES = 200 * 1024 * 1024;

function documentPlan(filePath) {
  const lower = String(filePath || '').toLowerCase();
  if (/\.md$/.test(lower)) return plan('md', 'text');
  if (/\.txt$/.test(lower)) return plan('txt', 'text');
  if (/\.eml$/.test(lower)) return plan('email', 'email');
  if (/\.pdf$/.test(lower)) return plan('pdf', 'remote', ['mineru-api', 'paddleocr-api']);
  if (/\.(png|jpe?g|webp|gif|bmp|tiff?)$/.test(lower)) return plan('image', 'remote', ['mineru-api', 'paddleocr-api']);
  if (/\.(doc|docx)$/.test(lower)) return plan('docx', 'remote', ['mineru-api']);
  if (/\.(ppt|pptx)$/.test(lower)) return plan('pptx', 'remote', ['mineru-api']);
  if (/\.(xls|xlsx)$/.test(lower)) return plan('xlsx', 'remote', ['mineru-api']);
  if (/\.(html|htm)$/.test(lower)) return Object.assign(plan('html', 'remote', ['mineru-api']), { mineruModel: 'MinerU-HTML' });
  if (/\.msg$/.test(lower)) return plan('outlook-msg', 'unsupported');
  if (/\.(mp4|mov|avi|mkv)$/.test(lower)) return plan('video', 'unsupported');
  if (/\.(mp3|wav|m4a)$/.test(lower)) return plan('audio', 'unsupported');
  return plan('unknown', 'unsupported');
}

function plan(sourceType, mode, engines = []) {
  return { sourceType, mode, engines, mineruModel: 'vlm' };
}

function createParsePackage(options) {
  const markdown = String(options.markdown || '').trim();
  const quality = markdownQuality(markdown);
  return {
    source_path: String(options.sourcePath || '').replace(/\\/g, '/'),
    source_hash: crypto.createHash('sha256').update(options.buffer || Buffer.alloc(0)).digest('hex'),
    source_type: options.sourceType || 'unknown',
    parser: normalizeParser(options.parser),
    parser_model: options.parserModel || '',
    remote_job_id: options.remoteJobId || '',
    language: options.language || 'unknown',
    markdown,
    pages: Array.isArray(options.pages) && options.pages.length
      ? options.pages
      : markdown ? [{ page: 1, text: markdown }] : [],
    images: Array.isArray(options.images) ? options.images : [],
    quality,
    // v2.9.0: 透传解析元数据（邮件主题/发件人/附件清单等），供卡片链接与总结阶段使用。
    //   只接受纯 JSON 对象（附件二进制不进这里，见 extractTextFromBuffer email 分支）。
    metadata: options.metadata && typeof options.metadata === 'object' && !Array.isArray(options.metadata) ? options.metadata : {},
    schema_version: '1.1'
  };
}

function normalizeParser(parser) {
  const value = String(parser || '');
  if (value.startsWith('mineru-api')) return 'mineru-api';
  if (value.startsWith('paddleocr-api')) return 'paddleocr-api';
  if (value === 'eml-parser') return value;
  return 'text-normalizer';
}

function markdownQuality(markdown) {
  const chars = [...String(markdown || '')];
  if (!chars.length) return { readable: false, score: 0, components: { length: 0, readable_ratio: 0, corrupt_ratio: 0, structure: 0 } };
  const corrupt = chars.filter((char) => char === '\uFFFD' || /[\x00-\x08\x0B\x0C\x0E-\x1F]/.test(char)).length;
  const readable = chars.filter((char) => /[\p{L}\p{N}\s，。、“”‘’：；！？（）【】《》,.()[\]{}:;!?/+=_%#&'"|@<>·…—-]/u.test(char)).length;
  const lengthScore = Math.min(1, chars.length / 200);
  const readableRatio = readable / chars.length;
  const corruptRatio = corrupt / chars.length;
  const structure = /(^|\n)#{1,6}\s|\|.+\||(^|\n)[-*]\s/m.test(markdown) ? 1 : 0.6;
  const score = clamp((0.25 * lengthScore) + (0.5 * readableRatio) + (0.25 * structure) - corruptRatio);
  return {
    readable: chars.length >= 20 && corruptRatio <= 0.02 && readableRatio >= 0.72,
    score: Number(score.toFixed(4)),
    components: {
      length: Number(lengthScore.toFixed(4)),
      readable_ratio: Number(readableRatio.toFixed(4)),
      corrupt_ratio: Number(corruptRatio.toFixed(4)),
      structure
    }
  };
}

function clamp(value) {
  return Math.max(0, Math.min(1, value));
}

module.exports = {
  MAX_MINERU_FILE_BYTES,
  createParsePackage,
  markdownQuality,
  documentPlan
};

},
/**
 * @module src/core/identity
 * 卡片身份指纹：源文件 hash + 内容 fingerprint → 稳定卡片 ID
 * @exports atomFingerprint
 * @exports sourceIdentity
 * @exports runIdentity
 */
"src/core/identity.js": function(require, module, exports) {
const crypto = require("crypto");

function sourceIdentity({ library, sourceHash }) {
  return `source-${hash(`${library}:${sourceHash}`).slice(0, 20)}`;
}

function runIdentity({ sourceIdentity: sourceId, pipelineVersion, promptBundleVersion, schemaVersion }) {
  return `run-${hash(`${sourceId}:${pipelineVersion}:${promptBundleVersion}:${schemaVersion}`).slice(0, 20)}`;
}

function atomFingerprint(atom) {
  const identityFields = {
    card_kind: atom?.card_kind || '',
    title: atom?.title || '',
    content: atom?.content || {},
    source_locator: atom?.source?.source_locator || ''
  };
  return hash(stableStringify(normalizeValue(identityFields)));
}

// v1.8 (M-08): cardIdentity 改用完整 sourceHash + 完整 fingerprint，
//              避免 slice(0,12) 截断导致的 48-bit 生日碰撞（~16M 文档级别）。
//              加库名前缀（bid/business）防止跨库碰撞。
function cardIdentity(library, sourceHash, fingerprint) {
  const lib = String(library || 'unknown').slice(0, 8);
  const src = String(sourceHash || '').slice(0, 16);
  const fp = String(fingerprint || '').slice(0, 16);
  return `card-${lib}-${src}-${fp}`;
}

function normalizeValue(value) {
  if (typeof value === 'string') return value.trim().replace(/\s+/g, ' ').toLowerCase();
  if (Array.isArray(value)) return value.map(normalizeValue);
  if (value && typeof value === 'object') {
    const result = {};
    for (const key of Object.keys(value).sort()) result[key] = normalizeValue(value[key]);
    return result;
  }
  return value;
}

function stableStringify(value) {
  return JSON.stringify(value);
}

function hash(value) {
  return crypto.createHash('sha256').update(String(value)).digest('hex');
}

module.exports = {
  atomFingerprint,
  cardIdentity,
  runIdentity,
  sourceIdentity
};

},
/**
 * @module src/core/pipeline
 * 单文件任务流水线的骨架：创建任务记录、驱动 AI 流水线、产出卡片
 * @exports createTaskRecord
 */
"src/core/pipeline.js": function(require, module, exports) {
const { runIdentity, sourceIdentity } = require("src/core/identity.js");

// v1.5 (M-02): 删除 TRANSITIONS / transitionTask / acquireLease / releaseLease /
//              retryFailedTask / runPipelineTask / artifact / requiredHandler /
//              copyTask 死代码；只保留 createTaskRecord（主流程还在用）。
//              这些都是 v1.1 重构期的中间产物，从来没被 main.js 外部调用。

function createTaskRecord(options) {
  const versions = options.versions || {};
  const sourceId = sourceIdentity({ library: options.library, sourceHash: options.sourceHash });
  const runId = runIdentity({
    sourceIdentity: sourceId,
    pipelineVersion: versions.pipelineVersion || '1.1.0',
    promptBundleVersion: versions.promptBundleVersion || '1.1',
    schemaVersion: versions.schemaVersion || '1.1'
  });
  const now = typeof options.now === 'string' ? options.now : (options.now || new Date()).toISOString();
  return {
    task_id: sourceId,
    run_id: runId,
    source_path: String(options.sourcePath || '').replace(/\\/g, '/'),
    source_aliases: [],
    source_hash: options.sourceHash,
    source_type: options.sourceType,
    library: options.library,
    pipeline_version: versions.pipelineVersion || '1.1.0',
    prompt_bundle_version: versions.promptBundleVersion || '1.1',
    schema_version: versions.schemaVersion || '1.1',
    status: 'queued',
    remote_jobs: [],
    retry_counts: {},
    artifacts: {},
    written_card_ids: [],
    review_atom_ids: [],
    errors: [],
    progress: {},
    lease: null,
    created_at: now,
    updated_at: now
  };
}

module.exports = {
  createTaskRecord
};

},
/**
 * @module src/core/schema-validator
 * AI 输出结构校验：classification.schema.json / card.schema.json 实例校验
 * @exports validateSchema
 */
"src/core/schema-validator.js": function(require, module, exports) {
function validateSchema(schema, value) {
  const errors = [];
  visit(schema, value, '$', errors);
  return { valid: errors.length === 0, errors };
}

function visit(schema, value, path, errors) {
  if (!schema || typeof schema !== 'object') return;

  if (Object.hasOwn(schema, 'const') && value !== schema.const) {
    errors.push(`${path} must equal ${JSON.stringify(schema.const)}`);
    return;
  }
  if (Array.isArray(schema.enum) && !schema.enum.includes(value)) {
    errors.push(`${path} must be one of ${schema.enum.map((item) => JSON.stringify(item)).join(', ')}`);
    return;
  }

  const acceptedTypes = Array.isArray(schema.type) ? schema.type : (schema.type ? [schema.type] : []);
  if (acceptedTypes.length && !acceptedTypes.some((type) => matchesType(type, value))) {
    errors.push(`${path} must be ${acceptedTypes.join(' or ')}`);
    return;
  }

  if (typeof value === 'string') {
    if (schema.minLength !== undefined && value.length < schema.minLength) errors.push(`${path} is shorter than ${schema.minLength}`);
    if (schema.maxLength !== undefined && value.length > schema.maxLength) errors.push(`${path} is longer than ${schema.maxLength}`);
    if (schema.pattern && !(new RegExp(schema.pattern).test(value))) errors.push(`${path} does not match ${schema.pattern}`);
  }

  if (typeof value === 'number' && Number.isFinite(value)) {
    if (schema.minimum !== undefined && value < schema.minimum) errors.push(`${path} is below ${schema.minimum}`);
    if (schema.maximum !== undefined && value > schema.maximum) errors.push(`${path} is above ${schema.maximum}`);
  }

  if (Array.isArray(value)) {
    if (schema.minItems !== undefined && value.length < schema.minItems) errors.push(`${path} has fewer than ${schema.minItems} items`);
    if (schema.maxItems !== undefined && value.length > schema.maxItems) errors.push(`${path} has more than ${schema.maxItems} items`);
    if (schema.uniqueItems && new Set(value.map(stableValue)).size !== value.length) errors.push(`${path} contains duplicate items`);
    if (schema.items) value.forEach((item, index) => visit(schema.items, item, `${path}[${index}]`, errors));
  }

  if (isObject(value)) {
    for (const key of schema.required || []) {
      if (!Object.hasOwn(value, key)) errors.push(`${path}.${key} is required`);
    }
    const properties = schema.properties || {};
    for (const [key, item] of Object.entries(value)) {
      if (properties[key]) visit(properties[key], item, `${path}.${key}`, errors);
      else if (schema.additionalProperties === false) errors.push(`${path}.${key} is not allowed`);
      else if (isObject(schema.additionalProperties)) visit(schema.additionalProperties, item, `${path}.${key}`, errors);
    }
  }
}

function matchesType(type, value) {
  if (type === 'null') return value === null;
  if (type === 'array') return Array.isArray(value);
  if (type === 'object') return isObject(value);
  if (type === 'integer') return Number.isInteger(value);
  if (type === 'number') return typeof value === 'number' && Number.isFinite(value);
  return typeof value === type;
}

function isObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function stableValue(value) {
  if (!isObject(value) && !Array.isArray(value)) return `${typeof value}:${String(value)}`;
  if (Array.isArray(value)) return `[${value.map(stableValue).join(',')}]`;
  return `{${Object.keys(value).sort().map((key) => `${key}:${stableValue(value[key])}`).join(',')}}`;
}

module.exports = { validateSchema };


},
/**
 * @module src/core/ai-pipeline
 * MiniMax M3 API 调用层：summarizeDocument / atomizeSummary / classifyDocument
 * 含重试 / 修复 / schema 校验 / 截断兜底
 * @exports requestMiniMaxJson
 * @exports summarizeDocument
 * @exports atomizeSummary
 * @exports classifyDocument
 */
"src/core/ai-pipeline.js": function(require, module, exports) {
const { validateSchema } = require("src/core/schema-validator.js");

// v1.1.9: ai-pipeline.js 是独立 bundle 模块闭包，main.js 里的本地 function diag 对它不可见。
// 通过 globalThis.__eksDiag 委托到唯一的诊断入口，确保 minimax.timeout/transport/http 等
// 失败打点能正常工作而不报 "diag is not defined"。若共享诊断还没初始化，则静默 no-op（不抛错）。
function diag(scope, payload) {
  try { return globalThis.__eksDiag && globalThis.__eksDiag.diag ? globalThis.__eksDiag.diag(scope, payload) : undefined; }
  catch (_) { /* 诊断日志自身不能炸 */ }
}
function keyFingerprint(value) {
  try { return globalThis.__eksDiag && globalThis.__eksDiag.keyFingerprint ? globalThis.__eksDiag.keyFingerprint(value) : 'fp:<unavailable>'; }
  catch (_) { return 'fp:<unavailable>'; }
}

function buildClassificationPrompt({ classifierPrompt, folderMap, parsePackage }) {
  const whitelist = (folderMap.routes || []).map((route) => ({
    library: route.library,
    folder_type: route.folder_type
  }));
  const fullEvidence = (parsePackage.sections || []).length
    ? parsePackage.sections.map((section) => `## ${section.heading || section.section_id}\n${section.markdown || ''}`).join('\n\n')
    : String(parsePackage.markdown || '');
  const evidence = classificationSample(fullEvidence);
  return [
    classifierPrompt,
    '以下目录是唯一合法白名单。library 与 folder_type 必须精确匹配其中一项，不得新建、翻译或改写目录名：',
    JSON.stringify(whitelist, null, 2),
    '文件元数据：',
    JSON.stringify({
      source_name: parsePackage.source_name,
      source_path: parsePackage.source_path,
      source_type: parsePackage.source_type,
      parser: parsePackage.parser,
      parse_quality: parsePackage.quality
    }, null, 2),
    '解析后的文档内容：',
    evidence,
    '只返回符合 classification.schema.json 的 JSON。'
  ].filter(Boolean).join('\n\n');
}

// v2.9.1: 代理对安全截断。JS 字符串是 UTF-16，BMP 外字符（emoji、CJK 扩展 B
//   汉字如 𠀀、部分数学符号）占两个码元，slice 正好切在高低代理之间会产出
//   孤立代理（lone surrogate）——写 frontmatter / JSON.stringify / 送 AI 时
//   变成乱码方块或损坏的 JSON。切点落在代理对中间时，把切点前移到高位代理之前。
function adjustSurrogateCut(text, index) {
  const hi = text.charCodeAt(index - 1);
  const lo = text.charCodeAt(index);
  if (hi >= 0xd800 && hi <= 0xdbff && lo >= 0xdc00 && lo <= 0xdfff) return index - 1;
  return index;
}

// v2.9.1: 定长截取统一入口——起止两端都做代理对校正。按换行符边界切的场景
//   天然安全（0x0A 不会出现在代理对中间），只有「按固定字符数截断」需要它。
function safeSlice(text, start, end) {
  const from = adjustSurrogateCut(text, start);
  const to = adjustSurrogateCut(text, end);
  return text.slice(from, to);
}

function classificationSample(markdown, maxChars = 24000) {
  const text = String(markdown || '');
  if (text.length <= maxChars) return text;
  const headingLines = safeSlice((text.match(/^#{1,6}\s+.+$/gm) || []).join('\n'), 0, 4000);
  const remaining = Math.max(6000, maxChars - headingLines.length - 120);
  const frontSize = Math.floor(remaining * 0.5);
  const middleSize = Math.floor(remaining * 0.2);
  const endSize = remaining - frontSize - middleSize;
  const middleStart = Math.max(frontSize, Math.floor(text.length / 2 - middleSize / 2));
  const lastHeading = Math.max(text.lastIndexOf('\n# '), text.lastIndexOf('\n## '), text.lastIndexOf('\n### '));
  const sectionTailSize = Math.floor(endSize * 0.6);
  const absoluteTailSize = endSize - sectionTailSize;
  // v2.9.1: 全部定长截取改走 safeSlice，避免 emoji / CJK 扩展 B 汉字被切出孤立代理
  const sectionTail = lastHeading >= 0
    ? safeSlice(text, lastHeading + 1, lastHeading + 1 + sectionTailSize)
    : safeSlice(text, Math.max(0, text.length - sectionTailSize), text.length);
  return [
    safeSlice(text, 0, frontSize),
    '\n\n[文档标题目录汇总]\n', headingLines,
    '\n\n[文档中段代表内容]\n', safeSlice(text, middleStart, middleStart + middleSize),
    '\n\n[最后章节开头]\n', sectionTail,
    '\n\n[文档实际尾部]\n', safeSlice(text, Math.max(0, text.length - absoluteTailSize), text.length)
  ].join('');
}

async function classifyDocument(options) {
  const basePrompt = buildClassificationPrompt(options);
  const result = await requestWithContract({
    prompt: basePrompt,
    stage: 'classification',
    schema: options.classificationSchema,
    requestJson: options.requestJson,
    maxRepairAttempts: options.maxRepairAttempts,
    onProgress: options.onProgress,
    extraValidation(value) {
      return findRoute(options.folderMap, value) ? [] : ['分类结果不在固定目录白名单'];
    }
  });
  return Object.assign({}, result, findRoute(options.folderMap, result));
}

function findRoute(folderMap, classification) {
  return (folderMap.routes || []).find((route) => route.library === classification.library && route.folder_type === classification.folder_type) || null;
}

// ==================== v2.7 切片引擎（借鉴 Tencent/WeKnora 的知识点切片思路） ====================
// 参考实现：
//   - docreader/splitter/splitter.py        → 受保护模式 + 重叠合并（protected_regex / chunk_overlap）
//   - internal/infrastructure/chunker/profiler.go        → 文档画像驱动策略选择（ProfileDocument / SelectStrategy）
//   - internal/infrastructure/chunker/heading_splitter.go → 标题边界切分 + 层级面包屑（ContextHeader）+ 小节合并（coalesceTinyChunks）
//   - internal/infrastructure/chunker/heuristic_splitter.go → 候选边界 + 贪心装箱（dropBoundsInsideSpans / bin-packing）
// 与 WeKnora 相同的原则：
//   1) 切块前先给文档做"画像"，按结构信号选择切分策略（heading / heuristic / legacy）
//   2) 代码块 / 表格 / LaTeX 公式等"受保护区域"永不被拦腰切断
//   3) 每个切片携带标题层级面包屑（ContextHeader），让下游 AI 拿到章节语境
//   4) 相邻、同语境、过小的切片合并（coalesce），减少 AI 调用次数
//   5) 切片之间保留可配置的重叠（overlap），避免段落语境在切点处断裂
//   6) 切分结果做顺序 / 覆盖 / 超尺寸校验（只告警不阻断）

// 受保护区域的正则：围栏代码块（含未闭合）、LaTeX 块级公式。
// 表格按行组识别（见 findProtectedSpans），不走正则。
const PROTECTED_SPAN_PATTERNS = [
  /```[^\n]*\n[\s\S]*?(?:```|$)/g,
  /\$\$[\s\S]*?\$\$/g
];

// 文档画像：一次性扫描文档，收集决定切分策略的结构信号。
// 对应 WeKnora profiler.go 的 ProfileDocument + SelectStrategy。
function profileMarkdown(text) {
  const source = String(text || '');
  const profile = {
    totalChars: source.length,
    totalLines: 0,
    avgLineLen: 0,
    headingCounts: {},
    headingTotal: 0,
    dominantHeadingLevel: 0,
    numberedSectionCount: 0,
    hasTables: false,
    hasCode: false,
    hasMath: false,
    codeChars: 0,
    codeRatio: 0,
    blankParagraphBreaks: 0,
    strategy: 'legacy'
  };
  if (!source) return profile;
  const lines = source.split('\n');
  profile.totalLines = lines.length;
  let lengthSum = 0;
  let lengthCount = 0;
  let inFence = false;
  for (const raw of lines) {
    const trimmed = raw.trim();
    if (trimmed.startsWith('```')) { inFence = !inFence; profile.hasCode = true; continue; }
    if (inFence) { profile.codeChars += raw.length; continue; }
    lengthSum += raw.length;
    lengthCount += 1;
    const heading = raw.match(/^(#{1,6})\s+\S/);
    if (heading) {
      const level = heading[1].length;
      profile.headingCounts[level] = (profile.headingCounts[level] || 0) + 1;
      profile.headingTotal += 1;
      continue;
    }
    if (/^\s*\d+(?:\.\d+)*[.、]\s*\S/.test(raw)) profile.numberedSectionCount += 1;
    if (trimmed.startsWith('|') && trimmed.endsWith('|') && trimmed.length >= 2) profile.hasTables = true;
    if (trimmed.includes('$$')) profile.hasMath = true;
  }
  if (lengthCount > 0) profile.avgLineLen = lengthSum / lengthCount;
  if (profile.totalChars > 0) profile.codeRatio = profile.codeChars / profile.totalChars;
  profile.blankParagraphBreaks = (source.match(/\n\n\n/g) || []).length;
  // 主标题层级：优先取出现 >= 3 次的最低层级（真正的文档骨架），
  // 否则取最深出现层级（小文档只有 H1 + 几个 H2 时的退化策略）。同 WeKnora DominantHeadingLevel。
  for (let level = 1; level <= 6; level += 1) {
    if ((profile.headingCounts[level] || 0) >= 3) { profile.dominantHeadingLevel = level; break; }
  }
  if (!profile.dominantHeadingLevel) {
    for (let level = 6; level >= 1; level -= 1) {
      if ((profile.headingCounts[level] || 0) > 0) { profile.dominantHeadingLevel = level; break; }
    }
  }
  // 策略选择（同 WeKnora SelectStrategy 的 tier 思路）：
  //   heading   —— 有 Markdown 标题骨架 → 优先按标题边界切分
  //   heuristic —— 无标题但有段落结构 → 按安全换行装箱（受保护区域不切断）
  //   legacy    —— 纯长文 → 同样走安全换行装箱（兜底）
  if (profile.headingTotal >= 3 && profile.dominantHeadingLevel > 0) {
    profile.strategy = 'heading';
  } else if (profile.numberedSectionCount >= 5 || profile.blankParagraphBreaks > 0 || source.includes('\n\n')) {
    profile.strategy = 'heuristic';
  } else {
    profile.strategy = 'legacy';
  }
  return profile;
}

// 计算受保护区域的 [start, end) 区间列表（升序、重叠区间合并）。
// 落在这些区间内的换行不会成为切点，代码块 / 表格 / 公式因此不会被拦腰切断。
function findProtectedSpans(text) {
  const spans = [];
  for (const pattern of PROTECTED_SPAN_PATTERNS) {
    pattern.lastIndex = 0;
    let match;
    while ((match = pattern.exec(text)) !== null) {
      if (match[0].length > 0) spans.push([match.index, match.index + match[0].length]);
      if (match.index === pattern.lastIndex) pattern.lastIndex += 1;
    }
  }
  // Markdown 表格：连续 >= 2 行以 | 开头结尾的行视为一个表格整体。
  // span 不含行尾换行，表格结束后紧跟的换行仍是合法切点。
  const lines = text.split('\n');
  let pos = 0;
  let tableStart = -1;
  let tableLineCount = 0;
  let tableLastEnd = 0;
  const flushTable = () => {
    if (tableStart >= 0 && tableLineCount >= 2) spans.push([tableStart, tableLastEnd]);
    tableStart = -1;
    tableLineCount = 0;
  };
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    const trimmed = line.trim();
    const isTableLine = trimmed.startsWith('|') && trimmed.endsWith('|') && trimmed.length >= 2;
    if (isTableLine) {
      if (tableStart < 0) tableStart = pos;
      tableLineCount += 1;
      tableLastEnd = pos + line.length;
    } else {
      flushTable();
    }
    pos += line.length + (i < lines.length - 1 ? 1 : 0);
  }
  flushTable();
  spans.sort((a, b) => a[0] - b[0] || b[1] - a[1]);
  const merged = [];
  for (const span of spans) {
    const last = merged[merged.length - 1];
    if (last && span[0] <= last[1]) last[1] = Math.max(last[1], span[1]);
    else merged.push([span[0], span[1]]);
  }
  return merged;
}

// 按主标题层级把文档切成带起止偏移与面包屑的 section 列表。
// 返回 null 表示没有可用的标题骨架（调用方退回整段切分）。
// 对应 WeKnora heading_splitter.go 的 findHeadingBoundaries + 层级面包屑快照。
function splitByHeadings(text, primaryLevel) {
  const lines = text.split('\n');
  const bounds = [0];
  const headingEvents = [];
  let pos = 0;
  let inFence = false;
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    const trimmed = line.trim();
    if (trimmed.startsWith('```')) {
      inFence = !inFence;
    } else if (!inFence) {
      const match = line.match(/^(#{1,6})\s+\S/);
      if (match) {
        const level = match[1].length;
        headingEvents.push({ pos, level, line: line.trim() });
        if (level <= primaryLevel && pos > 0) bounds.push(pos);
      }
    }
    pos += line.length + (i < lines.length - 1 ? 1 : 0);
  }
  if (bounds.length <= 1) return null;

  const sections = [];
  const stack = [];
  let eventIndex = 0;
  const renderBreadcrumb = () => stack.map((entry) => entry.text).join('\n');
  for (let b = 0; b < bounds.length; b += 1) {
    const start = bounds[b];
    const end = b + 1 < bounds.length ? bounds[b + 1] : text.length;
    let breadcrumb = '';
    while (eventIndex < headingEvents.length && headingEvents[eventIndex].pos < end) {
      const event = headingEvents[eventIndex];
      while (stack.length && stack[stack.length - 1].level >= event.level) stack.pop();
      stack.push({ level: event.level, text: event.line });
      if (event.pos === start) breadcrumb = renderBreadcrumb();
      eventIndex += 1;
    }
    // section 内部没有领头标题时，继承上一节的层级语境（同 WeKnora hierarchy 持续观测）
    if (!breadcrumb && stack.length) breadcrumb = renderBreadcrumb();
    sections.push({ text: text.slice(start, end), start, end, breadcrumb });
  }
  return sections;
}

// 找出所有"安全切点"：每个换行之后都是一个候选切点，但落在受保护区域内的换行被剔除。
// 对应 WeKnora heuristic_splitter.go 的 dropBoundsInsideSpans。
function buildSafeBreaks(text, spans) {
  const breaks = [0];
  let si = 0;
  for (let i = 0; i < text.length; i += 1) {
    if (text.charCodeAt(i) !== 10) continue;
    while (si < spans.length && spans[si][1] <= i) si += 1;
    const inside = si < spans.length && i >= spans[si][0];
    if (!inside) breaks.push(i + 1);
  }
  breaks.push(text.length);
  return breaks;
}

// 在安全切点上做贪心装箱：累积块直到超过 maxChars 再 flush，
// flush 后按 overlapRatio 把起点回退到最近的安全切点形成重叠。
// 对应 WeKnora heuristic_splitter.go 的 bin-packing + splitter.py 的 chunk_overlap。
function packWithOverlap(text, breaks, maxChars, overlapRatio) {
  const out = [];
  const minChunkSize = Math.max(50, Math.floor(maxChars / 4));
  const overlapChars = Math.floor(maxChars * overlapRatio);
  let chunkStart = breaks[0];
  let curEnd = breaks[0];
  for (let i = 1; i < breaks.length; i += 1) {
    const nextEnd = breaks[i];
    const blockLen = nextEnd - curEnd;
    if (blockLen > maxChars) {
      // 单个块本身超尺寸（巨型表格 / 代码块 / 超长单行）：flush 当前累积后硬切该块
      if (curEnd > chunkStart) {
        out.push({ text: text.slice(chunkStart, curEnd), start: chunkStart, end: curEnd });
        chunkStart = curEnd;
      }
      // v2.9.1: 硬切点做代理对校正——超长块（巨型表格/代码块）按 maxChars 截断时
      //   可能切在 emoji / CJK 扩展 B 汉字中间产出孤立代理；pieceEnd 由校正后的
      //   位置推进，校正最多前移 1 字符，pieceEnd <= offset 时兜底前进 1 防死循环。
      for (let offset = curEnd; offset < nextEnd;) {
        let pieceEnd = Math.min(offset + maxChars, nextEnd);
        if (pieceEnd < nextEnd) pieceEnd = adjustSurrogateCut(text, pieceEnd);
        if (pieceEnd <= offset) pieceEnd = Math.min(offset + 1, nextEnd);
        out.push({ text: text.slice(offset, pieceEnd), start: offset, end: pieceEnd });
        offset = pieceEnd;
      }
      curEnd = nextEnd;
      chunkStart = nextEnd;
      continue;
    }
    const accumulated = nextEnd - chunkStart;
    if (accumulated > maxChars && curEnd - chunkStart >= minChunkSize) {
      out.push({ text: text.slice(chunkStart, curEnd), start: chunkStart, end: curEnd });
      // 重叠回退：取 [curEnd - overlapChars, curEnd] 内、大于旧 chunkStart 的最大安全切点
      let overlapStart = -1;
      if (overlapChars > 0) {
        const floor = curEnd - overlapChars;
        for (const candidate of breaks) {
          if (candidate <= chunkStart) continue;
          if (candidate < floor) continue;
          // 严格小于 curEnd：候选 == curEnd 意味着零重叠，等价于关闭重叠
          if (candidate >= curEnd) break;
          overlapStart = candidate;
        }
      }
      chunkStart = overlapStart >= 0 ? overlapStart : curEnd;
    }
    curEnd = nextEnd;
  }
  if (curEnd > chunkStart) out.push({ text: text.slice(chunkStart, curEnd), start: chunkStart, end: curEnd });
  return out.length ? out : [{ text, start: 0, end: text.length }];
}

// 把一个（可能超尺寸的）文本段切成 <= maxChars 的带偏移片段，受保护区域不切断。
function splitRespectingProtected(text, maxChars, overlapRatio) {
  if (!text) return [];
  if (text.length <= maxChars) return [{ text, start: 0, end: text.length }];
  const spans = findProtectedSpans(text);
  const breaks = buildSafeBreaks(text, spans);
  return packWithOverlap(text, breaks, maxChars, overlapRatio);
}

// 两个面包屑的行对齐公共前缀。同 WeKnora heading_splitter.go 的 commonHeadingPrefix。
function commonBreadcrumbPrefix(a, b) {
  if (a === b) return a;
  const la = String(a || '').split('\n');
  const lb = String(b || '').split('\n');
  const n = Math.min(la.length, lb.length);
  let common = 0;
  for (let i = 0; i < n; i += 1) {
    if (la[i].trim() !== lb[i].trim()) break;
    common = i + 1;
  }
  return common ? la.slice(0, common).join('\n') : '';
}

// 合并相邻、同语境、过小的切片，减少 AI 调用次数。
// 只合并 cur.end === next.start（相邻且无重叠）的切片，避免重叠内容被拼接重复。
// 对应 WeKnora heading_splitter.go 的 coalesceTinyChunks（target ≈ chunkSize/2）。
function coalesceTinyChunks(chunks, maxChars) {
  if (chunks.length <= 1) return chunks;
  const target = Math.max(200, Math.floor(maxChars / 2));
  const out = [];
  let cur = chunks[0];
  for (let i = 1; i < chunks.length; i += 1) {
    const next = chunks[i];
    const adjacent = cur.end === next.start;
    const shared = commonBreadcrumbPrefix(cur.breadcrumb || '', next.breadcrumb || '');
    const sameContext = (cur.breadcrumb || '') === (next.breadcrumb || '') || shared !== '';
    const canMerge = adjacent
      && sameContext
      && cur.markdown.length < target
      && cur.markdown.length + next.markdown.length <= maxChars;
    if (canMerge) {
      cur = {
        markdown: cur.markdown + next.markdown,
        start: cur.start,
        end: next.end,
        breadcrumb: shared || cur.breadcrumb || ''
      };
      continue;
    }
    out.push(cur);
    cur = next;
  }
  out.push(cur);
  return out;
}

// 切片校验：顺序升序、原文被完整覆盖（允许重叠）、超尺寸告警。
// 只打 diag 日志不阻断流程。对应 WeKnora splitter.py 的 _validate_chunks 与 validator.go。
function validateChunks(chunks, source, maxChars) {
  try {
    if (!chunks.length) {
      diag('splitter.validate', { ok: false, reason: 'no-chunks', chars: source.length });
      return false;
    }
    for (let i = 1; i < chunks.length; i += 1) {
      if (chunks[i].start < chunks[i - 1].start) {
        diag('splitter.validate', { ok: false, reason: 'order', index: i });
        return false;
      }
    }
    let covered = 0;
    for (const chunk of chunks) {
      if (chunk.start > covered) {
        diag('splitter.validate', { ok: false, reason: 'gap', at: covered, next: chunk.start });
        return false;
      }
      covered = Math.max(covered, chunk.end);
    }
    if (covered < source.length) {
      diag('splitter.validate', { ok: false, reason: 'tail-gap', covered, total: source.length });
      return false;
    }
    for (const chunk of chunks) {
      const len = chunk.end - chunk.start;
      if (len > maxChars * 1.5) diag('splitter.validate', { warn: 'oversize', len, max: maxChars });
    }
    return true;
  } catch (error) {
    diag('splitter.validate', { ok: false, reason: 'exception', message: String((error && error.message) || error) });
    return false;
  }
}

// v2.7 重写：WeKnora 式切片主入口。
// options:
//   maxChars      —— 单切片字符上限（默认 12000）
//   overlapRatio  —— 相邻切片重叠比例（0–0.5，默认 0）
//   coalesceTiny  —— 是否合并过小相邻切片（默认 true）
//   profile       —— 预先算好的文档画像（可选，避免重复扫描）
// 返回形状向后兼容：{ chunk_id, markdown, headings } 并新增 breadcrumb（标题层级语境）。
function splitMarkdownSections(markdown, options = {}) {
  const source = String(markdown || '');
  const maxChars = Math.max(100, Number(options.maxChars) || 12000);
  const rawOverlap = Number(options.overlapRatio);
  const overlapRatio = Number.isFinite(rawOverlap) ? Math.min(0.5, Math.max(0, rawOverlap)) : 0;
  const coalesceTiny = options.coalesceTiny !== false;
  if (!source.trim()) return [{ chunk_id: 'chunk-001', markdown: source, headings: [], breadcrumb: '' }];

  const profile = options.profile && typeof options.profile === 'object' ? options.profile : profileMarkdown(source);
  diag('splitter.profile', {
    chars: profile.totalChars,
    headings: profile.headingTotal,
    dominant: profile.dominantHeadingLevel,
    tables: profile.hasTables,
    code: profile.hasCode,
    codeRatio: Number((profile.codeRatio || 0).toFixed(3)),
    strategy: profile.strategy
  });

  let sections = null;
  if (profile.strategy === 'heading' && profile.dominantHeadingLevel > 0) {
    sections = splitByHeadings(source, profile.dominantHeadingLevel);
  }
  if (!sections || !sections.length) {
    sections = [{ text: source, start: 0, end: source.length, breadcrumb: '' }];
  }

  const rawChunks = [];
  for (const section of sections) {
    const pieces = splitRespectingProtected(section.text, maxChars, overlapRatio);
    for (const piece of pieces) {
      rawChunks.push({
        markdown: piece.text,
        start: section.start + piece.start,
        end: section.start + piece.end,
        breadcrumb: section.breadcrumb
      });
    }
  }

  const chunks = coalesceTiny ? coalesceTinyChunks(rawChunks, maxChars) : rawChunks;
  validateChunks(chunks, source, maxChars);

  return chunks.map((chunk, index) => ({
    chunk_id: `chunk-${String(index + 1).padStart(3, '0')}`,
    markdown: chunk.markdown,
    headings: [...String(chunk.markdown).matchAll(/^#{1,6}\s+(.+)$/gm)].map((match) => match[1].trim()),
    breadcrumb: chunk.breadcrumb || ''
  }));
}

async function summarizeDocument(options) {
  // v2.7: 透传 WeKnora 式切片参数（重叠比例 + 小节合并开关）
  const chunks = splitMarkdownSections(options.parsePackage.markdown, {
    maxChars: options.maxChunkChars,
    overlapRatio: options.chunkOverlapRatio,
    coalesceTiny: options.coalesceTinyChunks
  });
  const partials = new Array(chunks.length);
  const concurrency = Math.max(1, Math.min(3, Number(options.summaryConcurrency) || 2));
  let nextChunkIndex = 0;
  async function summarizeChunk(index) {
    const chunk = chunks[index];
    // v2.7: 把标题层级面包屑（WeKnora ContextHeader）注入 prompt，让 AI 拿到章节语境
    const chunkContext = chunk.breadcrumb
      ? `当前分块 ${chunk.chunk_id}（${index + 1}/${chunks.length}），所属章节路径：\n${chunk.breadcrumb}`
      : `当前分块 ${chunk.chunk_id}（${index + 1}/${chunks.length}）：`;
    const prompt = [
      options.basePrompt,
      '当前文档类型专用规则：',
      options.typePrompt,
      '分类结果：',
      JSON.stringify(options.classification, null, 2),
      chunkContext,
      chunk.markdown,
      `coverage.chunk_ids 必须且只能包含 ["${chunk.chunk_id}"]，complete 必须为 true。`,
      '所有面向使用者的内容统一使用简体中文。只返回符合 structured-summary.schema.json 的 JSON。'
    ].filter(Boolean).join('\n\n');
    partials[index] = await requestWithContract({
      prompt,
      stage: 'summary-map',
      schema: options.summarySchema,
      requestJson: options.requestJson,
      requestStream: options.requestStream,
      streaming: !!options.requestStream,
      maxRepairAttempts: options.maxRepairAttempts,
      onProgress: options.onProgress,
      context: { chunk, chunkIndex: index + 1, chunkTotal: chunks.length },
      normalizeValue: (value) => normalizeSummaryMap(value, options, chunk),
      extraValidation: (value) => exactCoverage(value.coverage, 'chunk_ids', [chunk.chunk_id], '总结分块覆盖不完整')
    });
  }
  async function summaryWorker() {
    while (true) {
      const index = nextChunkIndex++;
      if (index >= chunks.length) return;
      await summarizeChunk(index);
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, chunks.length) }, () => summaryWorker()));

  if (partials.length === 1) return partials[0];
  if (partials.length > Math.max(2, Number(options.reduceBatchSize) || 8)) {
    return reduceSummaryHierarchy(options, partials, Math.max(2, Number(options.reduceBatchSize) || 8));
  }
  const chunkIds = chunks.map((chunk) => chunk.chunk_id);
  const reducePrompt = [
    options.basePrompt,
    '当前文档类型专用规则：',
    options.typePrompt,
    '请合并以下逐块总结，去重但不得删除任何有证据的独立事实、决策、要求、风险、参数、行动项或经验。',
    '保持每个 key_point 到 evidence_id 的可追溯关系。不得补充逐块总结中不存在的事实。',
    `coverage.chunk_ids 必须完整且只能为：${JSON.stringify(chunkIds)}；complete 必须为 true。`,
    JSON.stringify(partials, null, 2),
    '所有面向使用者的内容统一使用简体中文。只返回符合 structured-summary.schema.json 的 JSON。'
  ].filter(Boolean).join('\n\n');
  try {
    return await requestWithContract({
      prompt: reducePrompt,
      stage: 'summary-reduce',
      schema: options.summarySchema,
      requestJson: options.requestJson,
      requestStream: options.requestStream,
      streaming: !!options.requestStream,
      maxRepairAttempts: options.maxRepairAttempts,
      onProgress: options.onProgress,
      context: { chunkIds, partialCount: partials.length },
      extraValidation: (value) => exactCoverage(value.coverage, 'chunk_ids', chunkIds, '总结分块覆盖不完整')
    });
  } catch (error) {
    if (error?.code !== 'AI_OUTPUT_TRUNCATED') throw error;
    return mergeStructuredSummaries(partials, chunkIds, options.summarySchema);
  }
}

function normalizeSummaryMap(value, options, chunk) {
  if (!value || typeof value !== 'object') return value;
  const result = Object.assign({}, value, {
    document_title: value.document_title || options.parsePackage.source_name || '结构化总结',
    library: options.classification.library,
    folder_type: options.classification.folder_type,
    document_type: options.classification.document_type,
    coverage: { chunk_ids: [chunk.chunk_id], complete: true }
  });
  if (Array.isArray(result.evidence)) {
    // v2.7: 优先用标题层级面包屑做定位（"第3章 结构 > 3.2 荷载"），退回 chunk 内首个标题
    var breadcrumbPath = String(chunk.breadcrumb || '')
      .split('\n')
      .map(function(line) { return line.replace(/^#{1,6}\s+/, '').trim(); })
      .filter(Boolean)
      .join(' > ');
    var fallbackLocator = breadcrumbPath
      || ((chunk.headings && chunk.headings.length) ? chunk.headings[0] : chunk.chunk_id);
    var fallbackQuote = safeSlice(String(chunk.markdown || ''), 0, 200).replace(/\n/g, ' ').trim() || fallbackLocator;
    result.evidence = result.evidence.map(function(item, index) {
      if (!item || typeof item !== 'object') return item;
      return Object.assign({}, item, {
        evidence_id: item.evidence_id || ('evidence-' + (index + 1)),
        locator: item.locator || fallbackLocator,
        quote: item.quote || fallbackQuote
      });
    });
  }
  return result;
}

function mergeStructuredSummaries(partials, chunkIds, schema) {
  const first = partials[0] || {};
  const keyPoints = [];
  const evidence = [];
  const entities = [];
  const suggestedLinks = [];
  for (let index = 0; index < partials.length; index += 1) {
    const partial = partials[index];
    const prefix = (partial.coverage?.chunk_ids || [`part-${index + 1}`]).join('-');
    const evidenceMap = new Map();
    for (let evidenceIndex = 0; evidenceIndex < (partial.evidence || []).length; evidenceIndex += 1) {
      const item = partial.evidence[evidenceIndex];
      const oldId = item.evidence_id || `evidence-${evidenceIndex + 1}`;
      const newId = `${prefix}-${oldId}`;
      evidenceMap.set(oldId, newId);
      evidence.push(Object.assign({}, item, { evidence_id: newId }));
    }
    for (let pointIndex = 0; pointIndex < (partial.key_points || []).length; pointIndex += 1) {
      const point = partial.key_points[pointIndex];
      const oldId = point.point_id || `point-${pointIndex + 1}`;
      keyPoints.push(Object.assign({}, point, {
        point_id: `${prefix}-${oldId}`,
        evidence_ids: (point.evidence_ids || []).map((id) => evidenceMap.get(id) || `${prefix}-${id}`)
      }));
    }
    entities.push(...(partial.entities || []));
    suggestedLinks.push(...(partial.suggested_links || []));
  }
  const merged = applySchemaConstants(schema, {
    document_title: first.document_title || '结构化总结',
    library: first.library,
    folder_type: first.folder_type,
    document_type: first.document_type,
    executive_summary: [...new Set(partials.map((item) => item.executive_summary).filter(Boolean))].join('\n\n'),
    entities,
    key_points: keyPoints,
    evidence,
    suggested_links: suggestedLinks,
    coverage: { chunk_ids: chunkIds, complete: true },
    model_confidence: Math.min(...partials.map((item) => Number(item.model_confidence) || 0)),
    schema_version: '1.1'
  });
  if (Array.isArray(merged.evidence)) {
    var fbTitle = first.document_title || '文档内容';
    merged.evidence = merged.evidence.map(function(item, index) {
      if (!item || typeof item !== 'object') return item;
      return Object.assign({}, item, {
        evidence_id: item.evidence_id || ('evidence-' + (index + 1)),
        locator: item.locator || fbTitle,
        quote: item.quote || fbTitle
      });
    });
  }
  const validation = validateSchema(schema, merged);
  const errors = [...validation.errors, ...exactCoverage(merged.coverage, 'chunk_ids', chunkIds, '总结分块覆盖不完整')];
  if (errors.length) throw new Error(errors.join('；'));
  // v2.8.1: 总结合并结果诊断——"未生成任何可用知识原子"排障第一步：确认总结本身有没有知识点
  diag('summary.merged', {
    chunks: chunkIds.length,
    partials: partials.length,
    keyPoints: keyPoints.length,
    evidence: evidence.length,
    title: merged.document_title
  });
  return merged;
}

async function reduceSummaryHierarchy(options, initial, batchSize) {
  let level = initial;
  let round = 1;
  while (level.length > 1) {
    const next = [];
    for (let offset = 0; offset < level.length; offset += batchSize) {
      const group = level.slice(offset, offset + batchSize);
      if (group.length === 1) {
        next.push(group[0]);
        continue;
      }
      const chunkIds = [...new Set(group.flatMap((item) => item.coverage.chunk_ids))];
      const prompt = [
        options.basePrompt,
        '当前文档类型专用规则：',
        options.typePrompt,
        `这是第 ${round} 轮分层归并。合并以下总结，去重但不得删除任何有证据的独立事实、决策、要求、风险、参数、行动项或经验。`,
        `coverage.chunk_ids 必须完整且只能为：${JSON.stringify(chunkIds)}；complete 必须为 true。`,
        JSON.stringify(group, null, 2),
        '只返回符合 structured-summary.schema.json 的 JSON。'
      ].filter(Boolean).join('\n\n');
      next.push(await requestWithContract({
        prompt,
        stage: 'summary-reduce',
        schema: options.summarySchema,
        requestJson: options.requestJson,
        maxRepairAttempts: options.maxRepairAttempts,
        onProgress: options.onProgress,
        context: { chunkIds, partialCount: group.length, reduceRound: round },
        extraValidation: (value) => exactCoverage(value.coverage, 'chunk_ids', chunkIds, '总结分块覆盖不完整')
      }));
    }
    level = next;
    round += 1;
  }
  return level[0];
}

async function atomizeSummary(options) {
  const pointIds = (options.summary.key_points || []).map((point) => point.point_id);
  // v1.1.8: 默认拆细到每批 1 个知识点，调用次数 +N-3N 但每批之间能 emit 进度，
  // 用户不再面对 18 分钟黑屏。可在 settings.maxPointsPerRequest 调高（1-3）恢复。
  const configuredBatchSize = Number(options.maxPointsPerRequest) || 1;
  const batchSize = Math.max(1, Math.min(3, configuredBatchSize));
  const batches = [];
  for (let offset = 0; offset < pointIds.length; offset += batchSize) {
    batches.push(pointIds.slice(offset, offset + batchSize));
  }
  if (!batches.length) batches.push([]);

  const results = new Array(batches.length);
  let truncated = false;
  let nextBatchIndex = 0;
  const concurrency = Math.max(1, Math.min(3, Number(options.atomizationConcurrency) || 2));
  async function processBatch(index) {
    if (truncated) return;
    const batchPointIds = batches[index];
    const pointSet = new Set(batchPointIds);
    const keyPoints = (options.summary.key_points || []).filter((point) => pointSet.has(point.point_id));
    const evidenceIds = new Set(keyPoints.flatMap((point) => point.evidence_ids || []));
    const batchSummary = Object.assign({}, options.summary, {
      executive_summary: keyPoints.map((point) => point.content).join('；'),
      key_points: keyPoints,
      evidence: (options.summary.evidence || []).filter((item) => evidenceIds.has(item.evidence_id))
    });
    // 每个 batch 开始前 emit 一次（在调用前已知批次信息）
    await emitProgress(options.onProgress, {
      stage: 'atomization',
      batchIndex: index + 1,
      batchTotal: batches.length,
      message: `原子化 ${index + 1}/${batches.length} 批（共 ${pointIds.length} 个知识点，每批 ${batchSize} 个）`
    });
    // v1.1.10: AI 输出达到 8192 token 上限（AI_OUTPUT_TRUNCATED）时不再把整个任务炸掉，
    //   暂时标记 truncated = true，中断剩余批次，将已成功的批次合并成 partial 结果。
    let batchResult;
    try {
      batchResult = await atomizeSummaryBatch(options, batchSummary, batchPointIds, index + 1, batches.length);
    } catch (error) {
      if (error && error.code === 'AI_OUTPUT_TRUNCATED') {
        truncated = true;
        if (typeof globalThis.__eksDiag === 'object' && globalThis.__eksDiag.diag) {
          globalThis.__eksDiag.diag('atomization.truncated', { completed: index, total: batches.length, pointIds: pointIds.length });
        }
        return;
      }
      throw error;
    }
    results[index] = batchResult;
    // v2.8.1: 每批原子化结果诊断（请求知识点数 vs 产出原子数），空批排障用
    diag('atomization.batch', {
      batchIndex: index + 1,
      batchTotal: batches.length,
      requestedPoints: batchPointIds.length,
      atoms: (batchResult && Array.isArray(batchResult.atoms)) ? batchResult.atoms.length : 0
    });
    // 每个 batch 完成后 emit 一次（带 batchComplete 标记，触发写盘 + UI 重渲染）
    await emitProgress(options.onProgress, {
      stage: 'atomization',
      batchIndex: index + 1,
      batchTotal: batches.length,
      batchComplete: true,
      message: truncated
        ? `原子化 ${index + 1}/${batches.length} 批完成（后续批次因 AI 输出截断而跳过）`
        : `原子化 ${index + 1}/${batches.length} 批完成`
    });
  }
  async function worker() {
    while (!truncated) {
      const index = nextBatchIndex++;
      if (index >= batches.length) return;
      await processBatch(index);
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, batches.length) }, () => worker()));
  const completedResults = results.filter(Boolean);

  // v1.1.10: 配合 maxPointsPerRequest + 截断豁免：批次全是空（pointIds 为空）时允许返回空结果。
  if (!completedResults.length) {
    return applySchemaConstants(options.atomSchema, {
      atoms: [],
      coverage: { point_ids: pointIds, complete: !truncated && completedResults.length === batches.length },
      schema_version: '1.1'
    });
  }
  if (completedResults.length === 1 && !truncated) return completedResults[0];
  const mergedAtoms = completedResults.flatMap((result) => result.atoms || []);
  const merged = applySchemaConstants(options.atomSchema, {
    atoms: mergedAtoms,
    coverage: { point_ids: pointIds, complete: !truncated && completedResults.length === batches.length },
    schema_version: '1.1'
  });
  // v1.1.10: 截断情况下跳过严格 schema 校验，避免一次大文档被反复重试；
  //   改用轻量级校验（每个 atom 至少含 atom_id）以保留尽可能多的可入库卡片。
  if (truncated) {
    const validAtoms = mergedAtoms.filter((atom) => atom && atom.atom_id);
    return Object.assign({}, merged, { atoms: validAtoms, _truncated: true });
  }
  const validation = validateSchema(options.atomSchema, merged);
  const errors = [...validation.errors, ...exactCoverage(merged.coverage, 'point_ids', pointIds, '知识点覆盖不完整')];
  if (errors.length) throw new Error(errors.join('；'));
  return merged;
}

async function atomizeSummaryBatch(options, summary, pointIds, batchIndex, batchTotal) {
  const prompt = [
    options.atomPrompt,
    'Type Mapping（静态/动态卡片判定只能参考此契约）：',
    options.typeMapping,
    '标签字典（Category / TagL1 / TagL2 只能从中精确选择，不得自造）：',
    options.tagLibrary,
    '结构化总结：',
    JSON.stringify(summary, null, 2),
    '已有知识卡片候选（related_candidates 只能引用这些 card_id；没有明确语义关系时返回空数组）：',
    JSON.stringify((options.linkCandidates || []).map((item) => ({ card_id: item.card_id, title: item.title, path: item.path })), null, 2),
    '允许的关联类型仅为 supports、contradicts、supersedes、depends_on、implements、related。',
    '每个独立且有复用价值的知识点生成一个原子；禁止只描述”召开会议、进行了讨论、应当优化”等空泛内容。',
    '每个原子的 source 必须包含源文件双链、原文定位、逐字证据和父总结双链。',
    `coverage.point_ids 必须完整且只能为：${JSON.stringify(pointIds)}；complete 必须为 true。`,
    // v2.9.2: 归一化靠 content.point_ids 把原子归属到知识点。此前所有 prompt 只要求 coverage.point_ids（批次级），
    //   从不要求逐原子的 content.point_ids → 多知识点批次里每个原子都因"无归属"被丢弃（诊断日志
    //   droppedNoPointAttribution 全等于 rawAtoms），最终误报"AI 返回内容不是有效 JSON"。这里显式立约。
    `每个原子的 content.point_ids 必须是非空字符串数组，取值只能来自本批知识点 ${JSON.stringify(pointIds)}，表示该原子归属的知识点；一个原子只归属一个知识点，禁止留空、禁止使用本批之外的 point_id。`,
    `这是知识原子化第 ${batchIndex}/${batchTotal} 批；只处理本批知识点，不得重复其他批次。`,
    '标题和正文统一使用简体中文。只返回符合 knowledge-atoms.schema.json 的 JSON。',
    // v1.1.10: 显式列出必须的最外层结构。AI 返回不带 {atoms:[...], coverage:{...}, schema_version:”1.1”}
    //   包裹的形状（如直接返回 atom 数组、或单个 atom 对象、或裸 markdown）都会被严格 schema 校验拒绝。
    //   显式约束 shape 是 90% 错误的根因。
    '【输出包裹格式（严格）】必须直接返回一个 JSON 对象，禁止用 Markdown 代码围栏（不要 ```json ... ```），禁止外层再套一层数组或对象。该对象的 keys 只能出现以下三个：atoms、coverage、schema_version，缺一不可。',
    '示例（只是格式示例，不是内容约束）：{“atoms”:[{“atom_id”:”...”,”title”:”...”,”card_kind”:”static|event”,”library”:”bid|business”,”folder_type”:”...”,”content”:{...},”source”:{“source_link”:”...”,”source_locator”:”...”,”evidence_quote”:”...”,”parent_summary”:”...”},”model_confidence”:0.0,”validation_issues”:[],”related_candidates”:[]}, ...],”coverage”:{“point_ids”:[' + pointIds.map((id) => '”' + id + '”').join(',') + '],”complete”:true},”schema_version”:”1.1”}'
  ].filter(Boolean).join('\n\n');
  return requestWithContract({
    prompt,
    stage: 'atomization',
    schema: options.atomSchema,
    requestJson: options.requestJson,
    maxRepairAttempts: options.maxRepairAttempts,
    onProgress: options.onProgress,
    context: { pointIds, batchIndex, batchTotal },
    normalizeValue: (value) => normalizeAtomBatch(value, summary, pointIds),
    // v2.8.1: 知识点非空但归一化后原子为 0 时，走一次"带校验错误的修复提示词"重试，
    //   而不是静默通过、最后在 writing 阶段才炸"未生成任何可用知识原子"
    extraValidation: (value) => [
      ...exactCoverage(value.coverage, 'point_ids', pointIds, '知识点覆盖不完整'),
      ...(pointIds.length && !(Array.isArray(value.atoms) && value.atoms.length)
        ? [`本批 ${pointIds.length} 个知识点（${pointIds.join('、')}）却返回了 0 个可用原子，请为每个知识点至少生成一个符合 schema 的原子，并在 content.point_ids 中准确填写上述 point_id`]
        : [])
    ]
  });
}

function normalizeAtomBatch(value, summary, pointIds) {
  if (!value || typeof value !== 'object') return value;
  // MiniMax 偶尔直接返回 atom 数组。包回契约对象，避免有内容却被当成 0 个原子。
  if (Array.isArray(value)) {
    value = {
      atoms: value,
      coverage: { point_ids: pointIds, complete: true },
      schema_version: '1.1'
    };
  }
  const allowed = new Set(pointIds);
  const points = new Map((summary.key_points || []).map((point) => [point.point_id, point]));
  const evidence = new Map((summary.evidence || []).map((item) => [item.evidence_id, item]));
  const byPoint = new Map();
  // v2.8.1: 统计归一化丢弃原因——旧实现静默丢弃，"未生成任何可用知识原子"无从查起
  const rawCount = Array.isArray(value.atoms) ? value.atoms.length : 0;
  let droppedMismatch = 0;
  let droppedDuplicate = 0;
  let droppedNoPoint = 0;
  const unassigned = [];
  for (const atom of value.atoms || []) {
    const candidatePointIds = [
      ...(Array.isArray(atom?.content?.point_ids) ? atom.content.point_ids : []),
      atom?.content?.point_id,
      ...(Array.isArray(atom?.point_ids) ? atom.point_ids : []),
      atom?.point_id,
      ...(Array.isArray(atom?.source?.point_ids) ? atom.source.point_ids : []),
      atom?.source?.point_id
    ].filter(Boolean);
    const rawPointIds = [...new Set(candidatePointIds)];
    const matched = rawPointIds.filter((pointId) => allowed.has(pointId));
    if (rawPointIds.length && !matched.length) { droppedMismatch += 1; continue; }
    const pointId = matched[0] || '';
    if (!pointId) {
      unassigned.push(atom);
      continue;
    }
    if (byPoint.has(pointId)) { droppedDuplicate += 1; continue; }
    byPoint.set(pointId, atom);
  }

  // 批量输出最常见的失败形态是“原子数量正确、顺序正确，但漏写 point_ids”。
  // 只对尚未归属的原子按剩余 point 顺序补齐；显式写错的原子不会进入这里。
  const remainingPointIds = pointIds.filter((pointId) => !byPoint.has(pointId));
  if (unassigned.length === remainingPointIds.length) {
    unassigned.forEach((atom, index) => byPoint.set(remainingPointIds[index], atom));
  } else if (pointIds.length === 1 && unassigned.length) {
    byPoint.set(pointIds[0], unassigned[0]);
  }
  droppedNoPoint = Math.max(0, unassigned.length - remainingPointIds.length);

  for (const [pointId, atom] of [...byPoint.entries()]) {
    const point = points.get(pointId);
    const evidenceItem = evidence.get(point?.evidence_ids?.[0]) || {};
    byPoint.set(pointId, Object.assign({}, atom, {
      content: Object.assign({}, atom.content || {}, { point_ids: [pointId] }),
      source: Object.assign({}, atom.source || {}, {
        source_link: '[[source]]',
        source_locator: evidenceItem.locator || pointId,
        evidence_quote: evidenceItem.quote || point?.content || '',
        parent_summary: '[[summary]]'
      })
    }));
  }
  const keptAtoms = pointIds.map((pointId) => byPoint.get(pointId)).filter(Boolean);
  // v2.8.1: AI 返回了原子但被归一化丢光时，必须留下可追查的诊断
  if (rawCount > 0 && (droppedMismatch || droppedDuplicate || droppedNoPoint || !keptAtoms.length)) {
    diag('atomization.normalize', {
      requestedPoints: pointIds.length,
      rawAtoms: rawCount,
      keptAtoms: keptAtoms.length,
      droppedPointIdMismatch: droppedMismatch,
      droppedDuplicatePoint: droppedDuplicate,
      droppedNoPointAttribution: droppedNoPoint
    });
  }
  return Object.assign({}, value, { atoms: keptAtoms });
}

async function requestWithContract(options) {
  const maxRepairs = options.maxRepairAttempts === undefined ? 1 : Math.max(0, Number(options.maxRepairAttempts));
  const useStream = options.streaming === true && typeof options.requestStream === 'function';
  let prompt = options.prompt;
  let lastErrors = [];
  for (let attempt = 0; attempt <= maxRepairs; attempt += 1) {
    await emitProgress(options.onProgress, Object.assign({}, options.context || {}, {
      stage: options.stage,
      attempt: attempt + 1,
      message: attempt ? '正在修正不符合契约的 AI 结果' : (useStream ? '正在调用 MiniMax M3 (SSE)' : '正在调用 MiniMax M3')
    }));
    let rawValue;
    let value;
    try {
      if (useStream && attempt === 0) {
        // 第一次尝试走 SSE 流式；失败则降级到非流式
        try {
          rawValue = await options.requestStream(prompt, Object.assign({ stage: options.stage, attempt: attempt + 1, schema: options.schema }, options.context || {}), {
            onDelta: (event, state) => {
              if (typeof options.onStreamDelta === 'function') {
                try { options.onStreamDelta(event, state); } catch (_) {}
              }
            },
            onProgressText: (text) => {
              if (typeof options.onStreamText === 'function') {
                try { options.onStreamText(text); } catch (_) {}
              }
            }
          });
        } catch (streamError) {
          diag('minimax.stream-fallback', { stage: options.stage, errorMessage: String(streamError && streamError.message || streamError) });
          rawValue = await options.requestJson(prompt, Object.assign({ stage: options.stage, attempt: attempt + 1, schema: options.schema }, options.context || {}));
        }
      } else {
        rawValue = await options.requestJson(prompt, Object.assign({ stage: options.stage, attempt: attempt + 1, schema: options.schema }, options.context || {}));
      }
      value = parseJsonPayload(rawValue);
    } catch (error) {
      if (error?.code !== 'AI_INVALID_JSON') throw error;
      lastErrors = [error.message];
      if (attempt < maxRepairs) {
        prompt = buildRepairPrompt(options.prompt, lastErrors, rawValue);
        continue;
      }
      break;
    }
    value = applySchemaConstants(options.schema, value);
    if (typeof options.normalizeValue === 'function') value = options.normalizeValue(value);
    if (value && typeof value === 'object' && Array.isArray(value.evidence)) {
      var fbLocator = value.document_title || '文档内容';
      value.evidence = value.evidence.map(function(item, index) {
        if (!item || typeof item !== 'object') return item;
        return Object.assign({}, item, {
          evidence_id: item.evidence_id || ('evidence-' + (index + 1)),
          locator: item.locator || fbLocator,
          quote: item.quote || fbLocator
        });
      });
    }
    const validation = validateSchema(options.schema, value);
    lastErrors = [...validation.errors, ...(options.extraValidation ? options.extraValidation(value) : [])];
    if (!lastErrors.length) return value;
    if (attempt < maxRepairs) {
      prompt = buildRepairPrompt(options.prompt, lastErrors, value);
    }
  }
  throw new Error(lastErrors.join('；') || `${options.stage} 结果不符合契约`);
}

function buildRepairPrompt(originalPrompt, errors, previousValue) {
  // v2.9.1: 定长截断走 safeSlice——切断的代理对进入修复 prompt 会干扰 AI 输出
  const previous = typeof previousValue === 'string'
    ? safeSlice(previousValue, 0, 12000)
    : JSON.stringify(previousValue, null, 2);
  return [
    originalPrompt,
    '上一次结果未通过校验，请只修正 JSON，不得改变原文事实。',
    `需要修正的问题：${errors.join('；')}`,
    '上一次结果：',
    previous || '未返回可解析内容，请重新输出完整 JSON。'
  ].join('\n\n');
}

function applySchemaConstants(schema, value) {
  if (!schema || typeof schema !== 'object') return value;
  if (Object.hasOwn(schema, 'const')) return schema.const;
  if (Array.isArray(value) && schema.items) {
    return value.map((item) => applySchemaConstants(schema.items, item));
  }
  if (value && typeof value === 'object' && !Array.isArray(value) && schema.properties) {
    const result = Object.assign({}, value);
    for (const [key, propertySchema] of Object.entries(schema.properties)) {
      if (Object.hasOwn(propertySchema || {}, 'const') || Object.hasOwn(result, key)) {
        result[key] = applySchemaConstants(propertySchema, result[key]);
      }
    }
    return result;
  }
  return value;
}

async function requestMiniMaxJson({ settings, prompt, fetchImpl, context }) {
  if (!settings || !settings.minimaxApiKey) throw new Error('MiniMax 国内版 API Key 未配置');
  const fetcher = fetchImpl || globalThis.fetch;
  const endpoint = settings.minimaxEndpoint || 'https://api.minimaxi.com/anthropic/v1/messages';
  const anthropicProtocol = /\/anthropic\/v1\/messages\/?$/i.test(endpoint);
  if (typeof fetcher !== 'function') throw new Error('当前环境不支持网络请求');
  const controller = typeof AbortController === 'function' ? new AbortController() : null;
  const timeoutMs = Math.max(10000, Number(settings.aiRequestTimeoutMs) || 180000);
  const timer = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
  let response;
  try {
    const body = {
      model: settings.minimaxModel || 'MiniMax-M3',
      messages: [
        { role: 'system', content: '你是工程知识处理引擎。严格返回 JSON，不要输出 Markdown 代码围栏。' },
        { role: 'user', content: prompt }
      ],
      max_completion_tokens: 2048,
      reasoning_split: true,
      temperature: context && context.stage === 'classification' ? 0.1 : 0.2
    };
    if (context?.schema) {
      body.tools = [{
        type: 'function',
        function: {
          name: 'return_structured_result',
          description: '返回严格符合参数 Schema 的工程知识处理结果。',
          parameters: context.schema
        }
      }];
      body.tool_choice = 'auto';
    }
    let headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${settings.minimaxApiKey}` };
    if (anthropicProtocol) {
      body.max_tokens = 8192;
      delete body.max_completion_tokens;
      delete body.reasoning_split;
      body.system = '你是工程知识处理引擎。只通过指定工具返回结构化结果，不要输出额外说明。';
      body.messages = [{ role: 'user', content: prompt }];
      if (context?.schema) {
        body.tools = [{
          name: 'return_structured_result',
          description: '返回严格符合输入 Schema 的工程知识处理结果。',
          input_schema: context.schema
        }];
        body.tool_choice = { type: 'tool', name: 'return_structured_result' };
      }
      headers = { 'Content-Type': 'application/json', 'x-api-key': settings.minimaxApiKey, 'anthropic-version': '2023-06-01' };
    }
    response = await fetchWithTransientRetry(fetcher, endpoint, {
      method: 'POST',
      headers,
      signal: controller ? controller.signal : undefined,
      body: JSON.stringify(body)
    }, settings);
  } catch (error) {
    if (error && error.name === 'AbortError') {
      diag('minimax.timeout', { endpoint, timeoutMs, stage: context && context.stage });
      throw new Error(`MiniMax 国内版请求超时（${Math.round(timeoutMs / 1000)} 秒）`);
    }
    diag('minimax.transport', {
      endpoint,
      stage: context && context.stage,
      errorClass: error && error.constructor ? error.constructor.name : typeof error,
      errorMessage: String(error && error.message || error)
    });
    throw new Error(`MiniMax 国内版请求失败：${sanitizeError(error)}`);
  } finally {
    if (timer) clearTimeout(timer);
  }
  if (!response.ok) {
    const detail = await safeResponseText(response);
    diag('minimax.http', {
      endpoint,
      stage: context && context.stage,
      status: response.status,
      bodySnippet: String(detail || '').slice(0, 500)
    });
    throw new Error(`MiniMax 国内版请求失败（HTTP ${response.status}）${detail ? `：${detail}` : ''}`);
  }
  const payload = await response.json();
  if (anthropicProtocol) {
    if (payload?.stop_reason === 'max_tokens') {
      throw outputTruncatedError('MiniMax 输出达到 8192 token 上限，结果已截断。');
    }
    const toolUse = (payload?.content || []).find((item) => item?.type === 'tool_use' && item?.name === 'return_structured_result');
    const text = (payload?.content || []).filter((item) => item?.type === 'text').map((item) => item.text || '').join('\n');
    const content = toolUse?.input || text;
    if (!content) throw new Error('MiniMax 国内版返回内容为空');
    return parseJsonPayload(content);
  }
  const choice = payload && payload.choices && payload.choices[0];
  if (choice?.finish_reason === 'length' || choice?.finish_reason === 'max_output') {
    throw outputTruncatedError('MiniMax 输出达到 2048 token 上限，结果已截断；请缩小单批知识点数量后重试。');
  }
  const toolCall = choice?.message?.tool_calls?.find((item) => item?.function?.name === 'return_structured_result');
  const content = toolCall?.function?.arguments || (choice && choice.message && choice.message.content);
  if (!content) throw new Error('MiniMax 国内版返回内容为空');
  return parseJsonPayload(content);
}

/**
 * v2.2 (PR 4) SSE 流式请求 POC
 *
 * 用 globalThis.fetch 的 ReadableStream 读取 text/event-stream，
 * 把 data: {json} 事件按 \n\n 切分，逐条 JSON.parse 后回调 onDelta。
 *
 * ⚠️ 限制：
 * - Obsidian 的 `requestUrl` 不暴露 stream，所以这里走 globalThis.fetch
 *   （Obsidian 桌面端是 Electron / Chromium 27+，fetch + ReadableStream 都有）
 * - iOS 移动端 fetch 也支持，但 ReadableStream 行为可能差异更大
 * - 失败时不重试（与 fetchWithTransientRetry 行为不同），调用方需自己 try/catch
 */
async function sseJsonRequest(url, init, onDelta) {
  const response = await globalThis.fetch(url, init);
  if (!response.ok) {
    const text = await response.text().catch(() => '');
    throw new Error(`SSE 请求失败（HTTP ${response.status}）${text ? `：${text.slice(0, 200)}` : ''}`);
  }
  if (!response.body || typeof response.body.getReader !== 'function') {
    throw new Error('当前环境不支持 ReadableStream，无法使用 SSE 流式');
  }
  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  let eventCount = 0;
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let sepIndex;
    while ((sepIndex = buffer.indexOf('\n\n')) >= 0) {
      const block = buffer.slice(0, sepIndex);
      buffer = buffer.slice(sepIndex + 2);
      const event = parseSseEvent(block);
      if (!event) continue;
      eventCount += 1;
      if (typeof onDelta === 'function') onDelta(event);
      if (event.type === 'message_stop' || event.type === 'done' || event.type === 'response.done') {
        try { await reader.cancel(); } catch (_) {}
        return { ok: true, events: eventCount };
      }
    }
  }
  return { ok: true, events: eventCount };
}

function parseSseEvent(block) {
  const lines = block.split('\n');
  let eventName = 'message';
  const dataLines = [];
  for (const line of lines) {
    if (!line || line.startsWith(':')) continue;
    if (line.startsWith('event:')) eventName = line.slice(6).trim();
    else if (line.startsWith('data:')) dataLines.push(line.slice(5).trim());
  }
  if (!dataLines.length) return null;
  const dataStr = dataLines.join('\n');
  if (dataStr === '[DONE]') return { type: 'done', raw: dataStr };
  let data;
  try { data = JSON.parse(dataStr); } catch (_) { return { type: eventName, raw: dataStr }; }
  return Object.assign({ type: eventName }, data);
}

/**
 * 累积 Anthropic-style content_block_delta 事件里的 text 增量，
 * 以及 tool_use block 里的 input_json_delta（拼成完整 JSON 字符串）。
 */
function collectSseTextDeltas(event, state) {
  if (!event) return;
  // Anthropic Messages API SSE
  if (event.type === 'content_block_start' && event.content_block && event.content_block.type === 'tool_use') {
    state.toolUseId = event.content_block.id;
    state.toolInputJson = '';
  }
  if (event.type === 'content_block_delta' && event.delta) {
    if (event.delta.type === 'text_delta' && typeof event.delta.text === 'string') {
      state.text += event.delta.text;
    } else if (event.delta.type === 'input_json_delta' && typeof event.delta.partial_json === 'string') {
      state.toolInputJson += event.delta.partial_json;
    }
  }
}

/**
 * v2.2 (PR 4) MiniMax 流式变体
 * 与 requestMiniMaxJson 等价的请求体，但启用 stream:true 并通过 SSE 累积返回。
 * 返回字符串（与 requestMiniMaxJson 的 parseJsonPayload 输入等价）。
 */
async function requestMiniMaxStream({ settings, prompt, context, onDelta, onProgressText }) {
  if (!settings || !settings.minimaxApiKey) throw new Error('MiniMax 国内版 API Key 未配置');
  const endpoint = settings.minimaxEndpoint || 'https://api.minimaxi.com/anthropic/v1/messages';
  const anthropicProtocol = /\/anthropic\/v1\/messages\/?$/i.test(endpoint);
  const body = {
    model: settings.minimaxModel || 'MiniMax-M3',
    messages: anthropicProtocol
      ? [{ role: 'user', content: prompt }]
      : [{ role: 'system', content: '你是工程知识处理引擎。严格返回 JSON，不要输出 Markdown 代码围栏。' },
         { role: 'user', content: prompt }],
    max_completion_tokens: 2048,
    reasoning_split: true,
    temperature: context && context.stage === 'classification' ? 0.1 : 0.2,
    stream: true
  };
  if (anthropicProtocol) {
    body.max_tokens = 8192;
    delete body.max_completion_tokens;
    delete body.reasoning_split;
    body.system = '你是工程知识处理引擎。只通过指定工具返回结构化结果，不要输出额外说明。';
  }
  let headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${settings.minimaxApiKey}` };
  if (context?.schema) {
    body.tools = anthropicProtocol
      ? [{ name: 'return_structured_result', description: '返回严格符合输入 Schema 的工程知识处理结果。', input_schema: context.schema }]
      : [{ type: 'function', function: { name: 'return_structured_result', description: '返回严格符合参数 Schema 的工程知识处理结果。', parameters: context.schema } }];
    body.tool_choice = anthropicProtocol ? { type: 'tool', name: 'return_structured_result' } : 'auto';
  }
  if (anthropicProtocol) {
    headers = { 'Content-Type': 'application/json', 'x-api-key': settings.minimaxApiKey, 'anthropic-version': '2023-06-01' };
  }
  const controller = typeof AbortController === 'function' ? new AbortController() : null;
  const timeoutMs = Math.max(10000, Number(settings.aiRequestTimeoutMs) || 180000);
  const timer = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
  try {
    const state = { text: '', toolInputJson: '' };
    await sseJsonRequest(endpoint, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
      signal: controller ? controller.signal : undefined
    }, (event) => {
      collectSseTextDeltas(event, state);
      if (typeof onDelta === 'function') onDelta(event, state);
      // 透传进度文本（每 30 字符报告一次，避免 onProgress 风暴）
      if (typeof onProgressText === 'function' && state.text.length % 30 < 2) {
        onProgressText(state.text);
      }
    });
    const finalContent = state.toolInputJson || state.text;
    if (!finalContent) throw new Error('MiniMax 流式返回内容为空');
    return finalContent;
  } catch (error) {
    if (error && error.name === 'AbortError') {
      throw new Error(`MiniMax 流式请求超时（${Math.round(timeoutMs / 1000)} 秒）`);
    }
    throw error;
  } finally {
    if (timer) clearTimeout(timer);
  }
}

function exactCoverage(coverage, key, expected, message) {
  if (!coverage || coverage.complete !== true) return [message];
  const actual = Array.isArray(coverage[key]) ? coverage[key] : [];
  const left = [...new Set(actual)].sort();
  const right = [...new Set(expected)].sort();
  return left.length === right.length && left.every((item, index) => item === right[index]) ? [] : [message];
}

function outputTruncatedError(message) {
  const error = new Error(message);
  error.code = 'AI_OUTPUT_TRUNCATED';
  return error;
}

async function fetchWithTransientRetry(fetcher, endpoint, options, settings) {
  const configuredAttempts = Number(settings?.aiRequestMaxAttempts);
  const maxAttempts = Number.isFinite(configuredAttempts)
    ? Math.min(5, Math.max(1, Math.round(configuredAttempts)))
    : 3;
  const configuredBaseMs = Number(settings?.aiRetryBaseMs);
  const baseMs = Number.isFinite(configuredBaseMs) ? Math.max(0, configuredBaseMs) : 800;
  let lastError;

  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    try {
      const response = await fetcher(endpoint, options);
      if (response.ok || !isTransientHttpStatus(response.status) || attempt === maxAttempts) return response;
      await safeResponseText(response);
    } catch (error) {
      if (error?.name === 'AbortError' || attempt === maxAttempts) throw error;
      lastError = error;
    }
    await sleep(baseMs * (2 ** (attempt - 1)));
  }

  throw lastError || new Error('MiniMax request failed after retries');
}

function isTransientHttpStatus(status) {
  // v2.8.1: 加入 529——Anthropic 协议（MiniMax 国内版兼容接口）的 overloaded_error，
  //   纯服务端过载、稍后即恢复。旧版不重试 529，用户一次 529 就废掉整个已跑 9 分钟的任务。
  return [408, 425, 429, 500, 502, 503, 504, 529].includes(Number(status));
}

function sleep(ms) {
  return ms > 0 ? new Promise((resolve) => setTimeout(resolve, ms)) : Promise.resolve();
}

function parseJsonPayload(value) {
  if (value && typeof value === 'object') return unwrapTextJson(value);
  let text = String(value || '').trim().replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
  text = text.replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/i, '').trim();
  try { return JSON.parse(text); } catch {}
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start >= 0 && end > start) {
    const sliced = text.slice(start, end + 1).replace(/,\s*([}\]])/g, '$1');
    try { return JSON.parse(sliced); } catch {}
    // 兜底：尝试补全未闭合的括号/引号
    const repaired = repairJsonText(sliced);
    if (repaired) {
      try { return JSON.parse(repaired); } catch {}
    }
  }
  // 外层对象截断时，lastIndexOf('}') 可能只命中内部对象；此前 slice 会把
  // 未闭合的 atoms/coverage 尾部直接丢掉。对从首个 { 到响应末尾的文本再修一次。
  if (start >= 0) {
    const repaired = repairJsonText(text.slice(start));
    if (repaired) {
      try { return JSON.parse(repaired); } catch {}
    }
  }
  const error = new Error('AI 返回内容不是有效 JSON');
  error.code = 'AI_INVALID_JSON';
  throw error;
}

/**
 * v2.4: AI 输出截断时尝试补全 JSON。
 * - 去掉尾部逗号
 * - 补全未闭合的字符串 / 数组 / 对象
 * 返回补全后的文本；仍不可解析则返回 null。
 */
function repairJsonText(text) {
  if (!text || typeof text !== 'string') return null;
  let s = text.replace(/,\s*$/, '');
  // 在 escape 状态外，记录最后未闭合的引号
  let inString = false;
  let escape = false;
  const stack = []; // 期望闭合的括号，'[' 或 '{'
  for (let i = 0; i < s.length; i += 1) {
    const ch = s[i];
    if (escape) { escape = false; continue; }
    if (ch === '\\') { escape = true; continue; }
    if (ch === '"') { inString = !inString; continue; }
    if (inString) continue;
    if (ch === '{' || ch === '[') stack.push(ch === '{' ? '}' : ']');
    else if (ch === '}' || ch === ']') stack.pop();
  }
  // 收尾
  if (inString) s += '"';
  while (stack.length) {
    const closer = stack.pop();
    s += closer;
  }
  // 二次去尾随逗号
  s = s.replace(/,\s*([}\]])/g, '$1').replace(/,\s*$/, '');
  try { JSON.parse(s); return s; } catch { return null }
}

function unwrapTextJson(value) {
  if (Array.isArray(value)) return value.map(unwrapTextJson);
  if (!value || typeof value !== 'object') return value;
  const result = {};
  if (typeof value.$text === 'string') {
    try {
      const parsed = parseJsonPayload(value.$text);
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) Object.assign(result, parsed);
    } catch {}
  }
  for (const [key, item] of Object.entries(value)) {
    if (key === '$text') continue;
    result[key] = unwrapTextJson(item);
  }
  return Object.keys(result).length ? result : value;
}

async function safeResponseText(response) {
  try { return String(await response.text()).replace(/\s+/g, ' ').slice(0, 300); } catch { return ''; }
}

function sanitizeError(error) {
  return String(error && error.message ? error.message : error || '未知错误').replace(/(bearer|token|api[_ -]?key)\s*[:=]?\s*\S+/gi, '$1 ***');
}

async function emitProgress(onProgress, payload) {
  if (typeof onProgress === 'function') await onProgress(payload);
}

module.exports = {
  atomizeSummary,
  buildClassificationPrompt,
  classifyDocument,
  classificationSample,
  coalesceTinyChunks,
  commonBreadcrumbPrefix,
  findProtectedSpans,
  findRoute,
  normalizeAtomBatch,
  parseJsonPayload,
  profileMarkdown,
  repairJsonText,
  requestMiniMaxJson,
  requestMiniMaxStream,
  requestWithContract,
  safeSlice,
  splitByHeadings,
  splitMarkdownSections,
  summarizeDocument,
  validateChunks
};

},
/**
 * @module src/core/confidence
 * 卡片置信度评分：基于 schema 合规度 / AI 不确定性 / 字段完整度
 * @exports calculateConfidence
 */
"src/core/confidence.js": function(require, module, exports) {
const WEIGHTS = { P: 0.25, T: 0.15, E: 0.35, S: 0.15, A: 0.10 };

function calculateConfidence(input) {
  const hardRules = [];
  const parseMarkdown = normalizeText(input.parsePackage && input.parsePackage.markdown);
  const source = input.atom && input.atom.source ? input.atom.source : {};
  const evidenceQuote = normalizeText(source.evidence_quote);
  const atomText = normalizeText(`${input.atom && input.atom.title || ''} ${flattenContent(input.atom && input.atom.content)}`);

  const P = clamp(input.parsePackage && input.parsePackage.quality && input.parsePackage.quality.score);
  const alternative = Math.max(0, ...((input.classification && input.classification.alternatives) || []).map((item) => Number(item.model_confidence) || 0));
  const modelTypeScore = clamp(input.classification && input.classification.model_confidence);
  const margin = clamp(modelTypeScore - alternative);
  const T = clamp(0.65 * modelTypeScore + 0.2 * (input.routeValid ? 1 : 0) + 0.15 * margin);

  const hasSourceLink = Boolean(String(source.source_link || '').trim());
  const hasLocator = Boolean(String(source.source_locator || '').trim());
  const hasParent = Boolean(String(source.parent_summary || '').trim());
  const quoteFound = Boolean(evidenceQuote) && parseMarkdown.includes(evidenceQuote);
  const numbersGrounded = extractedFacts(atomText).every((item) => evidenceQuote.includes(item) || parseMarkdown.includes(item));
  const E = clamp((hasLocator ? 0.2 : 0) + (hasSourceLink ? 0.1 : 0) + (hasParent ? 0.1 : 0) + (quoteFound ? 0.4 : 0) + (numbersGrounded ? 0.2 : 0));

  const S = clamp((input.schemaValid ? 0.4 : 0) + (input.routeValid ? 0.3 : 0) + (input.labelsValid ? 0.3 : 0));
  const meaningful = atomText.length >= 12 && !isVague(atomText);
  const A = clamp((meaningful ? 0.6 : 0) + (!input.duplicate ? 0.4 : 0));
  const components = { P, T, E, S, A };
  let score = Object.entries(WEIGHTS).reduce((sum, [key, weight]) => sum + components[key] * weight, 0);

  if (P < 0.7) hardRules.push('解析质量低于 0.70，必须重新解析');
  if (!hasSourceLink) hardRules.push('缺少源文件链接');
  if (!hasLocator) hardRules.push('缺少原文定位');
  if (!evidenceQuote) hardRules.push('缺少逐字证据');
  if (!quoteFound) {
    hardRules.push('逐字证据无法在解析文本中定位');
    score = Math.min(score, 0.59);
  }
  if (!numbersGrounded) hardRules.push('知识卡片引入了证据中不存在的数字或日期');
  if (!input.schemaValid || !input.routeValid || !input.labelsValid) {
    hardRules.push('Schema、固定目录或标签字典校验未通过');
    score = Math.min(score, 0.69);
  }
  if (!meaningful) {
    hardRules.push('知识原子内容空泛或信息量不足');
    score = Math.min(score, 0.69);
  }
  if (input.duplicate) {
    hardRules.push('与已有知识卡片重复');
    score = Math.min(score, 0.69);
  }

  score = round(clamp(score));
  const rejected = P < 0.7 || !hasSourceLink || !hasLocator || !evidenceQuote || !numbersGrounded;
  let decision;
  if (rejected) decision = 'reject';
  else if (score >= 0.85 && hardRules.length === 0) decision = 'auto_ingest';
  else if (score >= 0.7) decision = 'review';
  else decision = 'regenerate';

  return {
    score,
    decision,
    components: Object.fromEntries(Object.entries(components).map(([key, value]) => [key, round(value)])),
    weights: WEIGHTS,
    hard_rules: hardRules
  };
}

function extractedFacts(text) {
  return [...new Set(String(text || '').match(/\d+(?:\.\d+)?(?:%|‰|mm|cm|m²|m2|m³|m3|MPa|kN|元|万元|亿元|年|月|日)?/g) || [])];
}

function flattenContent(value) {
  if (value === null || value === undefined) return '';
  if (typeof value === 'string' || typeof value === 'number') return String(value);
  if (Array.isArray(value)) return value.map(flattenContent).join(' ');
  if (typeof value === 'object') {
    return Object.entries(value)
      .filter(([key]) => key !== 'id' && !/_ids?$/.test(key))
      .map(([, item]) => flattenContent(item))
      .join(' ');
  }
  return '';
}

function isVague(text) {
  return /^(召开|开展|推进|优化|加强|提升|讨论|研究).{0,20}(会议|工作|管理|效率|方案)?[。.]?$/.test(String(text || '').trim());
}

function normalizeText(value) {
  return String(value || '').replace(/\s+/g, ' ').trim();
}

function clamp(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return 0;
  return Math.max(0, Math.min(1, number));
}

function round(value) {
  return Math.round(value * 1000) / 1000;
}

module.exports = { WEIGHTS, calculateConfidence, extractedFacts };

},
/**
 * @module src/core/markdown-renderer
 * 知识卡片 Markdown 渲染：buildCardRecord / renderKnowledgeCard / renderStructuredSummary
 * 含 YAML frontmatter / 章节拼接 / 空字段容错
 * @exports buildCardRecord
 * @exports cardFileName
 * @exports renderKnowledgeCard
 * @exports renderStructuredSummary
 */
"src/core/markdown-renderer.js": function(require, module, exports) {
const { atomFingerprint, cardIdentity } = require("src/core/identity.js");

function buildCardRecord(options) {
  const atom = options.atom;
  const fingerprint = atomFingerprint(atom);
  const cardId = cardIdentity(options.library, options.sourceHash, fingerprint);
  const now = typeof options.now === 'string' ? options.now : (options.now || new Date()).toISOString();
  const related = (atom.related_candidates || []).map((item) => typeof item === 'string' ? item : item.target).filter(Boolean);
  const relations = (atom.related_candidates || []).filter((item) => item && typeof item === 'object' && item.target).map((item) => ({
    target: item.target,
    relation: item.relation || 'related'
  }));
  const tags = [...new Set([atom.Category, atom.TagL1, atom.TagL2].filter(Boolean))];
  const sourceLink = String(atom.source && atom.source.source_link || '');
  const sourceFile = sourceLink.replace(/^\[\[/, '').replace(/\]\]$/, '').split('/').pop();
  const card = {
    title: atom.title,
    card_id: cardId,
    atom_fingerprint: fingerprint,
    card_kind: atom.card_kind,
    library: atom.library,
    folder_type: atom.folder_type,
    output_folder: options.route.output_folder,
    status: 'confirmed',
    source_file: sourceFile,
    source_link: sourceLink,
    source_hash: options.sourceHash,
    source_page: atom.source && atom.source.source_locator || '',
    source_locator: atom.source && atom.source.source_locator || '',
    evidence_quote: atom.source && atom.source.evidence_quote || '',
    parent_summary: atom.source && atom.source.parent_summary || '',
    related,
    relations,
    aliases: [],
    tags,
    confidence: options.confidence.score,
    confidence_components: options.confidence.components,
    schema_version: options.versions.schemaVersion,
    pipeline_version: options.versions.pipelineVersion,
    prompt_bundle_version: options.versions.promptBundleVersion,
    created: now,
    updated: now,
    content: atom.content || {}
  };
  for (const key of ['Info_Type', 'Event_Type', 'Category', 'TagL1', 'TagL2', 'project', 'client', 'stage']) {
    if (atom[key]) card[key] = atom[key];
  }
  if (options.supersedes) card.supersedes = options.supersedes;
  return card;
}

function renderKnowledgeCard(card) {
  const frontmatterOrder = [
    'title', 'card_id', 'atom_fingerprint', 'card_kind', 'Info_Type', 'Event_Type', 'library', 'folder_type',
    'output_folder', 'project', 'client', 'stage', 'status', 'Category', 'TagL1', 'TagL2', 'created', 'updated',
    'source_file', 'source_link', 'source_hash', 'source_page', 'parent_summary', 'supersedes', 'superseded_by',
    'related', 'aliases', 'tags', 'confidence', 'confidence_components', 'schema_version', 'pipeline_version', 'prompt_bundle_version'
  ];
  const lines = ['---'];
  for (const key of frontmatterOrder) {
    if (!hasValue(card[key]) && !['related', 'aliases', 'tags'].includes(key)) continue;
    lines.push(`${key}: ${yamlValue(card[key])}`);
  }
  lines.push('---', '', `# ${card.title}`, '');

  if (card.card_kind === 'event') renderEventBody(lines, card.content || {});
  else renderStaticBody(lines, card.content || {});

  optionalSection(lines, '来源证据', [
    `- 来源文件：${card.source_link}`,
    `- 证据位置：${card.source_locator || card.source_page}`,
    `- 原文摘录：${card.evidence_quote}`
  ]);
  optionalSection(lines, '关联知识', [
    `- 上游总结：${card.parent_summary}`,
    ...(Array.isArray(card.content && card.content.semantic_links) ? card.content.semantic_links : []).map((relation) => `- ${relation.relation || 'related'} ${relation.target || relation.target_card_id || ''}`),
    ...(Array.isArray(card.relations) ? card.relations : []).map((relation) => `- ${relation.relation || 'related'} ${relation.target}`),
    ...(Array.isArray(card.related) ? card.related : []).map((target) => `- related ${target}`)
  ]);
  return `${lines.join('\n').replace(/\n{3,}/g, '\n\n')}\n`;
}

function renderStaticBody(lines, content) {
  lines.push('## 核心知识', '', content.core_knowledge || content.statement || content.summary || '');
  optionalSection(lines, '适用条件与边界', content.applicable_conditions);
  optionalSection(lines, '关键参数、条款或方法', content.details);
}

function renderEventBody(lines, content) {
  lines.push('## 背景与触发', '', content.background || content.context || '');
  optionalSection(lines, '争议点或讨论问题', content.discussion);
  optionalSection(lines, '已确认方案或结论', content.confirmed_solution || content.decision);
  optionalSection(lines, '未决事项', content.unresolved_items);
  optionalSection(lines, '后续行动', content.action_items);
}

function optionalSection(lines, title, value) {
  if (!hasValue(value)) return;
  lines.push('', `## ${title}`, '', formatBody(value));
}

function formatBody(value) {
  if (Array.isArray(value)) return value.map((item) => `- ${typeof item === 'string' ? item : JSON.stringify(item)}`).join('\n');
  if (value && typeof value === 'object') return Object.entries(value).map(([key, item]) => `- ${key}：${formatBody(item)}`).join('\n');
  return String(value || '');
}

function cardFileName(card) {
  return `${String(card.card_id || 'card-unassigned').replace(/[^a-zA-Z0-9-]/g, '-')}.md`;
}

function renderStructuredSummary(summary, sourceLink) {
  const lines = [
    '---',
    `title: ${yamlValue(summary.document_title)}`,
    'artifact_type: "structured-summary"',
    `library: ${yamlValue(summary.library)}`,
    `folder_type: ${yamlValue(summary.folder_type)}`,
    `document_type: ${yamlValue(summary.document_type)}`,
    `source_link: ${yamlValue(sourceLink)}`,
    `schema_version: ${yamlValue(summary.schema_version)}`,
    '---', '', `# ${summary.document_title}`, '', '## 摘要', '', summary.executive_summary || '', '', '## 结构化要点', ''
  ];
  for (const point of summary.key_points || []) lines.push(`- **${point.kind || '要点'}** ${point.content} ^${point.point_id}`);
  lines.push('', '## 来源证据', '');
  for (const evidence of summary.evidence || []) lines.push(`- ${evidence.locator}：${evidence.quote} ^${evidence.evidence_id}`);
  lines.push('', '## 源文件', '', `- ${sourceLink}`);
  return `${lines.join('\n').replace(/\n{3,}/g, '\n\n')}\n`;
}

function yamlValue(value) {
  if (Array.isArray(value)) return JSON.stringify(value);
  if (value && typeof value === 'object') return JSON.stringify(value);
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  return JSON.stringify(String(value === undefined || value === null ? '' : value));
}

function hasValue(value) {
  if (value === undefined || value === null || value === '') return false;
  if (Array.isArray(value)) return value.length > 0;
  return true;
}

module.exports = { buildCardRecord, cardFileName, renderKnowledgeCard, renderStructuredSummary, yamlValue };

},
/**
 * @module src/core/link-service
 * 卡片间链接建议：基于标签 / Map_Index / 共享实体的双向链接候选
 * @exports findLinkCandidates
 * @exports validateRelations
 */
"src/core/link-service.js": function(require, module, exports) {
const RELATION_TYPES = Object.freeze(['supports', 'contradicts', 'supersedes', 'depends_on', 'implements', 'related']);

function findLinkCandidates(atom, cards, options = {}) {
  const limit = Math.min(20, Math.max(1, Number(options.limit) || 20));
  const atomTokens = tokenSet(`${atom.title || ''} ${flatten(atom.content)}`);
  return (cards || []).map((card) => {
    const cardTokens = tokenSet(`${card.title || ''} ${card.text || ''}`);
    let score = intersectionSize(atomTokens, cardTokens) * 2;
    if (atom.Category && atom.Category === card.Category) score += 6;
    if (atom.TagL1 && atom.TagL1 === card.TagL1) score += 3;
    if (atom.TagL2 && atom.TagL2 === card.TagL2) score += 2;
    return Object.assign({}, card, { candidate_score: score });
  }).sort((left, right) => right.candidate_score - left.candidate_score || String(left.card_id).localeCompare(String(right.card_id))).slice(0, limit);
}

function validateRelations(relations, candidates) {
  const candidateIds = new Set((candidates || []).map((item) => item.card_id));
  const valid = [];
  const issues = [];
  for (const relation of relations || []) {
    if (!candidateIds.has(relation.target_card_id)) {
      issues.push(`关联目标不在候选集：${relation.target_card_id}`);
      continue;
    }
    if (!RELATION_TYPES.includes(relation.relation)) {
      issues.push(`不支持的关联类型：${relation.relation}`);
      continue;
    }
    valid.push({ target_card_id: relation.target_card_id, relation: relation.relation });
  }
  return { valid, issues };
}

function tokenSet(text) {
  const normalized = String(text || '').toLowerCase();
  const tokens = normalized.match(/[a-z0-9][a-z0-9_-]+|[\u3400-\u9fff]{2,}/g) || [];
  const set = new Set();
  for (const token of tokens) {
    set.add(token);
    if (/^[\u3400-\u9fff]+$/.test(token)) {
      for (let index = 0; index < token.length - 1; index += 1) set.add(token.slice(index, index + 2));
    }
  }
  return set;
}

function intersectionSize(left, right) {
  let count = 0;
  for (const item of left) if (right.has(item)) count += 1;
  return count;
}

function flatten(value) {
  if (value === null || value === undefined) return '';
  if (typeof value !== 'object') return String(value);
  return Object.values(value).map(flatten).join(' ');
}

module.exports = { RELATION_TYPES, findLinkCandidates, validateRelations };


},
/**
 * @module src/core/workflow
 * 顶层工作流编排：parse → classify → summarize → atomize → buildCard → save
 * 串联 ai-pipeline / routing / link-service / markdown-renderer / confidence
 * @exports runKnowledgeWorkflow
 */
"src/core/workflow.js": function(require, module, exports) {
const { atomizeSummary, classifyDocument, summarizeDocument } = require("src/core/ai-pipeline.js");
const { calculateConfidence } = require("src/core/confidence.js");
const { atomFingerprint } = require("src/core/identity.js");
const { buildCardRecord } = require("src/core/markdown-renderer.js");
const { resolveFixedRoute } = require("src/core/routing.js");
const { findLinkCandidates, validateRelations } = require("src/core/link-service.js");

async function runKnowledgeWorkflow(options) {
  const classification = options.classification || await classifyDocument({
    parsePackage: options.parsePackage,
    folderMap: options.folderMap,
    classifierPrompt: options.prompts.classifier,
    classificationSchema: options.schemas.classification,
    requestJson: options.requestJson,
    onProgress: options.onProgress
  });
  await emitArtifact(options.onArtifact, 'classification', classification);
  const route = resolveFixedRoute(options.folderMap, classification);
  const typePrompt = options.prompts.type || (typeof options.loadTypePrompt === 'function' ? await options.loadTypePrompt(route, classification) : '');
  const summary = options.summary || await summarizeDocument({
    parsePackage: options.parsePackage,
    classification,
    basePrompt: options.prompts.summaryBase,
    typePrompt,
    summarySchema: options.schemas.summary,
    maxChunkChars: options.maxChunkChars,
    chunkOverlapRatio: options.chunkOverlapRatio,
    coalesceTinyChunks: options.coalesceTinyChunks,
    summaryConcurrency: options.summaryConcurrency,
    maxRepairAttempts: 2,
    requestJson: options.requestJson,
    requestStream: options.requestStream,
    onProgress: options.onProgress
  });
  await emitArtifact(options.onArtifact, 'summary', summary);
  const linkCandidates = findLinkCandidates({ title: summary.document_title, content: summary }, options.existingCards || [], { limit: 20 });
  const atomResult = options.atomResult || await atomizeSummary({
    summary,
    atomPrompt: options.prompts.atoms,
    typeMapping: options.prompts.typeMapping,
    tagLibrary: options.prompts.tagLibrary,
    linkCandidates,
    atomSchema: options.schemas.atoms,
    maxPointsPerRequest: options.maxPointsPerRequest,
    atomizationConcurrency: options.atomizationConcurrency,
    requestJson: options.requestJson,
    onProgress: options.onProgress
  });
  await emitArtifact(options.onArtifact, 'atoms', atomResult);

  const existingFingerprints = new Set([
    ...(options.existingFingerprints || []),
    ...(options.existingCards || []).map((card) => card.atom_fingerprint).filter(Boolean)
  ]);
  const accepted = [];
  const review = [];
  const pageCount = Array.isArray(options.parsePackage.pages) && options.parsePackage.pages.length
    ? options.parsePackage.pages.length
    : Number(options.parsePackage.total_pages || options.parsePackage.page_count || 0);
  const shortDocumentMaxCards = Math.max(5, Number(options.shortDocumentMaxCards) || 20);
  const quantityAnomaly = pageCount > 0 && pageCount <= 3 && (atomResult.atoms || []).length > shortDocumentMaxCards;
  for (const atom of atomResult.atoms || []) {
    atom.source = Object.assign({}, atom.source || {}, {
      source_link: `[[${options.parsePackage.source_path}]]`
    });
    reconcileAtomLinks(atom, linkCandidates);
    const fingerprint = atomFingerprint(atom);
    const labelsValid = typeof options.validateLabels === 'function' ? options.validateLabels(atom) : true;
    const routeValid = atom.library === classification.library && atom.folder_type === classification.folder_type;
    const duplicate = existingFingerprints.has(fingerprint);
    const confidence = calculateConfidence({
      parsePackage: options.parsePackage,
      classification,
      atom,
      schemaValid: true,
      routeValid,
      labelsValid,
      duplicate
    });
    const card = buildCardRecord({
      atom,
      route,
      sourceHash: options.sourceHash,
      confidence,
      versions: options.versions,
      now: options.now
    });
    if (confidence.decision === 'auto_ingest' && !quantityAnomaly) {
      accepted.push(card);
      existingFingerprints.add(fingerprint);
    } else {
      const reasons = [...confidence.hard_rules, ...(atom.validation_issues || [])];
      if (quantityAnomaly) reasons.push(`短文档数量异常：${pageCount} 页生成 ${(atomResult.atoms || []).length} 张卡片，超过阈值 ${shortDocumentMaxCards}，需整批人工确认`);
      if (!labelsValid && !reasons.some((reason) => /标签/.test(reason))) reasons.push('标签字典校验未通过');
      if (!routeValid && !reasons.some((reason) => /目录/.test(reason))) reasons.push('知识原子目录与文档分类不一致');
      if (duplicate && !reasons.some((reason) => /重复/.test(reason))) reasons.push('与已有知识卡片重复');
      if (!reasons.length) reasons.push(`可信度 ${confidence.score} 低于自动入库阈值`);
      review.push({
        atom_id: atom.atom_id,
        library: atom.library,
        folder_type: atom.folder_type,
        status: 'pending',
        reasons,
        confidence,
        atom,
        proposed_card: card
      });
    }
  }
  // v2.8.1: 工作流最终产出诊断——accepted/review 全空时，这条日志直接说明原子在哪一步丢的
  diag('workflow.result', {
    title: summary && summary.document_title,
    summaryKeyPoints: (summary && Array.isArray(summary.key_points)) ? summary.key_points.length : 0,
    atoms: (atomResult && Array.isArray(atomResult.atoms)) ? atomResult.atoms.length : 0,
    accepted: accepted.length,
    review: review.length,
    truncated: !!(atomResult && atomResult._truncated)
  });
  // v1.4 (M-07): 透传截断标志，dashboard 可显示警告
  return {
    classification,
    route,
    summary,
    atomResult,
    accepted,
    review,
    truncated: !!(atomResult && atomResult._truncated),
    truncatedCompleted: Array.isArray(atomResult?.coverage?.point_ids) ? atomResult.coverage.point_ids.length : (atomResult?.atoms?.length || 0)
  };
}

function reconcileAtomLinks(atom, candidates) {
  const validation = validateRelations(atom.related_candidates || [], candidates);
  const byId = new Map(candidates.map((candidate) => [candidate.card_id, candidate]));
  atom.related_candidates = validation.valid.map((relation) => {
    const target = byId.get(relation.target_card_id);
    const path = String(target.path || '').replace(/\.md$/i, '');
    return { target: `[[${path}]]`, relation: relation.relation };
  });
}

async function emitArtifact(handler, name, value) {
  if (typeof handler === 'function') await handler(name, value);
}

module.exports = { runKnowledgeWorkflow };

},
/**
 * @module src/core/review-service
 * 审核面板服务：按文件夹 / 状态 / 标签分组 + 批量审批
 * @exports groupReviewItems
 * @exports applyBatchAction
 */
"src/core/review-service.js": function(require, module, exports) {
function groupReviewItems(items) {
  const groups = new Map();
  for (const item of items || []) {
    const issue = [...(item.reasons || [])].sort().join('；') || '其他异常';
    const key = `${item.library || 'unknown'}|${item.folder_type || 'unknown'}|${issue}`;
    if (!groups.has(key)) {
      groups.set(key, {
        group_id: `review-${hashCode(key)}`,
        library: item.library,
        folder_type: item.folder_type,
        reasons: item.reasons || [],
        label: `${item.folder_type || '未分类'} · ${issue}`,
        items: []
      });
    }
    groups.get(key).items.push(item);
  }
  return [...groups.values()].sort((left, right) => right.items.length - left.items.length || left.label.localeCompare(right.label, 'zh-CN'));
}

// v1.4 (M-05): 批量修正的字段白名单与校验器。
//       用户在 dashboard prompt 输入 JSON 后，必须先过 validateCorrection 才会真正落到 atom。
//       任意不在白名单的字段、类型不是 string、数值空字符串都会被拒绝。
const ALLOWED_CORRECTION_FIELDS = new Set([
  'Category', 'TagL1', 'TagL2', 'Info_Type', 'Event_Type', 'Card_Type', 'Map_Index'
]);
function validateCorrection(correction) {
  if (!correction || typeof correction !== 'object' || Array.isArray(correction)) {
    throw new Error('修正内容必须是 JSON 对象，例如 {"Category":"…","TagL1":"…"}');
  }
  const cleaned = {};
  for (const [key, value] of Object.entries(correction)) {
    if (!ALLOWED_CORRECTION_FIELDS.has(key)) {
      throw new Error(`字段 "${key}" 不在白名单（${[...ALLOWED_CORRECTION_FIELDS].join(' / ')}）内，已被拒绝`);
    }
    if (value == null || value === '') continue; // 视为"不修改该字段"
    if (typeof value !== 'string') {
      throw new Error(`字段 "${key}" 必须是字符串，当前为 ${typeof value}`);
    }
    const trimmed = value.trim();
    if (!trimmed) continue;
    if (trimmed.length > 100) {
      throw new Error(`字段 "${key}" 长度超过 100 字符`);
    }
    cleaned[key] = trimmed;
  }
  if (Object.keys(cleaned).length === 0) {
    throw new Error('没有可应用的修正字段（所有字段都是空字符串）');
  }
  return cleaned;
}

function applyBatchAction(items, action, correction = {}) {
  const statuses = {
    approve_group: 'approved_override',
    regenerate_group: 'regenerate',
    discard_group: 'discarded',
    apply_correction: 'corrected'
  };
  if (!statuses[action]) throw new Error(`不支持的批量审核操作：${action}`);
  return (items || []).map((item) => {
    const next = clone(item);
    next.status = statuses[action];
    if (action === 'apply_correction') next.atom = Object.assign({}, next.atom || {}, correction);
    return next;
  });
}

function pendingReviewItems(reviewArtifacts) {
  return (reviewArtifacts || []).flatMap((artifact) => artifact.items || []).filter((item) => item.status === 'pending' || item.status === 'corrected');
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function hashCode(value) {
  let hash = 0;
  for (const char of String(value)) hash = ((hash << 5) - hash + char.charCodeAt(0)) | 0;
  return Math.abs(hash).toString(36);
}

module.exports = { applyBatchAction, groupReviewItems, pendingReviewItems };


}
};
const __cache = {};
function __require(id) {
  if (__modules[id]) {
    if (!__cache[id]) {
      const module = { exports: {} };
      __cache[id] = module;
      __modules[id](__require, module, module.exports);
    }
    return __cache[id].exports;
  }
  if (__nativeRequire) return __nativeRequire(id);
  throw new Error('Cannot find module ' + id);
}
module.exports = __require('main.js');
})();
